# LibMarket: backend API reference

This guide is for the Expo app, which uses `@supabase/supabase-js` v2. Every type mentioned below is defined in [`types.ts`](./types.ts). Create the client with `createClient<Database>(...)` so that `from()` and `rpc()` calls are fully typed. See README §3.

Conventions:
- IDs are UUID strings. `categories.id` is the exception: it is an integer.
- Timestamps are ISO strings (`timestamptz`).
- Money is `numeric(14,2)`, which arrives in the app as a JS `number`. The currency is `'USD' | 'LRD'`.
- Errors come back as `{ error: { code, message } }`. The `message` values raised by RPCs are written for humans, so you can show them to the user.
  - RLS violations return code `42501`, with a message like `new row violates row-level security policy`, or `permission denied` when the column is not writable.

---

## Contents

1. [Auth and profiles](#1-auth--profiles)
2. [Categories and config](#2-categories--config)
3. [Listings and images](#3-listings--images)
4. [Search (RPC `search_listings`)](#4-search)
5. [Favorites](#5-favorites)
6. [Chat: conversations, messages, offers](#6-chat)
7. [Reviews](#7-reviews)
8. [Reports and blocks](#8-reports--blocks)
9. [Saved searches](#9-saved-searches)
10. [Push tokens](#10-push-tokens)
11. [Storage](#11-storage)
12. [Realtime](#12-realtime)
13. [RPC summary](#13-rpc-summary)

---

## 1. Auth and profiles

When a user signs up, a `profiles` row is created automatically by the trigger on `auth.users`. The trigger reads `options.data`:

| metadata key | profile column | fallback |
|---|---|---|
| `display_name` (or `full_name`, `name`) | `display_name` | the part of the email before `@`, then `"LibMarket user"` |
| `avatar_url` | `avatar_url` | |
| `whatsapp` | `whatsapp` | ignored if the format is invalid |
| `community` | `community` | |
| `city` | `city` | `"Monrovia"` |
| (auth phone) | `phone` | |

```ts
await supabase.auth.signInWithOtp({ phone: '+231770000000', options: { data: { display_name: 'Musu K.' } } });
// or
await supabase.auth.signUp({ email, password, options: { data: { display_name: 'Musu K.', community: 'Sinkor' } } });
```

### `profiles` table: your own profile only

`ProfileRow`. You can read and update only your own row.

```ts
const { data: me } = await supabase.from('profiles').select('*').eq('id', user.id).single();

await supabase.from('profiles').update({
  display_name: 'Musu K.', whatsapp: '+231770000000', show_whatsapp: true,
  show_phone: false, community: 'Paynesville', bio: 'Selling baby things',
} satisfies ProfileUpdate).eq('id', user.id);
```

Writable columns: `display_name` (1–60 characters), `avatar_url`, `phone`, `whatsapp` (both must match `^\+?[0-9][0-9 -]{5,19}$`), `show_phone`, `show_whatsapp`, `community`, `city`, `bio` (500 characters or fewer). The server maintains `is_verified`, `rating_avg` and `rating_count`.

### `public_profiles` view: anyone's public profile

`PublicProfileRow`. This view is readable by `anon` and `authenticated` users. `phone` is null unless the user set `show_phone = true`. `whatsapp` is null unless `show_whatsapp = true`, which is the default.

```ts
const { data: seller } = await supabase.from('public_profiles').select('*').eq('id', sellerId).single();
// WhatsApp deep link:
if (seller?.whatsapp) Linking.openURL(`https://wa.me/${seller.whatsapp.replace(/[^0-9]/g, '')}?text=${encodeURIComponent('Hi, is "' + listing.title + '" still available?')}`);
```

---

## 2. Categories and config

`categories` → `CategoryRow`. Public and read-only. There are 20 seeded rows. `icon` is a MaterialCommunityIcons name.

```ts
const { data: categories } = await supabase.from('categories').select('*').order('sort');
```

| slug | name | slug | name |
|---|---|---|---|
| phones-tablets | Phones & Tablets | fashion | Fashion |
| electronics | Electronics | beauty | Beauty |
| computers | Computers | baby-kids | Baby & Kids |
| vehicles | Vehicles | sports-outdoors | Sports & Outdoors |
| motorbikes-keke | Motorbikes & Keke | books-education | Books & Education |
| vehicle-parts | Vehicle Parts | tools-equipment | Tools & Equipment |
| furniture | Furniture | building-materials | Building Materials |
| home-appliances | Home Appliances | agriculture | Agriculture |
| generators-solar | Generators & Solar | pets | Pets |
| services | Services | other | Other |

`app_config` → `AppConfigRow`. Public and read-only. It holds one key, `lrd_per_usd`, a number such as `190`. The app can use it to show "≈ USD" hints.

---

## 3. Listings and images

### `listings` → `ListingRow`

Who can read what:
- Anyone can read listings with status `active` or `reserved`.
- The owner can read all of their own listings, including `sold` and `deleted` ones.
- The buyer and seller in a conversation can still read the listing after it is `sold`, but not after it is `deleted`.

**Create** (`ListingInsert`). `seller_id` defaults to the current user. Status always starts as `active`.

```ts
const { data: listing, error } = await supabase.from('listings').insert({
  title: 'Tecno Camon 20 Pro 256GB', description: 'Clean, charger included',
  price: 180, currency: 'USD', negotiable: true, condition: 'like_new',
  category_id: phonesCategoryId, community: 'Sinkor', city: 'Monrovia',
  lat: 6.2907, lng: -10.7605,           // optional; prefer an approximate / community point for privacy
}).select().single();
```

Rules:
- `title`: 3–120 characters.
- `description`: 5000 characters or fewer.
- `price`: 0 or more.
- `lat` and `lng`: both set or both null.

The server manages `view_count`, `favorite_count`, `is_boosted`, `boosted_until`, `sold_at` and `search`.

**Update** (`ListingUpdate`). The owner can change the content fields and `status`.

```ts
await supabase.from('listings').update({ price: 160 }).eq('id', id);
await supabase.from('listings').update({ status: 'deleted' }).eq('id', id);   // soft delete (preferred)
await supabase.from('listings').update({ status: 'active' }).eq('id', id);    // un-reserve / relist
```

To mark a listing sold, use the `mark_listing_sold` RPC (see below). A hard `delete()` also works for owners. It cascades to images, favorites and conversations, so prefer the soft delete.

**Listing detail with seller and images:**

```ts
const { data } = await supabase
  .from('listings')
  .select('*, seller:public_profiles(*), category:categories(*), listing_images(id, path, sort)')
  .eq('id', id)
  .order('sort', { referencedTable: 'listing_images' })
  .single();
await supabase.rpc('increment_listing_view', { listing_id: id });
```

Embed sellers through `public_profiles`, **not** `profiles`. `profiles` returns only your own row.

**My listings:**

```ts
supabase.from('listings').select('*, listing_images(path, sort)').eq('seller_id', user.id).neq('status', 'deleted').order('created_at', { ascending: false });
```

### `listing_images` → `ListingImageRow`

Up to **10 images** per listing. To add one, upload the file to Storage first, then insert a row (see §11). The `path` must start with `<your user id>/`.

```ts
await supabase.from('listing_images').insert({ listing_id, path: `${user.id}/${listing_id}/${uuid}.jpg`, sort: 0 });
await supabase.from('listing_images').update({ sort: 1 }).eq('id', imageId);
await supabase.from('listing_images').delete().eq('id', imageId);   // also remove the file from Storage
```

The first image by (`sort`, `created_at`) is the cover.

### RPC `mark_listing_sold(listing_id)` → `ListingRow`

Owner only. Sets `status = 'sold'` and `sold_at`, and declines every offer on the listing that is still pending.

```ts
const { data: sold, error } = await supabase.rpc('mark_listing_sold', { listing_id: id });
```

### RPC `increment_listing_view(listing_id)` → `number`

Callable by anyone, including anonymous users. Adds 1 to `view_count` for `active` and `reserved` listings and returns the new count. Views by the seller are not counted. There is no per-user de-duplication, so call it once per detail-screen open.

---

## 4. Search

### RPC `search_listings(args: SearchListingsArgs)` → `ListingCard[]`

Use this for the home feed, category pages and search. It returns only `active` listings. It does **not** return listings from users you have blocked or who have blocked you.

| arg | type | notes |
|---|---|---|
| `q` | string | Free text. Every word is prefix-matched against the title (weighted highest), then the description, community and city. For example, `"sams gal"` finds "Samsung Galaxy". |
| `category` | number | `categories.id` |
| `min_price`, `max_price` | number | If `currency` is set, the range is in that currency. If not, it is compared against the **USD-equivalent** price, using `app_config.lrd_per_usd`. |
| `currency` | `'USD' \| 'LRD'` | filter |
| `condition` | `ListingCondition` | filter |
| `community` | string | case-insensitive exact match, e.g. `'Sinkor'` |
| `sort` | `'newest' \| 'price_asc' \| 'price_desc' \| 'nearest' \| 'relevance'` | Default: `relevance` when `q` is given, otherwise `newest`. Price sorts use the USD-equivalent. `nearest` needs `lat` and `lng`. |
| `lat`, `lng` | number | the user's location, used for `nearest` and `distance_km` |
| `radius_km` | number | optional distance filter (needs `lat` and `lng`) |
| `limit` | number | 1–100, default 20 |
| `offset` | number | default 0 |

Ordering: **boosted listings come first** (`is_boosted` is true and the boost has not expired), then the chosen sort, then newest.

Each card carries `total_count`, the number of matches without `limit` and `offset`, for pagination. It also carries `cover_path`, the seller's name, avatar, verified flag and rating, `price_usd`, and `distance_km`.

```ts
const PAGE = 20;
const { data: cards, error } = await supabase.rpc('search_listings', {
  q: 'generator', category: genCatId, currency: null, max_price: 500,
  community: 'Sinkor', sort: 'price_asc', limit: PAGE, offset: page * PAGE,
});
const total = cards?.[0]?.total_count ?? 0;
const coverUrl = (p: string | null) =>
  p ? supabase.storage.from('listing-images').getPublicUrl(p, { transform: { width: 400 } }).data.publicUrl : null;
```

`getPublicUrl` with `transform` needs image transformations, which are available on the Pro plan. Without the Pro plan, leave out `transform`.

---

## 5. Favorites

`favorites` → `FavoriteRow`, with primary key (`user_id`, `listing_id`). Only the owner can read or write these rows. The server maintains `listings.favorite_count` automatically.

```ts
await supabase.from('favorites').upsert({ listing_id }, { ignoreDuplicates: true }); // add (idempotent)
await supabase.from('favorites').delete().eq('listing_id', listing_id);             // remove
const { data } = await supabase.from('favorites')
  .select('created_at, listing:listings(*, listing_images(path, sort))')
  .order('created_at', { ascending: false });
```

Always pass `ignoreDuplicates: true`. A plain upsert needs UPDATE permission, which users do not have.

---

## 6. Chat

### Flow

1. The buyer taps "Chat" on a listing → `start_conversation(listing_id)`. This returns the existing conversation or creates a new one.
2. The chat screen loads the messages, subscribes to Realtime (§12) and calls `mark_conversation_read`.
3. A participant sends a message → `insert` into `messages`. A trigger updates `conversations.last_message`, `last_message_at` and the other side's unread counter.
4. The buyer can send an offer. The seller accepts or declines it with `respond_to_offer`.

### RPC `start_conversation(listing_id)` → `ConversationRow`

Fails when:
- the caller is the seller: "You cannot start a chat on your own listing"
- the listing is deleted or missing: "Listing not found"
- the listing is sold, but only for a new chat: "no longer available". An existing conversation is still returned.
- either user has blocked the other: code 42501

### `conversations` → `ConversationRow`

Only the buyer and seller can read a conversation. The app never writes to it directly.

### `inbox` view → `InboxRow`: the chat list

There is one row per conversation of the current user. It includes `my_role`, `unread` (my own counter), the other user's name, avatar and verified flag, a listing summary with its cover path, and `is_blocked`.

```ts
const { data: inbox } = await supabase.from('inbox').select('*')
  .order('last_message_at', { ascending: false, nullsFirst: false });
const totalUnread = inbox?.reduce((n, c) => n + c.unread, 0) ?? 0;
```

When `is_blocked` is true, disable the composer. The database also rejects the send.

### `messages` → `MessageRow`

Only conversation participants can read messages. They can insert them but not update or delete them.

```ts
// load (newest first, paginate with .range)
const { data: msgs } = await supabase.from('messages').select('*')
  .eq('conversation_id', convId).order('created_at', { ascending: false }).range(0, 49);

// text
await supabase.from('messages').insert({ conversation_id: convId, body: 'Hello, still available?' });

// offer: buyer only, listing must be active/reserved; currency = listing currency
await supabase.from('messages').insert({ conversation_id: convId, kind: 'offer', offer_amount: 150, body: 'Can you take 150?' });

// image: upload first to message-images/<convId>/<myUserId>/<uuid>.jpg (see §11)
await supabase.from('messages').insert({ conversation_id: convId, kind: 'image', image_path: path, body: null });
```

Server rules:
- `sender_id` must be you. It defaults to you.
- `kind` is `'text'`, `'offer'` or `'image'`. Only the server can create `'system'` messages.
- A `text` message needs a non-empty `body` of 4000 characters or fewer.
- An `offer` needs `offer_amount > 0`. The server sets `offer_status = 'pending'` and `offer_currency`.
- An `image` needs an `image_path` that starts with `<conversation_id>/`.
- Messages are rejected if either user has blocked the other.

`last_message` previews look like `Hello...`, `Offer: USD 1,500`, `[Photo]` or `Offer of USD 150 accepted`.

### RPC `respond_to_offer(message_id, accept)` → `MessageRow`

Only the seller of the conversation can call this, and only on a `pending` offer. It sets `offer_status` to `accepted` or `declined` and posts a `system` message such as "Offer of USD 150 accepted". **Accepting also moves an `active` listing to `reserved`.** The seller can later call `mark_listing_sold`, or set the status back to `active`.

```ts
const { data: offer, error } = await supabase.rpc('respond_to_offer', { message_id, accept: true });
```

### RPC `mark_conversation_read(conversation_id)` → `void`

Sets `read_at` on the messages you received and resets **your** unread counter to 0. Call it when the chat opens and whenever a new message arrives while the chat is on screen. `read_at` can drive "seen" ticks on your own messages.

---

## 7. Reviews

`reviews` → `ReviewRow`. Anyone can read reviews. The server keeps `rating_avg` and `rating_count` on the reviewee's profile in sync.

Rules:
- You can only review the **other party of a conversation about that listing**. The buyer can review the seller, and the seller can review the buyer.
- There is one review per (reviewer, listing).
- You cannot review yourself.
- The rating is 1–5, and the comment is 1000 characters or fewer.

```ts
await supabase.from('reviews').insert({ reviewee_id: sellerId, listing_id, rating: 5, comment: 'Honest seller' });
await supabase.from('reviews').update({ rating: 4 }).eq('id', reviewId);   // own review
const { data } = await supabase.from('reviews')
  .select('*, reviewer:public_profiles!reviews_reviewer_id_fkey(display_name, avatar_url)')
  .eq('reviewee_id', userId).order('created_at', { ascending: false });
```

---

## 8. Reports and blocks

### `reports`: insert only

Set exactly **one** of `listing_id` or `reported_user_id`. The `reason` is one of `ReportReason`: `spam`, `scam`, `prohibited_item`, `offensive`, `wrong_category`, `duplicate`, `harassment`, `other`.

```ts
// NOTE: no .select(), because users cannot read reports
await supabase.from('reports').insert({ listing_id, reason: 'scam', details: 'Asked for mobile money before meeting' });
await supabase.from('reports').insert({ reported_user_id: userId, reason: 'harassment' });
```

### `blocks` → `BlockRow`

You can see and manage only the blocks you created.

```ts
await supabase.from('blocks').insert({ blocked_id: userId });
await supabase.from('blocks').delete().eq('blocked_id', userId);
const { data } = await supabase.from('blocks').select('blocked_id, created_at, user:public_profiles!blocks_blocked_id_fkey(display_name, avatar_url)');
```

A block works in both directions:
- Neither user can message the other, and neither can start a new chat.
- Each user's listings disappear from the other's `search_listings` results.

---

## 9. Saved searches

`saved_searches` → `SavedSearchRow`. Only the owner can read or write these. They are stored for now. Sending "new match" notifications needs a scheduled Edge Function, which is not built yet (see Open items).

```ts
await supabase.from('saved_searches').insert({ query: 'generator', category_id, max_price: 500, currency: 'USD', community: 'Sinkor' });
```

`min_price` must be less than or equal to `max_price`.

---

## 10. Push tokens

### RPC `register_push_token(token, platform)` → `void`

Stores an Expo push token for the current user. If the device was previously signed in as another account, the token moves to the new account.

```ts
const token = (await Notifications.getExpoPushTokenAsync({ projectId })).data;
await supabase.rpc('register_push_token', { token, platform: Platform.OS === 'ios' ? 'ios' : 'android' });
// on sign-out:
await supabase.from('push_tokens').delete().eq('token', token);
```

---

## 11. Storage

| bucket | public | max size | path | who can write |
|---|---|---|---|---|
| `listing-images` | yes | 5 MB | `<user_id>/<listing_id>/<uuid>.jpg` | the owner (first folder = your user id) |
| `avatars` | yes | 2 MB | `<user_id>/avatar.jpg` | the owner |
| `message-images` | **no** | 5 MB | `<conversation_id>/<user_id>/<uuid>.jpg` | conversation participants, into their own sub-folder; blocked pairs cannot upload |

Allowed types: jpeg, png, webp and heic. Compress before uploading, for example with `expo-image-manipulator` at about 1280px and quality 0.7, to save users' mobile data.

```ts
import { decode } from 'base64-arraybuffer';
const path = `${user.id}/${listingId}/${Crypto.randomUUID()}.jpg`;
const { error } = await supabase.storage.from('listing-images')
  .upload(path, decode(base64), { contentType: 'image/jpeg' });
if (!error) await supabase.from('listing_images').insert({ listing_id: listingId, path, sort });
const url = supabase.storage.from('listing-images').getPublicUrl(path).data.publicUrl;

// avatar
await supabase.storage.from('avatars').upload(`${user.id}/avatar.jpg`, decode(base64), { contentType: 'image/jpeg', upsert: true });
await supabase.from('profiles').update({ avatar_url: supabase.storage.from('avatars').getPublicUrl(`${user.id}/avatar.jpg`).data.publicUrl }).eq('id', user.id);

// chat image (private): display with a signed URL
const { data } = await supabase.storage.from('message-images').createSignedUrl(msg.image_path!, 60 * 60);
```

---

## 12. Realtime

`messages` and `conversations` are in the `supabase_realtime` publication. Subscribers only receive rows their RLS policies allow them to read.

```ts
// Inside a chat
const ch = supabase.channel(`chat:${convId}`)
  .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${convId}` },
      (p) => addMessage(p.new as MessageRow))
  .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages', filter: `conversation_id=eq.${convId}` },
      (p) => updateMessage(p.new as MessageRow))          // offer accepted/declined, read_at
  .subscribe();

// Inbox / unread badge
const inboxCh = supabase.channel('inbox')
  .on('postgres_changes', { event: '*', schema: 'public', table: 'conversations' }, () => refetchInbox())
  .subscribe();

// cleanup
supabase.removeChannel(ch);
```

---

## 13. RPC summary

| RPC | Args | Returns | Who |
|---|---|---|---|
| `search_listings` | `SearchListingsArgs` | `ListingCard[]` | anyone |
| `increment_listing_view` | `{ listing_id }` | `number` | anyone |
| `start_conversation` | `{ listing_id }` | `ConversationRow` | signed in, not the seller |
| `mark_conversation_read` | `{ conversation_id }` | `void` | participant |
| `respond_to_offer` | `{ message_id, accept }` | `MessageRow` | seller of the conversation |
| `mark_listing_sold` | `{ listing_id }` | `ListingRow` | listing owner |
| `register_push_token` | `{ token, platform }` | `void` | signed in |

## Table access summary

| Table / view | anon | authenticated user |
|---|---|---|
| `categories`, `app_config` | read | read |
| `public_profiles` (view) | read | read |
| `profiles` | none | read and update own row (limited columns) |
| `listings` | read active and reserved | same, plus own (all statuses) and ones they chat about; create, update and delete own |
| `listing_images` | read for visible listings | same, plus manage own |
| `favorites` | none | own: read, insert, delete |
| `conversations` | none | read as a participant (write through RPCs) |
| `inbox` (view) | none | own conversations |
| `messages` | none | read and insert as a participant |
| `reviews` | read | read, plus insert, update and delete own (rules in §7) |
| `reports` | none | insert only |
| `blocks`, `saved_searches`, `push_tokens` | none | own rows |

## Open items / not included

- **Push delivery.** Tokens are stored, but nothing sends notifications yet. The next step is an Edge Function, fired by a Database Webhook on `messages` INSERT, that calls the Expo Push API. Saved-search alerts would need a scheduled function.
- **Boost payments.** Boosting is admin-only for now. Wire it to mobile money (Orange Money or MTN MoMo) through an Edge Function that uses the `service_role` key.
- **View counts are not de-duplicated per user.** If you need that, add a `listing_views` table.
