# LibMarket: Supabase backend

This folder holds the database, storage and realtime setup for LibMarket, a used-goods marketplace for Liberia that starts in Monrovia. You can run it as-is on a fresh Supabase project.

```
supabase/
├── migrations/
│   ├── 0001_schema.sql      enums, tables, constraints, indexes
│   ├── 0002_rls.sql         grants, RLS policies, helper fns, public_profiles + inbox views
│   ├── 0003_functions.sql   triggers + RPCs + realtime publication
│   ├── 0004_storage.sql     buckets + storage policies
│   └── 0005_seed.sql        20 categories, LRD/USD rate, commented demo data
├── tests/
│   ├── 00_supabase_stub.sql minimal auth/storage/roles stand-in (local Postgres only)
│   ├── 01_flows.sql         end-to-end SQL tests (~120 assertions)
│   └── run_local.sh         creates scratch DB, applies stub + migrations, runs tests
├── types.ts                 TypeScript `Database` type + row/RPC types for the app
├── API.md                   how the app uses every table, view and RPC
└── README.md
```

## 1. Create the project

1. Create a new project at https://supabase.com. A region close to West Africa, such as `eu-west` (London or Frankfurt), gives lower latency.
2. Go to **Authentication → Providers** and enable the providers you want:
   - **Phone (SMS OTP)** is the most natural fit for Liberia. It needs an SMS provider such as Twilio, MessageBird or Vonage.
   - **Email** is useful for testing. You can turn off "Confirm email" while developing.
3. Go to **Authentication → URL configuration** and add your Expo redirect URL, for example `libmarket://`, if you use magic links or OAuth.

## 2. Run the migrations

**Option A: SQL editor (quickest).** Open **SQL Editor** and run the files one at a time, in this order: `0001_schema.sql`, `0002_rls.sql`, `0003_functions.sql`, `0004_storage.sql`, `0005_seed.sql`. Each file must succeed before you run the next one.

**Option B: Supabase CLI.**

```bash
npm i -g supabase            # or: npx supabase ...
supabase login
supabase link --project-ref <your-project-ref>
supabase db push             # applies supabase/migrations/* in order
```

The CLI treats the numeric prefix (`0001`, `0002` and so on) as the migration version. New migrations must use a higher number, for example `0006_...sql`, or a timestamp.

**Enable Realtime.** Migration `0003` adds `messages` and `conversations` to the `supabase_realtime` publication. Check that they are listed under **Database → Publications**.

**Keep the exchange rate current.** `public.app_config` holds `lrd_per_usd`, seeded at 190. Search uses this rate only to compare and sort USD and LRD prices together. To update it:

```sql
update public.app_config set value = '195' where key = 'lrd_per_usd';
```

## 3. App environment variables

Put these in `.env` at the root of the Expo app. Expo inlines variables that start with `EXPO_PUBLIC_`.

```bash
EXPO_PUBLIC_SUPABASE_URL=https://<project-ref>.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=<anon public key>   # Settings → API
```

Both values are safe to ship inside the app, because RLS protects the data. **Never** put the `service_role` key in the app. Use it only on servers and in Edge Functions.

Client setup (Expo / React Native):

```ts
import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';
import type { Database } from './supabase/types';

export const supabase = createClient<Database>(
  process.env.EXPO_PUBLIC_SUPABASE_URL!,
  process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!,
  { auth: { storage: AsyncStorage, autoRefreshToken: true, persistSession: true, detectSessionInUrl: false } },
);
```

Install the dependencies with `npx expo install @supabase/supabase-js @react-native-async-storage/async-storage react-native-url-polyfill`.

## 4. Admin and operations tasks

These use the dashboard or the `service_role` key. There is no user-facing API for them.

| Task | How |
|---|---|
| Verify a seller | `update profiles set is_verified = true where id = '...'` |
| Boost a listing | `update listings set is_boosted = true, boosted_until = now() + interval '7 days' where id = '...'` |
| Moderate reports | `select * from reports where status = 'open' order by created_at` and then set `status` to `reviewing`, `resolved` or `dismissed` |
| Take down a listing | `update listings set status = 'deleted' where id = '...'` |
| Edit categories | Insert or update in `categories`. The app reads them, but only admins can write them. |

## 5. Security model (summary)

- **Row Level Security is on for every table.** Table and column privileges are granted explicitly, so users cannot write server-maintained columns. Examples: `rating_avg`, `is_verified`, `favorite_count`, `view_count`, `is_boosted`, `offer_status`, `read_at`.
- **Profiles.** The `profiles` table can only be read by its owner. Everyone else reads `public_profiles`, a view that returns `phone` only when `show_phone = true` (off by default) and `whatsapp` only when `show_whatsapp = true` (on by default).
- **Listings.** Anyone can read `active` and `reserved` listings. Owners can read all of their own listings. People in a conversation about a listing can still read it after it is sold. `deleted` listings are visible only to the owner.
- **Chat.** Only the buyer and seller can read or write a conversation's messages. Conversations are created only through `start_conversation`. The database rejects messages between two users when either has blocked the other. Users cannot insert `system` messages or set `offer_status` themselves.
- **Reviews.** Anyone can read reviews. A user can review only the other party of a conversation they had about that listing. There is one review per reviewer per listing, and users cannot review themselves.
- **Reports.** Users can create reports but cannot read them. Call `.insert()` **without** `.select()`.
- **Helper functions** are in the `private` schema, which the REST API does not expose.
- `public_profiles` is intentionally a *security-definer* view. It must read other users' rows to show their public fields. The Supabase linter reports it as "Security Definer View". This is expected, because the view exposes only safe columns.

## 6. Verify locally (optional)

The tests run on plain PostgreSQL 15 or later. Stubs stand in for `auth.users`, `auth.uid()`, `storage.*` and the `anon`, `authenticated` and `service_role` roles.

```bash
# with any local Postgres superuser connection:
PGHOST=localhost PGPORT=5432 PGUSER=postgres ./supabase/tests/run_local.sh
# ... prints "ok - ..." per assertion and ends with: ALL TESTS PASSED
```

The tests switch to the `anon` and `authenticated` roles and set `request.jwt.claim.sub`, the same way PostgREST does, so the RLS checks run as real app users would.

You can also run `supabase start` and apply the migrations to the local stack for a full-fidelity check. That setup includes the real Auth, Storage and PostgREST.
