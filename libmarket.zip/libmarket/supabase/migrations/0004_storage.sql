-- =============================================================================
-- LibMarket — 0004_storage.sql
-- Storage buckets + storage.objects policies.
--
-- Path conventions (enforced below):
--   listing-images  (public)  <user_id>/<listing_id>/<uuid>.jpg
--   avatars         (public)  <user_id>/<file>.jpg
--   message-images  (private) <conversation_id>/<user_id>/<uuid>.jpg
--                             read via createSignedUrl() by chat participants
-- storage.foldername(name) returns the folder parts of the object path.
-- =============================================================================

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('listing-images', 'listing-images', true,  5242880, array['image/jpeg', 'image/png', 'image/webp', 'image/heic']),
  ('avatars',        'avatars',        true,  2097152, array['image/jpeg', 'image/png', 'image/webp', 'image/heic']),
  ('message-images', 'message-images', false, 5242880, array['image/jpeg', 'image/png', 'image/webp', 'image/heic'])
on conflict (id) do update
  set public             = excluded.public,
      file_size_limit    = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

-- Helper: is the current user a participant of the conversation whose id is
-- the given text (a path segment)? Never raises on non-uuid input.
-- p_require_unblocked: also require that buyer and seller have not blocked each other.
create or replace function private.is_conversation_participant_text(p_conversation_id text,
                                                                  p_require_unblocked boolean default false)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.conversations c
    where c.id::text = p_conversation_id
      and (select auth.uid()) in (c.buyer_id, c.seller_id)
      and (not p_require_unblocked or not exists (
        select 1 from public.blocks b
        where (b.blocker_id = c.buyer_id  and b.blocked_id = c.seller_id)
           or (b.blocker_id = c.seller_id and b.blocked_id = c.buyer_id)))
  );
$$;
revoke all on function private.is_conversation_participant_text(text, boolean) from public;
grant execute on function private.is_conversation_participant_text(text, boolean) to anon, authenticated, service_role;

-- ---------------------------------------------------------------------------
-- listing-images
-- ---------------------------------------------------------------------------
drop policy if exists "listing-images: public read"  on storage.objects;
drop policy if exists "listing-images: owner insert" on storage.objects;
drop policy if exists "listing-images: owner update" on storage.objects;
drop policy if exists "listing-images: owner delete" on storage.objects;

create policy "listing-images: public read" on storage.objects
  for select to anon, authenticated
  using (bucket_id = 'listing-images');

create policy "listing-images: owner insert" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'listing-images'
              and (storage.foldername(name))[1] = (select auth.uid())::text);

create policy "listing-images: owner update" on storage.objects
  for update to authenticated
  using      (bucket_id = 'listing-images' and (storage.foldername(name))[1] = (select auth.uid())::text)
  with check (bucket_id = 'listing-images' and (storage.foldername(name))[1] = (select auth.uid())::text);

create policy "listing-images: owner delete" on storage.objects
  for delete to authenticated
  using (bucket_id = 'listing-images'
         and (storage.foldername(name))[1] = (select auth.uid())::text);

-- ---------------------------------------------------------------------------
-- avatars
-- ---------------------------------------------------------------------------
drop policy if exists "avatars: public read"  on storage.objects;
drop policy if exists "avatars: owner insert" on storage.objects;
drop policy if exists "avatars: owner update" on storage.objects;
drop policy if exists "avatars: owner delete" on storage.objects;

create policy "avatars: public read" on storage.objects
  for select to anon, authenticated
  using (bucket_id = 'avatars');

create policy "avatars: owner insert" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'avatars'
              and (storage.foldername(name))[1] = (select auth.uid())::text);

create policy "avatars: owner update" on storage.objects
  for update to authenticated
  using      (bucket_id = 'avatars' and (storage.foldername(name))[1] = (select auth.uid())::text)
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = (select auth.uid())::text);

create policy "avatars: owner delete" on storage.objects
  for delete to authenticated
  using (bucket_id = 'avatars'
         and (storage.foldername(name))[1] = (select auth.uid())::text);

-- ---------------------------------------------------------------------------
-- message-images (private): participants read; sender uploads into
-- <conversation_id>/<own user_id>/...; sender deletes own files.
-- ---------------------------------------------------------------------------
drop policy if exists "message-images: participants read" on storage.objects;
drop policy if exists "message-images: participant insert" on storage.objects;
drop policy if exists "message-images: owner delete"      on storage.objects;

create policy "message-images: participants read" on storage.objects
  for select to authenticated
  using (bucket_id = 'message-images'
         and private.is_conversation_participant_text((storage.foldername(name))[1]));

create policy "message-images: participant insert" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'message-images'
              and (storage.foldername(name))[2] = (select auth.uid())::text
              and private.is_conversation_participant_text((storage.foldername(name))[1], true));

create policy "message-images: owner delete" on storage.objects
  for delete to authenticated
  using (bucket_id = 'message-images'
         and (storage.foldername(name))[2] = (select auth.uid())::text);
