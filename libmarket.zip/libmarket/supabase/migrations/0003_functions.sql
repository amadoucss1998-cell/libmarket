-- =============================================================================
-- LibMarket — 0003_functions.sql
-- Triggers (updated_at, signup -> profile, counters, chat bookkeeping, ratings)
-- and RPCs callable from the app via supabase.rpc(...).
--
-- Every SECURITY DEFINER function pins search_path = '' and fully qualifies
-- names. RPCs raise exceptions with human-readable messages; PostgREST returns
-- them as { code, message } (HTTP 400, or 403 for errcode 42501).
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Generic: updated_at
-- -----------------------------------------------------------------------------
create or replace function private.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create trigger set_updated_at before update on public.profiles
  for each row execute function private.set_updated_at();
create trigger set_updated_at before update on public.listings
  for each row execute function private.set_updated_at();
create trigger set_updated_at before update on public.reviews
  for each row execute function private.set_updated_at();
create trigger set_updated_at before update on public.reports
  for each row execute function private.set_updated_at();
create trigger set_updated_at before update on public.push_tokens
  for each row execute function private.set_updated_at();
create trigger set_updated_at before update on public.app_config
  for each row execute function private.set_updated_at();

-- -----------------------------------------------------------------------------
-- Auth: create a profile for every new auth user
-- Reads raw_user_meta_data from supabase.auth.signUp({ options: { data: {...} } }):
--   display_name | full_name | name, avatar_url, whatsapp, community, city
-- Never raises on bad metadata (a failing trigger would block sign-up).
-- -----------------------------------------------------------------------------
create or replace function private.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  meta      jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb);
  v_name    text;
  v_phone   text;
  v_wa      text;
  v_comm    text;
  v_city    text;
  phone_re  constant text := '^\+?[0-9][0-9 -]{5,19}$';
begin
  v_name := left(btrim(coalesce(
              nullif(btrim(meta ->> 'display_name'), ''),
              nullif(btrim(meta ->> 'full_name'), ''),
              nullif(btrim(meta ->> 'name'), ''),
              nullif(split_part(coalesce(new.email, ''), '@', 1), ''),
              'LibMarket user')), 60);
  if v_name = '' then v_name := 'LibMarket user'; end if;

  v_phone := nullif(btrim(coalesce(new.phone, meta ->> 'phone', '')), '');
  if v_phone is not null and v_phone !~ phone_re then v_phone := null; end if;

  v_wa := nullif(btrim(coalesce(meta ->> 'whatsapp', '')), '');
  if v_wa is not null and v_wa !~ phone_re then v_wa := null; end if;

  v_comm := left(nullif(btrim(meta ->> 'community'), ''), 80);
  v_city := coalesce(left(nullif(btrim(meta ->> 'city'), ''), 80), 'Monrovia');

  insert into public.profiles (id, display_name, avatar_url, phone, whatsapp, community, city)
  values (new.id, v_name, nullif(meta ->> 'avatar_url', ''), v_phone, v_wa, v_comm, v_city)
  on conflict (id) do nothing;

  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function private.handle_new_user();

-- Backfill profiles for users that existed before this migration.
insert into public.profiles (id, display_name)
select u.id,
       left(coalesce(nullif(btrim(u.raw_user_meta_data ->> 'display_name'), ''),
                     nullif(split_part(coalesce(u.email, ''), '@', 1), ''),
                     'LibMarket user'), 60)
from auth.users u
on conflict (id) do nothing;

-- -----------------------------------------------------------------------------
-- Listings: sold_at bookkeeping
-- -----------------------------------------------------------------------------
create or replace function private.listings_status_change()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if new.status = 'sold' and old.status is distinct from 'sold' then
    new.sold_at := now();
  elsif new.status <> 'sold' then
    new.sold_at := null;
  end if;
  return new;
end;
$$;

create trigger listings_status_change before update of status on public.listings
  for each row execute function private.listings_status_change();

-- -----------------------------------------------------------------------------
-- Listing images: max 10 per listing
-- -----------------------------------------------------------------------------
create or replace function private.listing_images_limit()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  perform pg_advisory_xact_lock(hashtext('listing_images:' || new.listing_id::text));
  if (select count(*) from public.listing_images i where i.listing_id = new.listing_id) >= 10 then
    raise exception 'A listing can have at most 10 photos';
  end if;
  return new;
end;
$$;

create trigger listing_images_limit before insert on public.listing_images
  for each row execute function private.listing_images_limit();

-- -----------------------------------------------------------------------------
-- Favorites: maintain listings.favorite_count
-- -----------------------------------------------------------------------------
create or replace function private.favorites_count()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if tg_op = 'INSERT' then
    update public.listings set favorite_count = favorite_count + 1 where id = new.listing_id;
    return new;
  else
    update public.listings set favorite_count = greatest(favorite_count - 1, 0) where id = old.listing_id;
    return old;
  end if;
end;
$$;

create trigger favorites_count after insert or delete on public.favorites
  for each row execute function private.favorites_count();

-- -----------------------------------------------------------------------------
-- Messages: normalise/validate before insert, update conversation after insert
-- -----------------------------------------------------------------------------
create or replace function private.format_money(p_amount numeric, p_currency public.currency_code)
returns text
language sql
immutable
set search_path = ''
as $$
  select p_currency::text || ' ' ||
         rtrim(rtrim(to_char(p_amount, 'FM999,999,999,990.00'), '0'), '.');
$$;

create or replace function private.messages_before_insert()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_conv    public.conversations;
  v_listing public.listings;
begin
  select * into v_conv from public.conversations c where c.id = new.conversation_id;
  if not found then
    raise exception 'Conversation not found';
  end if;

  -- Server-controlled fields
  new.created_at := now();
  new.read_at    := null;

  if new.kind = 'offer' then
    if new.sender_id is distinct from v_conv.buyer_id then
      raise exception 'Only the buyer can make an offer';
    end if;
    select * into v_listing from public.listings l where l.id = v_conv.listing_id;
    if not found or v_listing.status not in ('active', 'reserved') then
      raise exception 'This listing is no longer available for offers';
    end if;
    new.offer_status   := 'pending';
    new.offer_currency := v_listing.currency;
  else
    new.offer_status   := null;
    new.offer_currency := null;
  end if;

  if new.kind = 'image'
     and split_part(coalesce(new.image_path, ''), '/', 1) <> new.conversation_id::text then
    raise exception 'image_path must start with the conversation id: <conversation_id>/<file>';
  end if;

  if new.body is not null then
    new.body := btrim(new.body);
    if new.body = '' and new.kind <> 'text' then new.body := null; end if;
  end if;

  return new;
end;
$$;

create trigger messages_before_insert before insert on public.messages
  for each row execute function private.messages_before_insert();

create or replace function private.messages_after_insert()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_preview text;
begin
  v_preview := case new.kind
    when 'text'   then left(new.body, 140)
    when 'image'  then coalesce(left(new.body, 120), '[Photo]')
    when 'offer'  then 'Offer: ' || private.format_money(new.offer_amount, new.offer_currency)
    when 'system' then left(new.body, 140)
  end;

  update public.conversations c
     set last_message    = v_preview,
         last_message_at = new.created_at,
         buyer_unread    = c.buyer_unread  + case when new.sender_id = c.seller_id then 1 else 0 end,
         seller_unread   = c.seller_unread + case when new.sender_id = c.buyer_id  then 1 else 0 end
   where c.id = new.conversation_id;

  return null;
end;
$$;

create trigger messages_after_insert after insert on public.messages
  for each row execute function private.messages_after_insert();

-- -----------------------------------------------------------------------------
-- Reviews: maintain profiles.rating_avg / rating_count
-- -----------------------------------------------------------------------------
create or replace function private.refresh_user_rating(p_user_id uuid)
returns void
language sql
security definer
set search_path = ''
as $$
  update public.profiles p
     set rating_avg   = coalesce((select round(avg(r.rating)::numeric, 2) from public.reviews r where r.reviewee_id = p_user_id), 0),
         rating_count = (select count(*) from public.reviews r where r.reviewee_id = p_user_id)
   where p.id = p_user_id;
$$;

create or replace function private.reviews_rating()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if tg_op in ('INSERT', 'UPDATE') then
    perform private.refresh_user_rating(new.reviewee_id);
  end if;
  if tg_op = 'DELETE' or (tg_op = 'UPDATE' and old.reviewee_id <> new.reviewee_id) then
    perform private.refresh_user_rating(old.reviewee_id);
  end if;
  return null;
end;
$$;

create trigger reviews_rating after insert or update or delete on public.reviews
  for each row execute function private.reviews_rating();

-- =============================================================================
-- RPCs (schema public => callable with supabase.rpc)
-- Parameter names match the API docs; inside plpgsql they are referenced as
-- <function_name>.<param> to avoid clashing with column names.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- start_conversation(listing_id) -> conversations row (existing or new)
-- -----------------------------------------------------------------------------
create or replace function public.start_conversation(listing_id uuid)
returns public.conversations
language plpgsql
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_uid     uuid := auth.uid();
  v_listing public.listings;
  v_conv    public.conversations;
begin
  if v_uid is null then
    raise exception 'You must be signed in' using errcode = '42501';
  end if;

  select * into v_listing from public.listings l where l.id = start_conversation.listing_id;
  if not found or v_listing.status = 'deleted' then
    raise exception 'Listing not found';
  end if;

  if v_listing.seller_id = v_uid then
    raise exception 'You cannot start a chat on your own listing';
  end if;

  select * into v_conv from public.conversations c
   where c.listing_id = v_listing.id and c.buyer_id = v_uid;
  if found then
    return v_conv;
  end if;

  if v_listing.status not in ('active', 'reserved') then
    raise exception 'This listing is no longer available';
  end if;

  if exists (select 1 from public.blocks b
              where (b.blocker_id = v_uid and b.blocked_id = v_listing.seller_id)
                 or (b.blocker_id = v_listing.seller_id and b.blocked_id = v_uid)) then
    raise exception 'You cannot message this user' using errcode = '42501';
  end if;

  insert into public.conversations (listing_id, buyer_id, seller_id)
  values (v_listing.id, v_uid, v_listing.seller_id)
  on conflict (listing_id, buyer_id) do nothing
  returning * into v_conv;

  if v_conv.id is null then  -- lost a race with a concurrent call
    select * into v_conv from public.conversations c
     where c.listing_id = v_listing.id and c.buyer_id = v_uid;
  end if;

  return v_conv;
end;
$$;

-- -----------------------------------------------------------------------------
-- mark_conversation_read(conversation_id) -> void
-- -----------------------------------------------------------------------------
create or replace function public.mark_conversation_read(conversation_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_uid  uuid := auth.uid();
  v_conv public.conversations;
begin
  select * into v_conv from public.conversations c where c.id = mark_conversation_read.conversation_id;
  if not found or v_uid is null or v_uid not in (v_conv.buyer_id, v_conv.seller_id) then
    raise exception 'Conversation not found' using errcode = '42501';
  end if;

  update public.messages m
     set read_at = now()
   where m.conversation_id = v_conv.id
     and m.sender_id <> v_uid
     and m.read_at is null;

  if v_uid = v_conv.buyer_id then
    update public.conversations c set buyer_unread = 0  where c.id = v_conv.id and c.buyer_unread  <> 0;
  else
    update public.conversations c set seller_unread = 0 where c.id = v_conv.id and c.seller_unread <> 0;
  end if;
end;
$$;

-- -----------------------------------------------------------------------------
-- increment_listing_view(listing_id) -> new view_count (seller's own views ignored)
-- -----------------------------------------------------------------------------
create or replace function public.increment_listing_view(listing_id uuid)
returns integer
language plpgsql
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_count integer;
begin
  update public.listings l
     set view_count = l.view_count + 1
   where l.id = increment_listing_view.listing_id
     and l.status in ('active', 'reserved')
     and l.seller_id is distinct from auth.uid()
  returning l.view_count into v_count;

  if v_count is null then
    select l.view_count into v_count from public.listings l
     where l.id = increment_listing_view.listing_id and l.status <> 'deleted';
  end if;
  return coalesce(v_count, 0);
end;
$$;

-- -----------------------------------------------------------------------------
-- respond_to_offer(message_id, accept) -> updated offer message
-- Only the seller of the conversation can answer a pending offer. Accepting
-- marks the listing 'reserved' (if active). A system message is posted.
-- -----------------------------------------------------------------------------
create or replace function public.respond_to_offer(message_id uuid, accept boolean)
returns public.messages
language plpgsql
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_uid  uuid := auth.uid();
  v_msg  public.messages;
  v_conv public.conversations;
begin
  if v_uid is null then
    raise exception 'You must be signed in' using errcode = '42501';
  end if;

  select * into v_msg from public.messages m where m.id = respond_to_offer.message_id for update;
  if not found then
    raise exception 'Offer not found';
  end if;

  select * into v_conv from public.conversations c where c.id = v_msg.conversation_id;
  if v_uid <> v_conv.seller_id then
    raise exception 'Only the seller can respond to this offer' using errcode = '42501';
  end if;
  if v_msg.kind <> 'offer' then
    raise exception 'This message is not an offer';
  end if;
  if v_msg.offer_status <> 'pending' then
    raise exception 'This offer has already been %', v_msg.offer_status;
  end if;

  update public.messages m
     set offer_status = case when respond_to_offer.accept then 'accepted'::public.offer_status
                             else 'declined'::public.offer_status end
   where m.id = v_msg.id
  returning * into v_msg;

  insert into public.messages (conversation_id, sender_id, kind, body)
  values (v_conv.id, v_uid, 'system',
          'Offer of ' || private.format_money(v_msg.offer_amount, v_msg.offer_currency) ||
          case when respond_to_offer.accept then ' accepted' else ' declined' end);

  if respond_to_offer.accept then
    update public.listings l set status = 'reserved'
     where l.id = v_conv.listing_id and l.status = 'active';
  end if;

  return v_msg;
end;
$$;

-- -----------------------------------------------------------------------------
-- mark_listing_sold(listing_id) -> updated listing (owner only).
-- Any still-pending offers on the listing are declined.
-- -----------------------------------------------------------------------------
create or replace function public.mark_listing_sold(listing_id uuid)
returns public.listings
language plpgsql
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_uid     uuid := auth.uid();
  v_listing public.listings;
begin
  select * into v_listing from public.listings l where l.id = mark_listing_sold.listing_id for update;
  if not found or v_listing.status = 'deleted' or v_uid is null or v_listing.seller_id <> v_uid then
    raise exception 'Listing not found' using errcode = '42501';
  end if;

  update public.listings l set status = 'sold'
   where l.id = v_listing.id
  returning * into v_listing;

  update public.messages m
     set offer_status = 'declined'
    from public.conversations c
   where c.listing_id = v_listing.id
     and m.conversation_id = c.id
     and m.kind = 'offer'
     and m.offer_status = 'pending';

  return v_listing;
end;
$$;

-- -----------------------------------------------------------------------------
-- register_push_token(token, platform) -> void
-- Upserts an Expo push token for the current user (moves it if the device
-- previously belonged to another account).
-- -----------------------------------------------------------------------------
create or replace function public.register_push_token(token text, platform public.push_platform)
returns void
language plpgsql
security definer
set search_path = ''
as $$
#variable_conflict use_column
declare
  v_uid uuid := auth.uid();
begin
  if v_uid is null then
    raise exception 'You must be signed in' using errcode = '42501';
  end if;
  insert into public.push_tokens as t (token, user_id, platform)
  values (register_push_token.token, v_uid, register_push_token.platform)
  on conflict (token) do update
     set user_id = excluded.user_id, platform = excluded.platform, updated_at = now();
end;
$$;

-- -----------------------------------------------------------------------------
-- search_listings(...) -> listing cards
--   q          free text; each word is prefix-matched ("sams gal" finds "Samsung Galaxy")
--   category   categories.id
--   min_price / max_price
--              compared in `currency` when currency is given, otherwise compared
--              against the USD-equivalent price (app_config.lrd_per_usd)
--   currency, condition, community (case-insensitive exact match)
--   sort       'newest' | 'price_asc' | 'price_desc' | 'nearest' | 'relevance'
--              default: 'relevance' when q is given, else 'newest'.
--              Price sorts use the USD-equivalent so USD and LRD mix correctly.
--              'nearest' needs lat & lng (falls back to newest otherwise).
--   lat, lng, radius_km (optional distance filter, needs lat & lng)
--   limit (1..100, default 20), offset
-- Only 'active' listings; boosted listings (boost not expired) come first;
-- listings from users you blocked / who blocked you are excluded.
-- total_count = number of matches ignoring limit/offset (for pagination).
-- -----------------------------------------------------------------------------
create or replace function private.to_prefix_tsquery(p_query text)
returns tsquery
language sql
immutable
set search_path = ''
as $$
  select case when s is null then null else to_tsquery('simple'::regconfig, s) end
  from (
    select nullif(string_agg(w || ':*', ' & '), '') as s
    from (
      select w
      from regexp_split_to_table(lower(coalesce(p_query, '')), '[^[:alnum:]]+') as w
      where w <> ''
      limit 8
    ) words
  ) x;
$$;

create or replace function public.search_listings(
  q          text                     default null,
  category   integer                  default null,
  min_price  numeric                  default null,
  max_price  numeric                  default null,
  currency   public.currency_code     default null,
  condition  public.listing_condition default null,
  community  text                     default null,
  sort       text                     default null,
  lat        double precision         default null,
  lng        double precision         default null,
  radius_km  double precision         default null,
  "limit"    integer                  default 20,
  "offset"   integer                  default 0
)
returns table (
  id                  uuid,
  seller_id           uuid,
  title               text,
  price               numeric,
  currency            public.currency_code,
  price_usd           numeric,
  negotiable          boolean,
  condition           public.listing_condition,
  category_id         integer,
  community           text,
  city                text,
  lat                 double precision,
  lng                 double precision,
  status              public.listing_status,
  view_count          integer,
  favorite_count      integer,
  is_boosted          boolean,
  created_at          timestamptz,
  cover_path          text,
  seller_display_name text,
  seller_avatar_url   text,
  seller_is_verified  boolean,
  seller_rating_avg   numeric,
  distance_km         double precision,
  rank                real,
  total_count         bigint
)
language sql
stable
security definer
set search_path = ''
as $$
  with params as (
    select
      private.to_prefix_tsquery(search_listings.q) as tsq,
      coalesce((select (c.value #>> '{}')::numeric from public.app_config c where c.key = 'lrd_per_usd'), 190::numeric) as rate,
      lower(coalesce(nullif(btrim(search_listings.sort), ''),
                     case when nullif(btrim(coalesce(search_listings.q, '')), '') is not null
                          then 'relevance' else 'newest' end)) as sort_key,
      (search_listings.lat is not null and search_listings.lng is not null) as has_point,
      least(greatest(coalesce(search_listings."limit", 20), 1), 100) as lim,
      greatest(coalesce(search_listings."offset", 0), 0)             as off,
      auth.uid() as uid
  ),
  matches as (
    select
      l.*,
      (l.is_boosted and (l.boosted_until is null or l.boosted_until > now())) as boosted,
      x.price_usd,
      x.distance_km,
      case when p.tsq is not null then ts_rank(l.search, p.tsq) else 0 end::real as rnk,
      p.sort_key
    from public.listings l
    cross join params p
    cross join lateral (
      select
        case l.currency when 'USD' then l.price else round(l.price / nullif(p.rate, 0), 2) end as price_usd,
        case when p.has_point and l.lat is not null then
          6371.0 * 2 * asin(sqrt(
              power(sin(radians(l.lat - search_listings.lat) / 2), 2)
            + cos(radians(search_listings.lat)) * cos(radians(l.lat))
            * power(sin(radians(l.lng - search_listings.lng) / 2), 2)))
        end as distance_km
    ) x
    where l.status = 'active'
      and (p.tsq is null or l.search @@ p.tsq)
      and (search_listings.category  is null or l.category_id = search_listings.category)
      and (search_listings.condition is null or l.condition   = search_listings.condition)
      and (search_listings.currency  is null or l.currency    = search_listings.currency)
      and (nullif(btrim(coalesce(search_listings.community, '')), '') is null
           or lower(l.community) = lower(btrim(search_listings.community)))
      and (search_listings.min_price is null
           or (case when search_listings.currency is not null then l.price else x.price_usd end) >= search_listings.min_price)
      and (search_listings.max_price is null
           or (case when search_listings.currency is not null then l.price else x.price_usd end) <= search_listings.max_price)
      and (search_listings.radius_km is null or not p.has_point
           or (x.distance_km is not null and x.distance_km <= search_listings.radius_km))
      and (p.uid is null or not exists (
             select 1 from public.blocks b
              where (b.blocker_id = p.uid and b.blocked_id = l.seller_id)
                 or (b.blocker_id = l.seller_id and b.blocked_id = p.uid)))
  )
  select
    m.id, m.seller_id, m.title, m.price, m.currency, m.price_usd, m.negotiable, m.condition,
    m.category_id, m.community, m.city, m.lat, m.lng, m.status, m.view_count, m.favorite_count,
    m.boosted, m.created_at,
    (select i.path from public.listing_images i
      where i.listing_id = m.id order by i.sort, i.created_at limit 1),
    pr.display_name, pr.avatar_url, pr.is_verified, pr.rating_avg,
    m.distance_km, m.rnk,
    count(*) over ()
  from matches m
  join public.profiles pr on pr.id = m.seller_id
  cross join params p
  order by
    m.boosted desc,
    case when m.sort_key = 'price_asc'  then m.price_usd end asc  nulls last,
    case when m.sort_key = 'price_desc' then m.price_usd end desc nulls last,
    case when m.sort_key = 'nearest'    then m.distance_km end asc nulls last,
    case when m.sort_key = 'relevance'  then m.rnk end desc nulls last,
    m.created_at desc,
    m.id
  limit (select lim from params)
  offset (select off from params);
$$;

-- -----------------------------------------------------------------------------
-- Function privileges
-- (Supabase grants EXECUTE on new public functions to anon/authenticated by
-- default, so revoke first and grant precisely.)
-- -----------------------------------------------------------------------------
revoke all on function
  public.start_conversation(uuid),
  public.mark_conversation_read(uuid),
  public.increment_listing_view(uuid),
  public.respond_to_offer(uuid, boolean),
  public.mark_listing_sold(uuid),
  public.register_push_token(text, public.push_platform),
  public.search_listings(text, integer, numeric, numeric, public.currency_code,
                         public.listing_condition, text, text, double precision,
                         double precision, double precision, integer, integer)
from public, anon, authenticated;

grant execute on function
  public.start_conversation(uuid),
  public.mark_conversation_read(uuid),
  public.respond_to_offer(uuid, boolean),
  public.mark_listing_sold(uuid),
  public.register_push_token(text, public.push_platform)
to authenticated, service_role;

grant execute on function
  public.increment_listing_view(uuid),
  public.search_listings(text, integer, numeric, numeric, public.currency_code,
                         public.listing_condition, text, text, double precision,
                         double precision, double precision, integer, integer)
to anon, authenticated, service_role;

-- New helper/trigger functions in `private`
revoke all on all functions in schema private from public;
grant execute on all functions in schema private to anon, authenticated, service_role;

-- -----------------------------------------------------------------------------
-- Realtime: stream chat changes to the app (RLS still applies per subscriber).
-- -----------------------------------------------------------------------------
do $$
begin
  if not exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    create publication supabase_realtime;
  end if;
  if not exists (select 1 from pg_publication_tables
                  where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'messages') then
    alter publication supabase_realtime add table public.messages;
  end if;
  if not exists (select 1 from pg_publication_tables
                  where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'conversations') then
    alter publication supabase_realtime add table public.conversations;
  end if;
end;
$$;
