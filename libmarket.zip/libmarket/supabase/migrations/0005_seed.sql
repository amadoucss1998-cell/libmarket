-- =============================================================================
-- LibMarket — 0005_seed.sql
-- Reference data. Idempotent (safe to re-run).
-- icon = MaterialCommunityIcons name (@expo/vector-icons).
-- =============================================================================

insert into public.categories (slug, name, icon, sort) values
  ('phones-tablets',      'Phones & Tablets',     'cellphone',          10),
  ('electronics',         'Electronics',          'television',         20),
  ('computers',           'Computers',            'laptop',             30),
  ('vehicles',            'Vehicles',             'car',                40),
  ('motorbikes-keke',     'Motorbikes & Keke',    'motorbike',          50),
  ('vehicle-parts',       'Vehicle Parts',        'car-cog',            60),
  ('furniture',           'Furniture',            'sofa',               70),
  ('home-appliances',     'Home Appliances',      'fridge',             80),
  ('generators-solar',    'Generators & Solar',   'solar-power',        90),
  ('fashion',             'Fashion',              'tshirt-crew',       100),
  ('beauty',              'Beauty',               'lipstick',          110),
  ('baby-kids',           'Baby & Kids',          'baby-carriage',     120),
  ('sports-outdoors',     'Sports & Outdoors',    'soccer',            130),
  ('books-education',     'Books & Education',    'book-open-variant', 140),
  ('tools-equipment',     'Tools & Equipment',    'hammer-wrench',     150),
  ('building-materials',  'Building Materials',   'wall',              160),
  ('agriculture',         'Agriculture',          'sprout',            170),
  ('pets',                'Pets',                 'paw',               180),
  ('services',            'Services',             'account-wrench',    190),
  ('other',               'Other',                'dots-horizontal',   200)
on conflict (slug) do update
  set name = excluded.name, icon = excluded.icon, sort = excluded.sort;

-- Liberian dollars per 1 US dollar. Used only to compare/sort prices across
-- currencies in search_listings. Update from the dashboard as the rate moves:
--   update public.app_config set value = '195' where key = 'lrd_per_usd';
insert into public.app_config (key, value) values
  ('lrd_per_usd', '190'::jsonb)
on conflict (key) do nothing;

-- =============================================================================
-- OPTIONAL DEMO DATA (local / staging only). Uncomment to use.
-- Creates two users via auth.users (the signup trigger creates profiles),
-- a few listings, a conversation with an offer.
-- In a hosted project prefer creating users through Auth, then run the
-- listings part with their real ids.
-- =============================================================================
/*
do $$
declare
  seller uuid := '11111111-1111-1111-1111-111111111111';
  buyer  uuid := '22222222-2222-2222-2222-222222222222';
  l1 uuid; l2 uuid; l3 uuid; conv uuid;
begin
  insert into auth.users (id, email, raw_user_meta_data)
  values (seller, 'kollie.seller@example.com', '{"display_name":"Kollie Electronics","community":"Sinkor"}'),
         (buyer,  'musu.buyer@example.com',    '{"display_name":"Musu K.","community":"Paynesville"}')
  on conflict (id) do nothing;

  update public.profiles set whatsapp = '+231770000001', is_verified = true where id = seller;

  insert into public.listings (seller_id, title, description, price, currency, condition, category_id, community, lat, lng)
  values (seller, 'Tecno Camon 20 Pro 256GB', 'Clean, no scratches. Charger included.', 180, 'USD', 'like_new',
          (select id from public.categories where slug = 'phones-tablets'), 'Sinkor', 6.2907, -10.7605)
  returning id into l1;

  insert into public.listings (seller_id, title, description, price, currency, condition, category_id, community, lat, lng)
  values (seller, 'Firman 3.5kVA generator', 'Used 6 months, runs well.', 65000, 'LRD', 'good',
          (select id from public.categories where slug = 'generators-solar'), 'Sinkor', 6.2907, -10.7605)
  returning id into l2;

  insert into public.listings (seller_id, title, description, price, currency, condition, category_id, community,
                               is_boosted, boosted_until)
  values (seller, 'Honda Ace 125 motorbike', 'Papers complete. Price small negotiable.', 950, 'USD', 'good',
          (select id from public.categories where slug = 'motorbikes-keke'), 'Congo Town', true, now() + interval '7 days')
  returning id into l3;

  insert into public.conversations (listing_id, buyer_id, seller_id) values (l1, buyer, seller) returning id into conv;
  insert into public.messages (conversation_id, sender_id, kind, body) values (conv, buyer, 'text', 'Hello, still available?');
  insert into public.messages (conversation_id, sender_id, kind, body) values (conv, seller, 'text', 'Yes my sister, it is available.');
  insert into public.messages (conversation_id, sender_id, kind, offer_amount) values (conv, buyer, 'offer', 160);
end;
$$;
*/
