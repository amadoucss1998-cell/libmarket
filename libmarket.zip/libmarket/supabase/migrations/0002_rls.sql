-- =============================================================================
-- LibMarket — 0002_rls.sql
-- Privileges, Row Level Security policies, RLS helper functions, public views.
--
-- Model:
--   * Table privileges are granted explicitly (column-level where users must not
--     touch server-maintained columns such as rating_avg, favorite_count,
--     is_boosted, offer_status...).
--   * RLS decides WHICH rows. Every table in `public` has RLS enabled.
--   * Helper functions live in schema `private` (not exposed via the REST API)
--     and are SECURITY DEFINER so policies don't chain through other policies.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1. Reset privileges on our tables, then grant exactly what the app needs.
-- -----------------------------------------------------------------------------
revoke all on
  public.app_config, public.profiles, public.categories, public.listings,
  public.listing_images, public.favorites, public.conversations, public.messages,
  public.reviews, public.reports, public.blocks, public.saved_searches, public.push_tokens
from anon, authenticated;

grant all on all tables    in schema public to service_role;
grant all on all sequences in schema public to service_role;

-- Public reference data
grant select on public.app_config, public.categories to anon, authenticated;

-- Profiles: owners read their own full row (public data goes through the
-- public_profiles view below). Only these columns are user-editable.
grant select on public.profiles to authenticated;
grant update (display_name, avatar_url, phone, whatsapp, show_phone, show_whatsapp,
              community, city, bio)
  on public.profiles to authenticated;

-- Listings
grant select on public.listings to anon, authenticated;
grant insert (seller_id, title, description, price, currency, negotiable, condition,
              category_id, community, city, lat, lng)
  on public.listings to authenticated;
grant update (title, description, price, currency, negotiable, condition,
              category_id, community, city, lat, lng, status)
  on public.listings to authenticated;
grant delete on public.listings to authenticated;

-- Listing images
grant select on public.listing_images to anon, authenticated;
grant insert (listing_id, path, sort) on public.listing_images to authenticated;
grant update (sort)                   on public.listing_images to authenticated;
grant delete                          on public.listing_images to authenticated;

-- Favorites
grant select, delete on public.favorites to authenticated;
grant insert (user_id, listing_id) on public.favorites to authenticated;

-- Conversations: read-only for users (created via start_conversation RPC,
-- counters maintained by triggers / mark_conversation_read RPC).
grant select on public.conversations to authenticated;

-- Messages: insert-only for users (read_at / offer_status set server-side).
grant select on public.messages to authenticated;
grant insert (conversation_id, sender_id, body, kind, offer_amount, image_path)
  on public.messages to authenticated;

-- Reviews
grant select on public.reviews to anon, authenticated;
grant insert (reviewer_id, reviewee_id, listing_id, rating, comment) on public.reviews to authenticated;
grant update (rating, comment) on public.reviews to authenticated;
grant delete on public.reviews to authenticated;

-- Reports: insert only (use supabase-js .insert() WITHOUT .select()).
grant insert (reporter_id, listing_id, reported_user_id, reason, details) on public.reports to authenticated;

-- Blocks
grant select, delete on public.blocks to authenticated;
grant insert (blocker_id, blocked_id) on public.blocks to authenticated;

-- Saved searches
grant select, delete on public.saved_searches to authenticated;
grant insert (user_id, query, category_id, min_price, max_price, currency, community, notify)
  on public.saved_searches to authenticated;
grant update (query, category_id, min_price, max_price, currency, community, notify)
  on public.saved_searches to authenticated;

-- Push tokens (prefer the register_push_token RPC, which handles device hand-over)
grant select, delete on public.push_tokens to authenticated;
grant insert (token, user_id, platform) on public.push_tokens to authenticated;

-- -----------------------------------------------------------------------------
-- 2. Enable RLS everywhere
-- -----------------------------------------------------------------------------
alter table public.app_config     enable row level security;
alter table public.profiles       enable row level security;
alter table public.categories     enable row level security;
alter table public.listings       enable row level security;
alter table public.listing_images enable row level security;
alter table public.favorites      enable row level security;
alter table public.conversations  enable row level security;
alter table public.messages       enable row level security;
alter table public.reviews        enable row level security;
alter table public.reports        enable row level security;
alter table public.blocks         enable row level security;
alter table public.saved_searches enable row level security;
alter table public.push_tokens    enable row level security;

-- -----------------------------------------------------------------------------
-- 3. RLS helper functions (SECURITY DEFINER, schema `private`)
-- -----------------------------------------------------------------------------
create or replace function private.is_conversation_participant(p_conversation_id uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.conversations c
    where c.id = p_conversation_id
      and (select auth.uid()) in (c.buyer_id, c.seller_id)
  );
$$;

-- True if the current user and p_other have blocked each other in either direction.
create or replace function private.is_blocked_with(p_other uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.blocks b
    where (b.blocker_id = (select auth.uid()) and b.blocked_id = p_other)
       or (b.blocker_id = p_other and b.blocked_id = (select auth.uid()))
  );
$$;

-- True if buyer and seller of the conversation have a block in either direction.
create or replace function private.is_conversation_blocked(p_conversation_id uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1
    from public.conversations c
    join public.blocks b
      on (b.blocker_id = c.buyer_id  and b.blocked_id = c.seller_id)
      or (b.blocker_id = c.seller_id and b.blocked_id = c.buyer_id)
    where c.id = p_conversation_id
  );
$$;

create or replace function private.owns_listing(p_listing_id uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.listings l
    where l.id = p_listing_id and l.seller_id = (select auth.uid())
  );
$$;

-- Current user takes part in a conversation about this listing.
create or replace function private.is_listing_participant(p_listing_id uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.conversations c
    where c.listing_id = p_listing_id
      and (select auth.uid()) in (c.buyer_id, c.seller_id)
  );
$$;

-- Listing is visible to the current user (mirrors the listings SELECT policies).
create or replace function private.can_see_listing(p_listing_id uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.listings l
    where l.id = p_listing_id
      and (   l.status in ('active', 'reserved')
           or l.seller_id = (select auth.uid())
           or (l.status <> 'deleted' and private.is_listing_participant(l.id)))
  );
$$;

-- A user may review the other party of a conversation about that listing.
create or replace function private.can_review(p_listing_id uuid, p_reviewee_id uuid)
returns boolean
language sql stable security definer set search_path = ''
as $$
  select exists (
    select 1 from public.conversations c
    where c.listing_id = p_listing_id
      and (   (c.buyer_id  = (select auth.uid()) and c.seller_id = p_reviewee_id)
           or (c.seller_id = (select auth.uid()) and c.buyer_id  = p_reviewee_id))
  );
$$;

revoke all on all functions in schema private from public;
grant execute on all functions in schema private to anon, authenticated, service_role;

-- -----------------------------------------------------------------------------
-- 4. Policies
-- -----------------------------------------------------------------------------

-- app_config / categories: public read, no client writes.
create policy "app_config: public read" on public.app_config
  for select to anon, authenticated using (true);

create policy "categories: public read" on public.categories
  for select to anon, authenticated using (true);

-- profiles: owner reads/updates own row. Everyone else uses public_profiles view.
create policy "profiles: owner read" on public.profiles
  for select to authenticated using (id = (select auth.uid()));

create policy "profiles: owner update" on public.profiles
  for update to authenticated
  using (id = (select auth.uid()))
  with check (id = (select auth.uid()));

-- listings
create policy "listings: public read active" on public.listings
  for select to anon, authenticated
  using (status in ('active', 'reserved'));

create policy "listings: owner read all own" on public.listings
  for select to authenticated
  using (seller_id = (select auth.uid()));

create policy "listings: participants read" on public.listings
  for select to authenticated
  using (status <> 'deleted' and private.is_listing_participant(id));

create policy "listings: owner insert" on public.listings
  for insert to authenticated
  with check (seller_id = (select auth.uid()) and status = 'active');

create policy "listings: owner update" on public.listings
  for update to authenticated
  using (seller_id = (select auth.uid()))
  with check (seller_id = (select auth.uid()));

create policy "listings: owner delete" on public.listings
  for delete to authenticated
  using (seller_id = (select auth.uid()));

-- listing_images: visible when the listing is visible; owner manages.
create policy "listing_images: read if listing visible" on public.listing_images
  for select to anon, authenticated
  using (private.can_see_listing(listing_id));

create policy "listing_images: owner insert" on public.listing_images
  for insert to authenticated
  with check (
    private.owns_listing(listing_id)
    and split_part(path, '/', 1) = (select auth.uid())::text
  );

create policy "listing_images: owner update" on public.listing_images
  for update to authenticated
  using (private.owns_listing(listing_id))
  with check (private.owns_listing(listing_id));

create policy "listing_images: owner delete" on public.listing_images
  for delete to authenticated
  using (private.owns_listing(listing_id));

-- favorites
create policy "favorites: owner read" on public.favorites
  for select to authenticated using (user_id = (select auth.uid()));

create policy "favorites: owner insert" on public.favorites
  for insert to authenticated
  with check (user_id = (select auth.uid()) and private.can_see_listing(listing_id));

create policy "favorites: owner delete" on public.favorites
  for delete to authenticated using (user_id = (select auth.uid()));

-- conversations: participants only (no direct writes).
create policy "conversations: participants read" on public.conversations
  for select to authenticated
  using ((select auth.uid()) in (buyer_id, seller_id));

-- messages: participants only; blocked pairs cannot send; users cannot forge
-- system messages.
create policy "messages: participants read" on public.messages
  for select to authenticated
  using (private.is_conversation_participant(conversation_id));

create policy "messages: participants send" on public.messages
  for insert to authenticated
  with check (
    sender_id = (select auth.uid())
    and kind in ('text', 'offer', 'image')
    and private.is_conversation_participant(conversation_id)
    and not private.is_conversation_blocked(conversation_id)
  );

-- reviews: public read; reviewer writes own; no self-review; must have chatted
-- about the listing with the reviewee.
create policy "reviews: public read" on public.reviews
  for select to anon, authenticated using (true);

create policy "reviews: reviewer insert" on public.reviews
  for insert to authenticated
  with check (
    reviewer_id = (select auth.uid())
    and reviewee_id <> (select auth.uid())
    and listing_id is not null
    and private.can_review(listing_id, reviewee_id)
  );

create policy "reviews: reviewer update" on public.reviews
  for update to authenticated
  using (reviewer_id = (select auth.uid()))
  with check (reviewer_id = (select auth.uid()));

create policy "reviews: reviewer delete" on public.reviews
  for delete to authenticated
  using (reviewer_id = (select auth.uid()));

-- reports: insert-only by authenticated users (moderation via service_role).
create policy "reports: authenticated insert" on public.reports
  for insert to authenticated
  with check (reporter_id = (select auth.uid()));

-- blocks
create policy "blocks: owner read" on public.blocks
  for select to authenticated using (blocker_id = (select auth.uid()));

create policy "blocks: owner insert" on public.blocks
  for insert to authenticated
  with check (blocker_id = (select auth.uid()) and blocked_id <> (select auth.uid()));

create policy "blocks: owner delete" on public.blocks
  for delete to authenticated using (blocker_id = (select auth.uid()));

-- saved_searches
create policy "saved_searches: owner read" on public.saved_searches
  for select to authenticated using (user_id = (select auth.uid()));

create policy "saved_searches: owner insert" on public.saved_searches
  for insert to authenticated with check (user_id = (select auth.uid()));

create policy "saved_searches: owner update" on public.saved_searches
  for update to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

create policy "saved_searches: owner delete" on public.saved_searches
  for delete to authenticated using (user_id = (select auth.uid()));

-- push_tokens
create policy "push_tokens: owner read" on public.push_tokens
  for select to authenticated using (user_id = (select auth.uid()));

create policy "push_tokens: owner insert" on public.push_tokens
  for insert to authenticated with check (user_id = (select auth.uid()));

create policy "push_tokens: owner delete" on public.push_tokens
  for delete to authenticated using (user_id = (select auth.uid()));

-- -----------------------------------------------------------------------------
-- 5. Views
-- -----------------------------------------------------------------------------

-- Public profile data. Intentionally NOT security_invoker: it reads profiles as
-- the view owner so anyone can see public fields, while phone / whatsapp are
-- masked according to the user's show_phone / show_whatsapp choice.
-- (Supabase's linter flags "security definer view" — this one is deliberate.)
create view public.public_profiles
with (security_barrier = true)
as
select
  p.id,
  p.display_name,
  p.avatar_url,
  case when p.show_phone    then p.phone    end as phone,
  case when p.show_whatsapp then p.whatsapp end as whatsapp,
  p.community,
  p.city,
  p.bio,
  p.is_verified,
  p.rating_avg,
  p.rating_count,
  p.created_at
from public.profiles p;

revoke all on public.public_profiles from anon, authenticated;
grant select on public.public_profiles to anon, authenticated, service_role;

-- Inbox: one row per conversation of the current user, with the counterpart,
-- listing summary and MY unread count. Runs with the caller's RLS.
create view public.inbox
with (security_invoker = true)
as
select
  c.id,
  c.listing_id,
  c.buyer_id,
  c.seller_id,
  c.last_message,
  c.last_message_at,
  c.created_at,
  case when c.buyer_id = (select auth.uid()) then 'buyer' else 'seller' end              as my_role,
  case when c.buyer_id = (select auth.uid()) then c.buyer_unread else c.seller_unread end as unread,
  o.id            as other_user_id,
  o.display_name  as other_display_name,
  o.avatar_url    as other_avatar_url,
  o.is_verified   as other_is_verified,
  l.title         as listing_title,
  l.price         as listing_price,
  l.currency      as listing_currency,
  l.status        as listing_status,
  (select li.path from public.listing_images li
    where li.listing_id = c.listing_id
    order by li.sort, li.created_at limit 1)                                              as listing_cover_path,
  private.is_blocked_with(o.id)                                                           as is_blocked
from public.conversations c
left join public.public_profiles o
  on o.id = case when c.buyer_id = (select auth.uid()) then c.seller_id else c.buyer_id end
left join public.listings l on l.id = c.listing_id;

revoke all on public.inbox from anon, authenticated;
grant select on public.inbox to authenticated, service_role;
