-- LibMarket backend flow tests (plain Postgres + 00_supabase_stub.sql).
-- Each block raises on failure; ON_ERROR_STOP makes psql exit non-zero.
\set QUIET on
\o /dev/null
set client_min_messages = warning;

-- ---------------------------------------------------------------------------
-- Test helpers
-- ---------------------------------------------------------------------------
create schema tests;
grant usage on schema tests to anon, authenticated;

create function tests.login(p_uid uuid) returns void language plpgsql as $$
begin
  execute 'reset role';
  perform set_config('request.jwt.claim.sub', coalesce(p_uid::text, ''), false);
  if p_uid is null then execute 'set role anon'; else execute 'set role authenticated'; end if;
end $$;

create function tests.logout() returns void language plpgsql as $$
begin
  execute 'reset role';
  perform set_config('request.jwt.claim.sub', '', false);
end $$;

create function tests.ok(cond boolean, msg text) returns void language plpgsql as $$
begin
  if cond is distinct from true then raise exception 'FAIL: %', msg; end if;
  raise notice 'ok - %', msg;
end $$;

-- Runs p_sql; passes only if it raises an error whose message matches p_like.
create function tests.throws(p_sql text, p_like text, msg text) returns void language plpgsql as $$
declare err text;
begin
  begin
    execute p_sql;
  exception when others then
    err := sqlerrm;
  end;
  if err is null then raise exception 'FAIL: % (no error raised)', msg; end if;
  if err not ilike p_like then raise exception 'FAIL: % (got error: %)', msg, err; end if;
  raise notice 'ok - % [%]', msg, err;
end $$;

create function tests.id(k text) returns uuid language sql as $$ select current_setting('t.' || k)::uuid $$;
create function tests.put(k text, v uuid) returns void language sql as $$ select set_config('t.' || k, v::text, false) $$;

grant execute on all functions in schema tests to anon, authenticated;

set client_min_messages = notice;

-- ---------------------------------------------------------------------------
-- 1. Signup trigger
-- ---------------------------------------------------------------------------
insert into auth.users (id, email, phone, raw_user_meta_data) values
  ('11111111-1111-1111-1111-111111111111', 'kollie@example.com', '231770000001', '{"display_name":"Kollie Electronics","community":"Sinkor","whatsapp":"+231770000001"}'),
  ('22222222-2222-2222-2222-222222222222', 'musu@example.com',   null,           '{"full_name":"Musu K."}'),
  ('33333333-3333-3333-3333-333333333333', 'stranger@example.com', 'bad phone!',  null);
select tests.put('seller', '11111111-1111-1111-1111-111111111111'),
       tests.put('buyer',  '22222222-2222-2222-2222-222222222222'),
       tests.put('other',  '33333333-3333-3333-3333-333333333333');

select tests.ok((select count(*) = 3 from public.profiles), 'signup trigger created 3 profiles');
select tests.ok((select display_name = 'Kollie Electronics' and community = 'Sinkor' and whatsapp = '+231770000001'
                   and phone = '231770000001' from public.profiles where id = tests.id('seller')),
                'display_name/community/whatsapp/phone taken from metadata');
select tests.ok((select display_name = 'Musu K.' from public.profiles where id = tests.id('buyer')), 'full_name fallback');
select tests.ok((select display_name = 'stranger' and phone is null from public.profiles where id = tests.id('other')),
                'email fallback, invalid phone dropped without failing signup');

-- ---------------------------------------------------------------------------
-- 2. Profiles privacy + column protection
-- ---------------------------------------------------------------------------
select tests.login(tests.id('seller'));
update public.profiles set bio = 'Phones & gadgets, Sinkor' where id = tests.id('seller');
select tests.ok((select bio is not null from public.profiles where id = tests.id('seller')), 'owner can update own profile');
select tests.throws($$update public.profiles set rating_avg = 5 where id = tests.id('seller')$$,
                    '%permission denied%', 'user cannot set own rating_avg');
select tests.throws($$update public.profiles set is_verified = true where id = tests.id('seller')$$,
                    '%permission denied%', 'user cannot self-verify');
update public.profiles set bio = 'hacked' where id = tests.id('buyer');
select tests.ok((select count(*) = 0 from public.profiles where id = tests.id('buyer')), 'cannot read another user''s profile row');

select tests.login(null);  -- anon
select tests.throws($$select * from public.profiles$$, '%permission denied%', 'anon cannot read profiles table');
select tests.ok((select phone is null and whatsapp = '+231770000001' and display_name = 'Kollie Electronics'
                   from public.public_profiles where id = tests.id('seller')),
                'public_profiles hides phone (show_phone=false) and shows whatsapp');
select tests.logout();
update public.profiles set show_phone = true where id = tests.id('seller');
select tests.login(null);
select tests.ok((select phone = '231770000001' from public.public_profiles where id = tests.id('seller')),
                'public_profiles shows phone once show_phone=true');

-- ---------------------------------------------------------------------------
-- 3. Listings + images
-- ---------------------------------------------------------------------------
select tests.login(tests.id('seller'));
insert into public.listings (title, description, price, currency, condition, category_id, community, lat, lng)
values ('Samsung Galaxy S21 128GB', 'Very clean, charger included', 200, 'USD', 'like_new',
        (select id from public.categories where slug = 'phones-tablets'), 'Sinkor', 6.2907, -10.7605);
select tests.put('l1', (select id from public.listings where title = 'Samsung Galaxy S21 128GB'));
select tests.ok((select seller_id = tests.id('seller') and status = 'active' and search @@ to_tsquery('simple', 'galaxy')
                   from public.listings where id = tests.id('l1')),
                'listing created with seller_id default + generated tsvector');
select tests.throws($$insert into public.listings (seller_id, title, price, category_id) values
                      (tests.id('buyer'), 'Fake listing', 1, 1)$$,
                    '%row-level security%', 'cannot create listing for someone else');
select tests.throws($$insert into public.listings (title, price, category_id, is_boosted) values ('Boost me', 1, 1, true)$$,
                    '%permission denied%', 'cannot self-boost');
select tests.throws($$update public.listings set favorite_count = 999 where id = tests.id('l1')$$,
                    '%permission denied%', 'cannot edit favorite_count');

insert into public.listing_images (listing_id, path, sort)
values (tests.id('l1'), tests.id('seller') || '/' || tests.id('l1') || '/a.jpg', 0),
       (tests.id('l1'), tests.id('seller') || '/' || tests.id('l1') || '/b.jpg', 1);
select tests.throws($$insert into public.listing_images (listing_id, path) values (tests.id('l1'), 'someone-else/x.jpg')$$,
                    '%row-level security%', 'image path must start with own user id');

select tests.login(tests.id('buyer'));
select tests.throws($$insert into public.listing_images (listing_id, path) values
                      (tests.id('l1'), tests.id('buyer') || '/x.jpg')$$,
                    '%row-level security%', 'cannot add images to someone else''s listing');
update public.listings set price = 1 where id = tests.id('l1');
select tests.ok((select price = 200 from public.listings where id = tests.id('l1')), 'cannot edit someone else''s listing');

select tests.login(null);
select tests.ok((select count(*) = 1 from public.listings where id = tests.id('l1')), 'anon can read active listing');
select tests.ok((select count(*) = 2 from public.listing_images where listing_id = tests.id('l1')), 'anon can read listing images');

-- ---------------------------------------------------------------------------
-- 4. Favorites + counter
-- ---------------------------------------------------------------------------
select tests.login(tests.id('buyer'));
insert into public.favorites (listing_id) values (tests.id('l1'));
select tests.ok((select favorite_count = 1 from public.listings where id = tests.id('l1')), 'favorite_count incremented');
delete from public.favorites where listing_id = tests.id('l1');
select tests.ok((select favorite_count = 0 from public.listings where id = tests.id('l1')), 'favorite_count decremented');
insert into public.favorites (listing_id) values (tests.id('l1'));
insert into public.favorites (listing_id) values (tests.id('l1')) on conflict do nothing;
select tests.ok((select favorite_count = 1 from public.listings where id = tests.id('l1')), 'duplicate favorite ignored');
select tests.login(tests.id('other'));
select tests.ok((select count(*) = 0 from public.favorites), 'cannot see other users'' favorites');

-- ---------------------------------------------------------------------------
-- 5. Conversations + messages
-- ---------------------------------------------------------------------------
select tests.login(tests.id('buyer'));
select tests.put('c1', (select id from public.start_conversation(tests.id('l1'))));
select tests.ok((select id from public.start_conversation(tests.id('l1'))) = tests.id('c1'),
                'start_conversation returns existing conversation');
select tests.ok((select buyer_id = tests.id('buyer') and seller_id = tests.id('seller')
                   from public.conversations where id = tests.id('c1')), 'conversation has buyer/seller');

select tests.login(tests.id('seller'));
select tests.throws($$select public.start_conversation(tests.id('l1'))$$, '%own listing%', 'seller cannot message self');
select tests.throws($$insert into public.conversations (listing_id, buyer_id, seller_id)
                      values (tests.id('l1'), tests.id('other'), tests.id('seller'))$$,
                    '%permission denied%', 'conversations cannot be inserted directly');

select tests.login(tests.id('buyer'));
insert into public.messages (conversation_id, body) values (tests.id('c1'), 'Hello, still available?');
select tests.ok((select seller_unread = 1 and buyer_unread = 0 and last_message = 'Hello, still available?'
                   and last_message_at is not null from public.conversations where id = tests.id('c1')),
                'new message updates last_message + seller_unread');

select tests.login(tests.id('seller'));
select tests.ok((select count(*) = 1 from public.messages where conversation_id = tests.id('c1')), 'seller reads messages');
insert into public.messages (conversation_id, body) values (tests.id('c1'), 'Yes, available');
select tests.ok((select buyer_unread = 1 and seller_unread = 1 from public.conversations where id = tests.id('c1')),
                'reply increments buyer_unread');
select tests.throws($$insert into public.messages (conversation_id, kind, body) values (tests.id('c1'), 'system', 'fake')$$,
                    '%row-level security%', 'users cannot send system messages');
select tests.throws($$insert into public.messages (conversation_id, sender_id, body) values (tests.id('c1'), tests.id('buyer'), 'spoof')$$,
                    '%row-level security%', 'cannot spoof sender_id');

-- RLS: non-participant
select tests.login(tests.id('other'));
select tests.ok((select count(*) = 0 from public.messages), 'non-participant sees no messages');
select tests.ok((select count(*) = 0 from public.conversations), 'non-participant sees no conversations');
select tests.throws($$insert into public.messages (conversation_id, body) values (tests.id('c1'), 'intruder')$$,
                    '%row-level security%', 'non-participant cannot post into conversation');
select tests.throws($$select public.mark_conversation_read(tests.id('c1'))$$, '%not found%',
                    'non-participant cannot mark read');
select tests.login(null);
select tests.throws($$select * from public.messages$$, '%permission denied%', 'anon cannot read messages');

-- mark read
select tests.login(tests.id('seller'));
select public.mark_conversation_read(tests.id('c1'));
select tests.ok((select seller_unread = 0 and buyer_unread = 1 from public.conversations where id = tests.id('c1')),
                'mark_conversation_read zeroes only my counter');
select tests.ok((select read_at is not null from public.messages where conversation_id = tests.id('c1') and sender_id = tests.id('buyer')),
                'mark_conversation_read sets read_at on received messages');
select tests.ok((select read_at is null from public.messages where conversation_id = tests.id('c1') and sender_id = tests.id('seller')),
                'own messages stay unread for the other side');

-- ---------------------------------------------------------------------------
-- 6. Offers
-- ---------------------------------------------------------------------------
select tests.login(tests.id('seller'));
select tests.throws($$insert into public.messages (conversation_id, kind, offer_amount) values (tests.id('c1'), 'offer', 150)$$,
                    '%only the buyer%', 'seller cannot make an offer');

select tests.login(tests.id('buyer'));
select tests.throws($$insert into public.messages (conversation_id, kind, offer_amount, offer_status)
                      values (tests.id('c1'), 'offer', 1500, 'accepted')$$,
                    '%permission denied%', 'buyer cannot pre-set offer_status');
insert into public.messages (conversation_id, kind, offer_amount) values (tests.id('c1'), 'offer', 1500);
select tests.put('o1', (select id from public.messages where kind = 'offer' order by created_at desc limit 1));
select tests.ok((select offer_status = 'pending' and offer_currency = 'USD' from public.messages where id = tests.id('o1')),
                'offer forced to pending with listing currency');
select tests.ok((select last_message = 'Offer: USD 1,500' from public.conversations where id = tests.id('c1')),
                'offer preview formatted');
select tests.throws($$select public.respond_to_offer(tests.id('o1'), true)$$, '%only the seller%', 'buyer cannot accept own offer');
select tests.throws($$update public.messages set offer_status = 'accepted' where id = tests.id('o1')$$,
                    '%permission denied%', 'offer_status not directly updatable');

select tests.login(tests.id('seller'));
select tests.ok((select offer_status = 'accepted' from public.respond_to_offer(tests.id('o1'), true)), 'seller accepts offer');
select tests.ok((select status = 'reserved' from public.listings where id = tests.id('l1')), 'accepting reserves the listing');
select tests.ok((select body = 'Offer of USD 1,500 accepted' from public.messages
                  where conversation_id = tests.id('c1') and kind = 'system'), 'system message posted');
select tests.throws($$select public.respond_to_offer(tests.id('o1'), false)$$, '%already been accepted%', 'cannot answer twice');

select tests.login(tests.id('buyer'));
insert into public.messages (conversation_id, kind, offer_amount) values (tests.id('c1'), 'offer', 170);
select tests.put('o2', (select id from public.messages where kind = 'offer' and offer_amount = 170));
select tests.login(tests.id('seller'));
select tests.ok((select offer_status = 'declined' from public.respond_to_offer(tests.id('o2'), false)), 'seller declines offer');

-- ---------------------------------------------------------------------------
-- 7. Blocks
-- ---------------------------------------------------------------------------
select tests.login(tests.id('seller'));
insert into public.blocks (blocked_id) values (tests.id('buyer'));
select tests.login(tests.id('buyer'));
select tests.throws($$insert into public.messages (conversation_id, body) values (tests.id('c1'), 'why?')$$,
                    '%row-level security%', 'blocked user cannot message');
select tests.ok((select count(*) = 0 from public.blocks), 'blocked user cannot see who blocked them');
select tests.ok((select is_blocked from public.inbox where id = tests.id('c1')), 'inbox shows is_blocked');
select tests.login(tests.id('seller'));
select tests.throws($$insert into public.messages (conversation_id, body) values (tests.id('c1'), 'bye')$$,
                    '%row-level security%', 'blocker cannot message either');
select tests.throws($$insert into public.blocks (blocked_id) values (tests.id('seller'))$$, '%blocks%', 'cannot block self');
delete from public.blocks where blocked_id = tests.id('buyer');
select tests.login(tests.id('buyer'));
insert into public.messages (conversation_id, body) values (tests.id('c1'), 'ok thanks');
select tests.ok(true, 'messaging works again after unblock');

-- ---------------------------------------------------------------------------
-- 8. Inbox view
-- ---------------------------------------------------------------------------
select tests.login(tests.id('buyer'));
select tests.ok((select my_role = 'buyer' and other_display_name = 'Kollie Electronics' and listing_title like 'Samsung%'
                   and listing_cover_path like '%/a.jpg' and unread >= 1
                   from public.inbox where id = tests.id('c1')), 'inbox row for buyer');
select tests.login(tests.id('seller'));
select tests.ok((select my_role = 'seller' and other_display_name = 'Musu K.' and unread = 3
                   from public.inbox where id = tests.id('c1')), 'inbox row for seller');
select tests.login(tests.id('other'));
select tests.ok((select count(*) = 0 from public.inbox), 'inbox empty for non-participant');

-- ---------------------------------------------------------------------------
-- 9. Reviews + rating maintenance
-- ---------------------------------------------------------------------------
select tests.login(tests.id('buyer'));
insert into public.reviews (reviewee_id, listing_id, rating, comment) values (tests.id('seller'), tests.id('l1'), 5, 'Honest seller');
select tests.ok((select rating_avg = 5 and rating_count = 1 from public.public_profiles where id = tests.id('seller')),
                'rating_avg/count updated on review insert');
select tests.throws($$insert into public.reviews (reviewee_id, listing_id, rating) values (tests.id('buyer'), tests.id('l1'), 5)$$,
                    '%row-level security%', 'cannot review yourself');
select tests.throws($$insert into public.reviews (reviewee_id, listing_id, rating) values (tests.id('seller'), tests.id('l1'), 1)$$,
                    '%reviews_reviewer_listing_uq%', 'one review per reviewer+listing');
update public.reviews set rating = 3 where reviewer_id = tests.id('buyer');
select tests.ok((select rating_avg = 3 from public.public_profiles where id = tests.id('seller')), 'rating_avg updated on edit');
select tests.login(tests.id('seller'));
insert into public.reviews (reviewee_id, listing_id, rating) values (tests.id('buyer'), tests.id('l1'), 4);
select tests.ok(true, 'seller can review buyer');
select tests.login(tests.id('other'));
select tests.throws($$insert into public.reviews (reviewee_id, listing_id, rating) values (tests.id('seller'), tests.id('l1'), 1)$$,
                    '%row-level security%', 'cannot review without a conversation');
select tests.login(tests.id('buyer'));
delete from public.reviews where reviewer_id = tests.id('buyer');
select tests.ok((select rating_avg = 0 and rating_count = 0 from public.public_profiles where id = tests.id('seller')),
                'rating reset after review delete');

-- ---------------------------------------------------------------------------
-- 10. Reports (insert-only)
-- ---------------------------------------------------------------------------
select tests.login(tests.id('other'));
insert into public.reports (listing_id, reason, details) values (tests.id('l1'), 'scam', 'asks for mobile money upfront');
insert into public.reports (reported_user_id, reason) values (tests.id('seller'), 'harassment');
select tests.throws($$select * from public.reports$$, '%permission denied%', 'reports are not readable by users');
select tests.throws($$insert into public.reports (reason) values ('spam')$$, '%reports_one_target%', 'report needs exactly one target');
select tests.logout();
select tests.ok((select count(*) = 2 from public.reports), 'reports stored');

-- ---------------------------------------------------------------------------
-- 11. Views counter
-- ---------------------------------------------------------------------------
update public.listings set status = 'active' where id = tests.id('l1');
select tests.login(null);
select tests.ok(public.increment_listing_view(tests.id('l1')) = 1, 'anon view increments');
select tests.login(tests.id('seller'));
select tests.ok(public.increment_listing_view(tests.id('l1')) = 1, 'seller''s own view not counted');

-- ---------------------------------------------------------------------------
-- 12. search_listings
-- ---------------------------------------------------------------------------
select tests.login(tests.id('seller'));
insert into public.listings (title, price, currency, condition, category_id, community, lat, lng, description) values
  ('Firman generator 3.5kVA', 57000, 'LRD', 'good',     (select id from public.categories where slug='generators-solar'), 'Sinkor',     6.2907, -10.7605, 'Runs well'),
  ('Solar panel 300W',        120,   'USD', 'new',      (select id from public.categories where slug='generators-solar'), 'Paynesville', 6.2700, -10.7000, 'Brand new'),
  ('iPhone 12 Pro',           350,   'USD', 'good',     (select id from public.categories where slug='phones-tablets'),   'Congo Town', 6.2800, -10.7400, 'Face ID works'),
  ('Old Nokia for parts',     5,     'USD', 'for_parts',(select id from public.categories where slug='phones-tablets'),   'Duala',      null,   null,     'Screen broken');
select tests.logout();
update public.listings set is_boosted = true, boosted_until = now() + interval '1 day' where title = 'Old Nokia for parts';
insert into public.listings (seller_id, title, price, category_id, is_boosted, boosted_until)
values (tests.id('seller'), 'Expired boost chair', 30, (select id from public.categories where slug='furniture'), true, now() - interval '1 day');
select tests.login(null);

select tests.ok((select total_count = 6 from public.search_listings() limit 1), 'no filters returns all 6 active listings');
select tests.ok((select title = 'Old Nokia for parts' and is_boosted from public.search_listings() limit 1), 'boosted listing first');
select tests.ok((select not is_boosted from public.search_listings() where title = 'Expired boost chair'), 'expired boost not boosted');
select tests.ok((select array_agg(title order by title) = array['Samsung Galaxy S21 128GB']
                   from public.search_listings(q => 'sams gal')), 'prefix full-text search');
select tests.ok((select count(*) = 0 from public.search_listings(q => '!!!zzz')), 'no match returns nothing');
select tests.ok((select count(*) = 3 from public.search_listings(category => (select id from public.categories where slug='phones-tablets'))),
                'category filter');
select tests.ok((select count(*) = 1 from public.search_listings(currency => 'LRD')), 'currency filter');
select tests.ok((select count(*) = 1 from public.search_listings(condition => 'new')), 'condition filter');
select tests.ok((select count(*) = 2 from public.search_listings(community => 'sinkor')), 'community filter (case-insensitive)');
-- USD-equivalent: 57000 LRD / 190 = 300 USD
select tests.ok((select price_usd = 300 from public.search_listings(q => 'firman')), 'LRD converted to USD-equivalent');
select tests.ok((select array_agg(title order by title) = array['Firman generator 3.5kVA', 'iPhone 12 Pro']
                   from public.search_listings(min_price => 250, max_price => 400)), 'price range uses USD-equivalent');
select tests.ok((select count(*) = 1 from public.search_listings(currency => 'LRD', min_price => 50000)), 'price range in given currency');
select tests.ok((select (array_agg(title))[2:3] = array['Expired boost chair', 'Solar panel 300W']
                   from public.search_listings(sort => 'price_asc')), 'price_asc: boosted first, then cheapest (USD-equivalent)');
select tests.ok((select (array_agg(title))[2] = 'iPhone 12 Pro' from public.search_listings(sort => 'price_desc')),
                'price_desc: boosted first, then most expensive');
select tests.ok((select (array_agg(title))[2] = 'Solar panel 300W'
                   from public.search_listings(sort => 'nearest', lat => 6.2705, lng => -10.7005)), 'nearest sort');
select tests.ok((select count(*) = 1 from public.search_listings(lat => 6.2705, lng => -10.7005, radius_km => 1)), 'radius filter');
select tests.ok((select count(*) = 2 and max(total_count) = 6 from public.search_listings("limit" => 2)), 'limit + total_count');
select tests.ok((select count(*) = 1 from public.search_listings("limit" => 5, "offset" => 5)), 'offset');
select tests.ok((select seller_display_name = 'Kollie Electronics' from public.search_listings(q => 'samsung')), 'seller name in card');
select tests.ok((select cover_path like '%/a.jpg' from public.search_listings(q => 'samsung')), 'cover image path in card');

select tests.login(tests.id('buyer'));
insert into public.blocks (blocked_id) values (tests.id('seller'));
select tests.ok((select count(*) = 0 from public.search_listings()), 'listings of blocked users hidden from search');
delete from public.blocks where blocked_id = tests.id('seller');

-- ---------------------------------------------------------------------------
-- 13. mark_listing_sold + visibility
-- ---------------------------------------------------------------------------
select tests.login(tests.id('buyer'));
insert into public.messages (conversation_id, kind, offer_amount) values (tests.id('c1'), 'offer', 180);
select tests.throws($$select public.mark_listing_sold(tests.id('l1'))$$, '%not found%', 'only seller can mark sold');
select tests.login(tests.id('seller'));
select tests.ok((select status = 'sold' and sold_at is not null from public.mark_listing_sold(tests.id('l1'))), 'seller marks sold');
select tests.ok((select count(*) = 0 from public.messages where kind = 'offer' and offer_status = 'pending'),
                'pending offers declined on sale');
select tests.login(null);
select tests.ok((select count(*) = 0 from public.listings where id = tests.id('l1')), 'sold listing hidden from public');
select tests.ok((select count(*) = 0 from public.search_listings(q => 'samsung')), 'sold listing not in search');
select tests.login(tests.id('buyer'));
select tests.ok((select count(*) = 1 from public.listings where id = tests.id('l1')), 'participant still sees sold listing');
select tests.ok((select count(*) = 2 from public.listing_images where listing_id = tests.id('l1')), 'participant still sees its images');
select tests.throws($$insert into public.messages (conversation_id, kind, offer_amount) values (tests.id('c1'), 'offer', 10)$$,
                    '%no longer available%', 'no offers on sold listing');
select tests.login(tests.id('other'));
select tests.throws($$select public.start_conversation(tests.id('l1'))$$, '%no longer available%', 'cannot start chat on sold listing');
select tests.login(tests.id('seller'));
update public.listings set status = 'deleted' where id = tests.id('l1');
select tests.login(tests.id('buyer'));
select tests.ok((select count(*) = 0 from public.listings where id = tests.id('l1')), 'deleted listing hidden even from participants');
select tests.ok((select listing_title is null from public.inbox where id = tests.id('c1')), 'inbox survives deleted listing');

-- ---------------------------------------------------------------------------
-- 14. Storage policies
-- ---------------------------------------------------------------------------
select tests.login(tests.id('seller'));
insert into storage.objects (bucket_id, name) values ('listing-images', tests.id('seller') || '/l/1.jpg');
insert into storage.objects (bucket_id, name) values ('avatars', tests.id('seller') || '/avatar.jpg');
select tests.throws($$insert into storage.objects (bucket_id, name) values ('listing-images', tests.id('buyer') || '/l/1.jpg')$$,
                    '%row-level security%', 'cannot upload into another user''s folder');
select tests.throws($$insert into storage.objects (bucket_id, name) values ('avatars', 'avatar.jpg')$$,
                    '%row-level security%', 'avatar must be inside own folder');
insert into storage.objects (bucket_id, name) values ('message-images', tests.id('c1') || '/' || tests.id('seller') || '/p.jpg');
select tests.login(tests.id('buyer'));
select tests.ok((select count(*) = 1 from storage.objects where bucket_id = 'message-images'), 'participant can read chat image');
delete from storage.objects where bucket_id = 'listing-images';
select tests.login(tests.id('other'));
select tests.ok((select count(*) = 0 from storage.objects where bucket_id = 'message-images'), 'non-participant cannot read chat image');
select tests.throws($$insert into storage.objects (bucket_id, name) values ('message-images', tests.id('c1') || '/' || tests.id('other') || '/p.jpg')$$,
                    '%row-level security%', 'non-participant cannot upload chat image');
select tests.login(null);
select tests.ok((select count(*) = 1 from storage.objects where bucket_id = 'listing-images'), 'anon reads listing images; buyer could not delete seller''s file');

-- chat image message
select tests.login(tests.id('seller'));
update public.listings set status = 'active' where id = tests.id('l1');
insert into public.messages (conversation_id, kind, image_path)
values (tests.id('c1'), 'image', tests.id('c1') || '/' || tests.id('seller') || '/p.jpg');
select tests.ok((select last_message = '[Photo]' from public.conversations where id = tests.id('c1')), 'image message preview');
select tests.throws($$insert into public.messages (conversation_id, kind, image_path) values (tests.id('c1'), 'image', 'x/y.jpg')$$,
                    '%must start with the conversation id%', 'image path bound to conversation');

-- ---------------------------------------------------------------------------
-- 15. Push tokens + saved searches
-- ---------------------------------------------------------------------------
select tests.login(tests.id('buyer'));
select public.register_push_token('ExponentPushToken[abc123xyz]', 'android');
select tests.login(tests.id('other'));
select public.register_push_token('ExponentPushToken[abc123xyz]', 'android');  -- same phone, new account
select tests.ok((select count(*) = 1 from public.push_tokens), 'token moved to new account');
select tests.login(tests.id('buyer'));
select tests.ok((select count(*) = 0 from public.push_tokens), 'old account no longer owns token');
insert into public.saved_searches (query, category_id, max_price, currency, community)
values ('generator', (select id from public.categories where slug='generators-solar'), 500, 'USD', 'Sinkor');
select tests.ok((select count(*) = 1 from public.saved_searches), 'saved search stored');
select tests.throws($$insert into public.saved_searches (query, min_price, max_price) values ('x', 10, 5)$$,
                    '%price_order%', 'min <= max enforced');
select tests.login(tests.id('other'));
select tests.ok((select count(*) = 0 from public.saved_searches), 'saved searches are private');

-- ---------------------------------------------------------------------------
-- 16. Misc guards
-- ---------------------------------------------------------------------------
select tests.login(tests.id('seller'));
select tests.throws($$insert into public.categories (slug, name) values ('x', 'X')$$, '%permission denied%', 'categories are read-only');
select tests.logout();
select tests.ok((select count(*) = 20 from public.categories), '20 categories seeded');
select tests.ok((select count(*) = 2 from pg_publication_tables where pubname = 'supabase_realtime'
                   and tablename in ('messages', 'conversations')), 'realtime publication has messages + conversations');
select tests.ok((select bool_and(relrowsecurity) from pg_class c join pg_namespace n on n.oid = c.relnamespace
                   where n.nspname = 'public' and c.relkind = 'r'), 'RLS enabled on every public table');

\o
\echo 'ALL TESTS PASSED'
