#!/usr/bin/env bash
# Recreate a scratch DB, apply stub + migrations in order, then run tests.
# Usage: PGHOST=/var/tmp PGPORT=5433 PGUSER=postgres ./run_local.sh
set -euo pipefail
here="$(cd "$(dirname "$0")" && pwd)"
db="${DB:-libmarket_test}"
psql -v ON_ERROR_STOP=1 -q -d postgres -c "drop database if exists $db" -c "create database $db"
psql -v ON_ERROR_STOP=1 -q -d "$db" -f "$here/00_supabase_stub.sql"
for f in "$here"/../migrations/*.sql; do
  echo "== applying $(basename "$f")"
  psql -v ON_ERROR_STOP=1 -q -d "$db" -f "$f"
done
echo "== running tests"
psql -v ON_ERROR_STOP=1 -q -d "$db" -f "$here/01_flows.sql"
