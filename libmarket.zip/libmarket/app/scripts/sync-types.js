#!/usr/bin/env node
/**
 * Copies the backend's hand-written Database types (../supabase/types.ts) into the app,
 * so the app stays self-contained for EAS Build (which only uploads this folder's repo).
 * Run after changing supabase/types.ts:  npm run sync-types
 */
const fs = require('fs');
const path = require('path');

const src = path.resolve(__dirname, '../../supabase/types.ts');
const dest = path.resolve(__dirname, '../src/types/database.ts');

if (!fs.existsSync(src)) {
  console.error(`Not found: ${src}`);
  process.exit(1);
}
fs.copyFileSync(src, dest);
console.log(`Copied ${path.relative(process.cwd(), src)} -> ${path.relative(process.cwd(), dest)}`);
