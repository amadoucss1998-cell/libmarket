import { PersistQueryClientProvider } from '@tanstack/react-query-persist-client';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { colors, spacing } from '@/constants/colors';
import { AuthProvider } from '@/hooks/useAuth';
import { persistOptions, queryClient } from '@/lib/queryClient';
import { isSupabaseConfigured } from '@/lib/supabase';

export default function RootLayout() {
  if (!isSupabaseConfigured) return <MissingConfig />;
  return (
    <SafeAreaProvider>
      <PersistQueryClientProvider client={queryClient} persistOptions={persistOptions}>
        <AuthProvider>
          <StatusBar style="dark" />
          <Stack
            screenOptions={{
              headerTintColor: colors.secondary,
              headerTitleStyle: { fontWeight: '800', color: colors.text },
              headerShadowVisible: false,
              contentStyle: { backgroundColor: colors.background },
              headerBackButtonDisplayMode: 'minimal',
            }}
          >
            <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
            <Stack.Screen name="listing/[id]" options={{ title: '', headerTransparent: false }} />
            <Stack.Screen name="listing/edit/[id]" options={{ title: 'Edit item' }} />
            <Stack.Screen name="chat/[id]" options={{ title: 'Chat' }} />
            <Stack.Screen name="user/[id]" options={{ title: 'Profile' }} />
            <Stack.Screen name="auth/login" options={{ title: 'Log in', presentation: 'modal' }} />
            <Stack.Screen name="auth/verify" options={{ title: 'Enter code' }} />
            <Stack.Screen name="auth/profile-setup" options={{ title: 'Your profile' }} />
            <Stack.Screen name="report" options={{ title: 'Report', presentation: 'modal' }} />
            <Stack.Screen name="review" options={{ title: 'Leave a review', presentation: 'modal' }} />
            <Stack.Screen name="settings/index" options={{ title: 'Settings' }} />
            <Stack.Screen name="settings/blocked" options={{ title: 'Blocked users' }} />
            <Stack.Screen name="safety" options={{ title: 'Stay safe' }} />
          </Stack>
        </AuthProvider>
      </PersistQueryClientProvider>
    </SafeAreaProvider>
  );
}

/** Shown when EXPO_PUBLIC_SUPABASE_URL / ANON_KEY are missing, instead of crashing. */
function MissingConfig() {
  return (
    <ScrollView contentContainerStyle={{ flexGrow: 1, justifyContent: 'center', padding: spacing.xl, backgroundColor: colors.white }}>
      <Text style={{ fontSize: 22, fontWeight: '800', color: colors.primary, marginBottom: spacing.md }}>LibMarket setup needed</Text>
      <Text style={{ fontSize: 15, color: colors.text, lineHeight: 22 }}>
        Create a file named .env in the app folder (copy .env.example) and set EXPO_PUBLIC_SUPABASE_URL and
        EXPO_PUBLIC_SUPABASE_ANON_KEY from your Supabase project (Settings → API). Then restart Expo with
        "npx expo start -c".
      </Text>
      <View style={{ height: spacing.xl }} />
    </ScrollView>
  );
}
