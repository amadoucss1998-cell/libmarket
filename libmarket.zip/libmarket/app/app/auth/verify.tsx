import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Button } from '@/components/ui';
import { colors, radius, spacing } from '@/constants/colors';
import { finishSignIn } from '@/lib/authFlow';
import { errorMessage, supabase } from '@/lib/supabase';

const RESEND_SECONDS = 60;

export default function VerifyScreen() {
  const { phone } = useLocalSearchParams<{ phone: string }>();
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [left, setLeft] = useState(RESEND_SECONDS);

  useEffect(() => {
    if (left <= 0) return;
    const t = setTimeout(() => setLeft((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [left]);

  const verify = async (token = code) => {
    if (token.length !== 6 || !phone) return;
    setLoading(true);
    const { data, error } = await supabase.auth.verifyOtp({ phone, token, type: 'sms' });
    setLoading(false);
    if (error || !data.user) {
      Alert.alert('Wrong or expired code', errorMessage(error, 'Please try again.'));
      return;
    }
    await finishSignIn(data.user.id, 2);
  };

  const resend = async () => {
    if (!phone) return;
    const { error } = await supabase.auth.signInWithOtp({ phone });
    if (error) Alert.alert('Could not resend', errorMessage(error));
    else setLeft(RESEND_SECONDS);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Enter the 6-digit code</Text>
      <Text style={styles.subtitle}>Sent by SMS to {phone}</Text>
      <TextInput
        value={code}
        onChangeText={(t) => {
          const digits = t.replace(/\D/g, '').slice(0, 6);
          setCode(digits);
          if (digits.length === 6) verify(digits);
        }}
        keyboardType="number-pad"
        textContentType="oneTimeCode"
        autoComplete="sms-otp"
        maxLength={6}
        autoFocus
        style={styles.code}
        placeholder="••••••"
        placeholderTextColor={colors.textLight}
        accessibilityLabel="Verification code"
      />
      <Button title="Verify" onPress={() => verify()} loading={loading} disabled={code.length !== 6} />
      <View style={styles.row}>
        {left > 0 ? (
          <Text style={styles.muted}>Resend code in {left}s</Text>
        ) : (
          <Pressable onPress={resend} hitSlop={10} accessibilityRole="button">
            <Text style={styles.link}>Resend code</Text>
          </Pressable>
        )}
        <Pressable onPress={() => router.back()} hitSlop={10} accessibilityRole="button">
          <Text style={styles.link}>Change number</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.white, padding: spacing.xl },
  title: { fontSize: 22, fontWeight: '800', color: colors.text },
  subtitle: { color: colors.textMuted, marginTop: 4, marginBottom: spacing.xl },
  code: {
    fontSize: 32,
    letterSpacing: 12,
    textAlign: 'center',
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    minHeight: 64,
    marginBottom: spacing.lg,
    color: colors.text,
    fontWeight: '800',
  },
  row: { flexDirection: 'row', justifyContent: 'space-between', marginTop: spacing.lg, minHeight: 44, alignItems: 'center' },
  muted: { color: colors.textMuted },
  link: { color: colors.secondary, fontWeight: '700' },
});
