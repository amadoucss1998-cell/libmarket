import { router } from 'expo-router';
import React, { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Button, Icon, Segmented, TextField } from '@/components/ui';
import { colors, spacing } from '@/constants/colors';
import { finishSignIn } from '@/lib/authFlow';
import { isValidPhone, normalizeLiberianPhone } from '@/lib/format';
import { errorMessage, supabase } from '@/lib/supabase';

type Mode = 'phone' | 'email';
type EmailMode = 'login' | 'signup';

export default function LoginScreen() {
  const [mode, setMode] = useState<Mode>('phone');
  const [emailMode, setEmailMode] = useState<EmailMode>('login');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);

  const sendCode = async () => {
    const full = normalizeLiberianPhone(phone);
    if (!isValidPhone(full) || full.replace(/\D/g, '').length < 11) {
      Alert.alert('Check your number', 'Enter your Liberian mobile number, e.g. 0770 123 456.');
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.signInWithOtp({ phone: full });
    setLoading(false);
    if (error) {
      Alert.alert('Could not send code', errorMessage(error));
      return;
    }
    router.push(`/auth/verify?phone=${encodeURIComponent(full)}`);
  };

  const emailSubmit = async () => {
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) return Alert.alert('Check your email address');
    if (password.length < 6) return Alert.alert('Password too short', 'Use at least 6 characters.');
    if (emailMode === 'signup' && name.trim().length < 1) return Alert.alert('Enter your name');
    setLoading(true);
    try {
      if (emailMode === 'login') {
        const { data, error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error) throw error;
        await finishSignIn(data.user.id, 1);
      } else {
        const { data, error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { data: { display_name: name.trim() } },
        });
        if (error) throw error;
        if (!data.session || !data.user) {
          Alert.alert('Check your email', 'We sent you a link to confirm your account. Then come back and log in.');
          setEmailMode('login');
          return;
        }
        await finishSignIn(data.user.id, 1);
      }
    } catch (e) {
      Alert.alert(emailMode === 'login' ? 'Could not log in' : 'Could not sign up', errorMessage(e));
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: colors.white }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <Text style={styles.brand}>
          <Text style={{ color: colors.primary }}>Lib</Text>
          <Text style={{ color: colors.secondary }}>Market</Text>
        </Text>
        <Text style={styles.tagline}>Buy and sell near you. Chat, call or WhatsApp.</Text>

        {mode === 'phone' ? (
          <>
            <TextField
              label="Phone number"
              value={phone}
              onChangeText={setPhone}
              placeholder="0770 123 456"
              keyboardType="phone-pad"
              textContentType="telephoneNumber"
              autoComplete="tel"
              prefix="+231"
              hint="We'll text you a 6-digit code."
              autoFocus
            />
            <Button title="Send code" icon="message-text-outline" onPress={sendCode} loading={loading} />
            <Pressable onPress={() => setMode('email')} style={styles.switch} accessibilityRole="button">
              <Icon name="email-outline" size={18} color={colors.secondary} />
              <Text style={styles.switchText}>Use email instead</Text>
            </Pressable>
          </>
        ) : (
          <>
            <Segmented<EmailMode>
              options={[
                { value: 'login', label: 'Log in' },
                { value: 'signup', label: 'Create account' },
              ]}
              value={emailMode}
              onChange={setEmailMode}
            />
            <View style={{ height: spacing.lg }} />
            {emailMode === 'signup' ? (
              <TextField label="Your name" value={name} onChangeText={setName} placeholder="e.g. Musu K." maxLength={60} autoComplete="name" />
            ) : null}
            <TextField
              label="Email"
              value={email}
              onChangeText={setEmail}
              placeholder="you@example.com"
              keyboardType="email-address"
              autoCapitalize="none"
              autoComplete="email"
            />
            <TextField
              label="Password"
              value={password}
              onChangeText={setPassword}
              placeholder="At least 6 characters"
              secureTextEntry
              autoCapitalize="none"
              autoComplete={emailMode === 'login' ? 'current-password' : 'new-password'}
            />
            <Button title={emailMode === 'login' ? 'Log in' : 'Create account'} onPress={emailSubmit} loading={loading} />
            <Pressable onPress={() => setMode('phone')} style={styles.switch} accessibilityRole="button">
              <Icon name="cellphone" size={18} color={colors.secondary} />
              <Text style={styles.switchText}>Use phone number instead</Text>
            </Pressable>
          </>
        )}

        <Text style={styles.terms}>
          By continuing you agree to LibMarket's Terms and Privacy Policy, and to follow our safety rules.
        </Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  content: { padding: spacing.xl, paddingTop: spacing.xl },
  brand: { fontSize: 34, fontWeight: '900', textAlign: 'center' },
  tagline: { textAlign: 'center', color: colors.textMuted, marginTop: 4, marginBottom: spacing.xl },
  switch: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, minHeight: 48, marginTop: spacing.sm },
  switchText: { color: colors.secondary, fontWeight: '700' },
  terms: { fontSize: 12, color: colors.textMuted, textAlign: 'center', marginTop: spacing.xl, lineHeight: 18 },
});
