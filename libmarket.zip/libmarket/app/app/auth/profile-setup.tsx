import { router, Stack, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import { CommunityPicker } from '@/components/CommunityPicker';
import { Picker } from '@/components/FiltersSheet';
import { Avatar, Button, Icon, Loading, TextField } from '@/components/ui';
import { colors, spacing } from '@/constants/colors';
import { cityForCommunity } from '@/constants/communities';
import { useAuth } from '@/hooks/useAuth';
import { updateMyProfile, uploadAvatar } from '@/lib/api';
import { closeAuth } from '@/lib/authFlow';
import { isValidPhone, normalizeLiberianPhone } from '@/lib/format';
import { chooseImageSource, pickImages } from '@/lib/images';
import { errorMessage } from '@/lib/supabase';

export default function ProfileSetupScreen() {
  const { onboarding, depth } = useLocalSearchParams<{ onboarding?: string; depth?: string }>();
  const { user, profile, profileLoading, refreshProfile } = useAuth();
  const [name, setName] = useState('');
  const [community, setCommunity] = useState<string | null>(null);
  const [whatsapp, setWhatsapp] = useState('');
  const [showWhatsapp, setShowWhatsapp] = useState(true);
  const [phone, setPhone] = useState('');
  const [showPhone, setShowPhone] = useState(false);
  const [bio, setBio] = useState('');
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (profile && !loaded) {
      const authPhone = user?.phone ? `+${user.phone.replace(/^\+/, '')}` : '';
      setName(profile.display_name === 'LibMarket user' ? '' : profile.display_name);
      setCommunity(profile.community);
      setWhatsapp(profile.whatsapp ?? authPhone);
      setShowWhatsapp(profile.show_whatsapp);
      setPhone(profile.phone ?? authPhone);
      setShowPhone(profile.show_phone);
      setBio(profile.bio ?? '');
      setAvatarUrl(profile.avatar_url);
      setLoaded(true);
    }
  }, [profile, loaded, user]);

  if (!user) return <Loading />;
  if (profileLoading && !loaded) return <Loading />;

  const changeAvatar = () =>
    chooseImageSource(async (source) => {
      const [img] = await pickImages(source, 1);
      if (!img) return;
      setUploading(true);
      try {
        const url = await uploadAvatar(user.id, img);
        await updateMyProfile(user.id, { avatar_url: url });
        setAvatarUrl(url);
        refreshProfile();
      } catch (e) {
        Alert.alert('Could not upload photo', errorMessage(e));
      } finally {
        setUploading(false);
      }
    });

  const save = async () => {
    const wa = whatsapp.trim() ? normalizeLiberianPhone(whatsapp) : null;
    const ph = phone.trim() ? normalizeLiberianPhone(phone) : null;
    if (name.trim().length < 1) return Alert.alert('Enter your name');
    if (!community) return Alert.alert('Choose your community', 'It helps buyers near you find your items.');
    if (wa && !isValidPhone(wa)) return Alert.alert('Check your WhatsApp number');
    if (ph && !isValidPhone(ph)) return Alert.alert('Check your phone number');
    if (showPhone && !ph) return Alert.alert('Add a phone number', 'Or turn off "Allow calls".');
    setSaving(true);
    try {
      await updateMyProfile(user.id, {
        display_name: name.trim().slice(0, 60),
        community,
        city: cityForCommunity(community),
        whatsapp: wa,
        show_whatsapp: showWhatsapp,
        phone: ph,
        show_phone: showPhone,
        bio: bio.trim() || null,
      });
      await refreshProfile();
      if (onboarding) closeAuth(Number(depth) || 1);
      else router.back();
    } catch (e) {
      Alert.alert('Could not save profile', errorMessage(e));
    } finally {
      setSaving(false);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: colors.white }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Stack.Screen options={{ title: onboarding ? 'Set up your profile' : 'Edit profile', headerBackVisible: !onboarding }} />
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <Pressable onPress={changeAvatar} style={styles.avatarWrap} accessibilityRole="button" accessibilityLabel="Change profile photo">
          <Avatar uri={avatarUrl} name={name || profile?.display_name} size={96} />
          <View style={styles.cameraBadge}>
            <Icon name={uploading ? 'progress-upload' : 'camera'} size={18} color={colors.white} />
          </View>
          <Text style={styles.avatarHint}>{uploading ? 'Uploading…' : 'Add a photo (optional)'}</Text>
        </Pressable>

        <TextField label="Your name" value={name} onChangeText={setName} placeholder="e.g. Musu K." maxLength={60} autoComplete="name" />

        <Text style={styles.label}>Your community</Text>
        <Picker value={community} placeholder="Choose community" icon="map-marker-outline" onPress={() => setPickerOpen(true)} />
        <Text style={styles.hint}>Used as the default location for your items and your home feed.</Text>

        <TextField
          label="WhatsApp number"
          value={whatsapp}
          onChangeText={setWhatsapp}
          placeholder="0770 123 456"
          keyboardType="phone-pad"
          style={{ marginTop: spacing.lg }}
        />
        <ToggleRow
          label="Show WhatsApp button on my items"
          hint="Buyers can message you on WhatsApp"
          value={showWhatsapp}
          onChange={setShowWhatsapp}
        />

        <TextField
          label="Phone number for calls"
          value={phone}
          onChangeText={setPhone}
          placeholder="0770 123 456"
          keyboardType="phone-pad"
          style={{ marginTop: spacing.md }}
        />
        <ToggleRow label="Allow calls" hint="Show a Call button to logged-in buyers" value={showPhone} onChange={setShowPhone} />

        <TextField
          label="About you (optional)"
          value={bio}
          onChangeText={setBio}
          placeholder="e.g. Selling quality used phones in Sinkor"
          multiline
          maxLength={500}
          counter
          style={{ marginTop: spacing.md }}
        />

        <Button title={onboarding ? 'Continue' : 'Save'} onPress={save} loading={saving} />
      </ScrollView>
      <CommunityPicker visible={pickerOpen} onClose={() => setPickerOpen(false)} selected={community} onSelect={setCommunity} />
    </KeyboardAvoidingView>
  );
}

function ToggleRow({ label, hint, value, onChange }: { label: string; hint: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <View style={styles.toggle}>
      <View style={{ flex: 1 }}>
        <Text style={styles.toggleLabel}>{label}</Text>
        <Text style={styles.hint}>{hint}</Text>
      </View>
      <Switch
        value={value}
        onValueChange={onChange}
        trackColor={{ true: colors.primary, false: colors.border }}
        thumbColor={colors.white}
        accessibilityLabel={label}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  content: { padding: spacing.lg, paddingBottom: 80 },
  avatarWrap: { alignItems: 'center', marginBottom: spacing.xl },
  cameraBadge: {
    position: 'absolute',
    top: 66,
    left: '55%',
    backgroundColor: colors.primary,
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.white,
  },
  avatarHint: { color: colors.secondary, marginTop: spacing.sm, fontWeight: '600' },
  label: { fontSize: 14, fontWeight: '600', color: colors.text, marginBottom: 6 },
  hint: { fontSize: 12, color: colors.textMuted, marginTop: 4 },
  toggle: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, minHeight: 52 },
  toggleLabel: { fontSize: 15, fontWeight: '600', color: colors.text },
});
