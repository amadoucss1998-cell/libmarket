import { router, useLocalSearchParams } from 'expo-router';
import React, { useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Button, EmptyState, Icon, TextField } from '@/components/ui';
import { colors, radius, spacing } from '@/constants/colors';
import { REPORT_REASONS } from '@/constants/options';
import { useAuth } from '@/hooks/useAuth';
import { submitReport } from '@/lib/api';
import { errorMessage } from '@/lib/supabase';
import type { ReportReason } from '@/types/database';

export default function ReportScreen() {
  const { listingId, userId } = useLocalSearchParams<{ listingId?: string; userId?: string }>();
  const { user } = useAuth();
  const [reason, setReason] = useState<ReportReason | null>(null);
  const [details, setDetails] = useState('');
  const [sending, setSending] = useState(false);

  if (!user) {
    return (
      <EmptyState
        icon="flag-outline"
        title="Log in to report"
        action={{ label: 'Log in', onPress: () => router.replace('/auth/login') }}
      />
    );
  }
  if (!listingId && !userId) return <EmptyState title="Nothing to report" />;

  const isListing = !!listingId;
  const reasons = REPORT_REASONS.filter((r) => (isListing ? r.forListing : r.forUser));

  const submit = async () => {
    if (!reason) return;
    setSending(true);
    try {
      const d = details.trim() || null;
      await submitReport(
        isListing ? { listing_id: listingId!, reason, details: d } : { reported_user_id: userId!, reason, details: d },
      );
      Alert.alert('Thank you', 'Our team will review your report. You can also block this user.', [{ text: 'OK', onPress: () => router.back() }]);
    } catch (e) {
      Alert.alert('Could not send report', errorMessage(e));
    } finally {
      setSending(false);
    }
  };

  return (
    <ScrollView style={{ backgroundColor: colors.white }} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
      <Text style={styles.title}>{isListing ? 'What is wrong with this item?' : 'Why are you reporting this user?'}</Text>
      <View style={{ gap: spacing.sm, marginVertical: spacing.lg }}>
        {reasons.map((r) => {
          const selected = reason === r.value;
          return (
            <Pressable
              key={r.value}
              onPress={() => setReason(r.value)}
              accessibilityRole="radio"
              accessibilityState={{ checked: selected }}
              style={[styles.option, selected && styles.optionSelected]}
            >
              <Icon name={selected ? 'radiobox-marked' : 'radiobox-blank'} size={22} color={selected ? colors.primary : colors.textLight} />
              <Text style={styles.optionText}>{r.label}</Text>
            </Pressable>
          );
        })}
      </View>
      <TextField
        label="Details (optional)"
        value={details}
        onChangeText={setDetails}
        placeholder="e.g. Asked me to send MoMo before meeting"
        multiline
        maxLength={1000}
        counter
      />
      <Button title="Send report" icon="flag-outline" onPress={submit} disabled={!reason} loading={sending} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { padding: spacing.lg, paddingBottom: 60 },
  title: { fontSize: 18, fontWeight: '800', color: colors.text },
  option: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    minHeight: 52,
    paddingHorizontal: spacing.md,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
  },
  optionSelected: { borderColor: colors.primary, backgroundColor: colors.primarySoft },
  optionText: { fontSize: 16, color: colors.text },
});
