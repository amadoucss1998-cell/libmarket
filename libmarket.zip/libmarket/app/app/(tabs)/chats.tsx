import { Image } from 'expo-image';
import { router } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { FlatList, Pressable, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { Avatar, EmptyState, ErrorState, Icon, Loading, OfflineBanner, Segmented, Skeleton, VerifiedTick } from '@/components/ui';
import { colors, radius, spacing } from '@/constants/colors';
import { useAuth } from '@/hooks/useAuth';
import { useInbox } from '@/hooks/useInbox';
import { formatPrice, timeAgo } from '@/lib/format';
import { errorMessage, listingImageUrl } from '@/lib/supabase';
import type { InboxRow } from '@/types/database';

type Filter = 'all' | 'buying' | 'selling';

export default function ChatsScreen() {
  const { user, initializing } = useAuth();
  const inbox = useInbox();
  const [filter, setFilter] = useState<Filter>('all');

  const rows = useMemo(
    () => inbox.rows.filter((r) => filter === 'all' || (filter === 'buying' ? r.my_role === 'buyer' : r.my_role === 'seller')),
    [inbox.rows, filter],
  );

  if (initializing) return <Loading />;
  if (!user) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.white }}>
        <EmptyState
          icon="chat-outline"
          title="Your chats live here"
          message="Log in to message sellers, make offers and get replies."
          action={{ label: 'Log in', onPress: () => router.push('/auth/login') }}
        />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.white }}>
      <OfflineBanner />
      <View style={{ padding: spacing.md, paddingBottom: spacing.sm }}>
        <Segmented<Filter>
          options={[
            { value: 'all', label: 'All' },
            { value: 'buying', label: 'Buying' },
            { value: 'selling', label: 'Selling' },
          ]}
          value={filter}
          onChange={setFilter}
        />
      </View>
      {inbox.isLoading ? (
        <View style={{ padding: spacing.md, gap: spacing.lg }}>
          {[0, 1, 2, 3, 4].map((i) => (
            <View key={i} style={{ flexDirection: 'row', gap: spacing.md, alignItems: 'center' }}>
              <Skeleton style={{ width: 56, height: 56, borderRadius: radius.md }} />
              <View style={{ flex: 1, gap: 8 }}>
                <Skeleton style={{ width: '50%', height: 14 }} />
                <Skeleton style={{ width: '80%', height: 12 }} />
              </View>
            </View>
          ))}
        </View>
      ) : (
        <FlatList
          data={rows}
          keyExtractor={(r) => r.id}
          renderItem={({ item }) => <InboxItem row={item} />}
          ItemSeparatorComponent={() => <View style={styles.sep} />}
          refreshControl={<RefreshControl refreshing={inbox.isRefetching} onRefresh={() => inbox.refetch()} colors={[colors.primary]} />}
          contentContainerStyle={rows.length === 0 ? { flexGrow: 1 } : undefined}
          ListEmptyComponent={
            inbox.isError ? (
              <ErrorState message={errorMessage(inbox.error)} onRetry={() => inbox.refetch()} />
            ) : (
              <EmptyState
                icon="chat-outline"
                title="No chats yet"
                message={filter === 'selling' ? 'When buyers message you about your items, they appear here.' : 'Find something you like and tap "Chat".'}
                action={{ label: 'Browse items', onPress: () => router.push('/') }}
              />
            )
          }
        />
      )}
    </View>
  );
}

function InboxItem({ row }: { row: InboxRow }) {
  const cover = listingImageUrl(row.listing_cover_path, true);
  const unread = row.unread > 0;
  return (
    <Pressable
      onPress={() => router.push(`/chat/${row.id}`)}
      accessibilityRole="button"
      accessibilityLabel={`Chat with ${row.other_display_name ?? 'user'} about ${row.listing_title ?? 'a removed item'}${unread ? `, ${row.unread} unread` : ''}`}
      style={({ pressed }) => [styles.item, pressed && { backgroundColor: colors.background }]}
    >
      <View>
        {cover ? (
          <Image source={{ uri: cover }} style={styles.thumb} contentFit="cover" cachePolicy="disk" />
        ) : (
          <View style={[styles.thumb, { alignItems: 'center', justifyContent: 'center' }]}>
            <Icon name="image-off-outline" size={22} color={colors.textLight} />
          </View>
        )}
        <View style={styles.avatarPos}>
          <Avatar uri={row.other_avatar_url} name={row.other_display_name} size={26} />
        </View>
      </View>
      <View style={{ flex: 1, gap: 2 }}>
        <View style={styles.rowBetween}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, flex: 1 }}>
            <Text style={[styles.name, unread && { fontWeight: '800' }]} numberOfLines={1}>
              {row.other_display_name ?? 'LibMarket user'}
            </Text>
            {row.other_is_verified ? <VerifiedTick size={14} /> : null}
          </View>
          <Text style={styles.time}>{timeAgo(row.last_message_at ?? row.created_at)}</Text>
        </View>
        <Text style={styles.listing} numberOfLines={1}>
          {row.my_role === 'seller' ? 'Selling · ' : ''}
          {row.listing_title ?? 'Item removed'}
          {row.listing_price != null && row.listing_currency ? ` · ${formatPrice(row.listing_price, row.listing_currency)}` : ''}
          {row.listing_status === 'sold' ? ' · SOLD' : row.listing_status === 'reserved' ? ' · Reserved' : ''}
        </Text>
        <View style={styles.rowBetween}>
          <Text style={[styles.preview, unread && { color: colors.text, fontWeight: '700' }]} numberOfLines={1}>
            {row.is_blocked ? 'Blocked' : row.last_message ?? 'No messages yet'}
          </Text>
          {unread ? (
            <View style={styles.unread}>
              <Text style={styles.unreadText}>{row.unread > 99 ? '99+' : row.unread}</Text>
            </View>
          ) : null}
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  item: { flexDirection: 'row', gap: spacing.md, paddingHorizontal: spacing.md, paddingVertical: spacing.md, alignItems: 'center' },
  thumb: { width: 60, height: 60, borderRadius: radius.md, backgroundColor: colors.skeleton },
  avatarPos: { position: 'absolute', right: -6, bottom: -6, borderWidth: 2, borderColor: colors.white, borderRadius: 15 },
  rowBetween: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: spacing.sm },
  name: { fontSize: 16, fontWeight: '600', color: colors.text, flexShrink: 1 },
  time: { fontSize: 12, color: colors.textMuted },
  listing: { fontSize: 13, color: colors.secondary },
  preview: { fontSize: 14, color: colors.textMuted, flex: 1 },
  unread: {
    minWidth: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 6,
  },
  unreadText: { color: colors.white, fontSize: 12, fontWeight: '800' },
  sep: { height: StyleSheet.hairlineWidth, backgroundColor: colors.border, marginLeft: 88 },
});
