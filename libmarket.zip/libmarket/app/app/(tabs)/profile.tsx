import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { router } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { Alert, FlatList, Pressable, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { cardFromListing, type CardData } from '@/components/ListingCard';
import { ListingGrid } from '@/components/ListingGrid';
import {
  Avatar,
  Badge,
  Button,
  EmptyState,
  ErrorState,
  Icon,
  IconButton,
  Loading,
  Segmented,
  Stars,
  VerifiedTick,
} from '@/components/ui';
import { colors, radius, spacing } from '@/constants/colors';
import { useAuth } from '@/hooks/useAuth';
import { useOwnerListingActions } from '@/hooks/useListingActions';
import { useCategories } from '@/hooks/useReferenceData';
import { deleteSavedSearch, fetchFavorites, fetchMyListings, fetchSavedSearches } from '@/lib/api';
import { formatPrice, monthYear } from '@/lib/format';
import { qk } from '@/lib/queryClient';
import { errorMessage } from '@/lib/supabase';
import type { SavedSearchRow } from '@/types/database';

type Tab = 'selling' | 'sold' | 'saved' | 'searches';

export default function ProfileScreen() {
  const { user, profile, initializing } = useAuth();
  const [tab, setTab] = useState<Tab>('selling');

  if (initializing) return <Loading />;
  if (!user) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.white }}>
        <EmptyState
          icon="account-circle-outline"
          title="Welcome to LibMarket"
          message="Log in to sell items, chat with buyers and sellers, and save things you like."
          action={{ label: 'Log in or sign up', onPress: () => router.push('/auth/login') }}
        />
        <View style={{ alignItems: 'center', paddingBottom: spacing.xl }}>
          <Button title="Safety tips" variant="ghost" icon="shield-check-outline" onPress={() => router.push('/safety')} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.white }} edges={['top']}>
      <View style={styles.header}>
        <Avatar uri={profile?.avatar_url} name={profile?.display_name} size={64} />
        <View style={{ flex: 1, gap: 3 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
            <Text style={styles.name} numberOfLines={1}>
              {profile?.display_name ?? '…'}
            </Text>
            {profile?.is_verified ? <VerifiedTick /> : null}
          </View>
          {profile && profile.rating_count > 0 ? (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
              <Stars value={Number(profile.rating_avg)} />
              <Text style={styles.meta}>({profile.rating_count})</Text>
            </View>
          ) : null}
          <Text style={styles.meta} numberOfLines={1}>
            {profile?.community ?? 'No community set'}
            {profile ? ` · since ${monthYear(profile.created_at)}` : ''}
          </Text>
          <Pressable onPress={() => router.push(`/user/${user.id}`)} hitSlop={8}>
            <Text style={styles.link}>View public profile ›</Text>
          </Pressable>
        </View>
        <IconButton name="cog-outline" label="Settings" onPress={() => router.push('/settings')} color={colors.secondary} />
      </View>
      <View style={{ paddingHorizontal: spacing.md, paddingBottom: spacing.sm }}>
        <Segmented<Tab>
          options={[
            { value: 'selling', label: 'Selling' },
            { value: 'sold', label: 'Sold' },
            { value: 'saved', label: 'Saved' },
            { value: 'searches', label: 'Searches' },
          ]}
          value={tab}
          onChange={setTab}
        />
      </View>
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        {tab === 'selling' || tab === 'sold' ? <MyListings userId={user.id} sold={tab === 'sold'} /> : null}
        {tab === 'saved' ? <SavedItems userId={user.id} /> : null}
        {tab === 'searches' ? <SavedSearches userId={user.id} /> : null}
      </View>
    </SafeAreaView>
  );
}

function MyListings({ userId, sold }: { userId: string; sold: boolean }) {
  const q = useQuery({ queryKey: qk.myListings(userId), queryFn: () => fetchMyListings(userId) });
  const { openMenu } = useOwnerListingActions();
  const rows = useMemo(() => (q.data ?? []).filter((l) => (sold ? l.status === 'sold' : l.status !== 'sold')), [q.data, sold]);
  const byId = useMemo(() => new Map(rows.map((r) => [r.id, r])), [rows]);
  const items = useMemo(() => rows.map(cardFromListing), [rows]);

  const renderFooter = (item: CardData) => {
    const l = byId.get(item.id);
    if (!l) return null;
    return (
      <View style={{ marginTop: 6, gap: 6 }}>
        <View style={{ flexDirection: 'row', gap: 10 }}>
          <Stat icon="eye-outline" value={l.view_count} label="views" />
          <Stat icon="heart-outline" value={l.favorite_count} label="saves" />
        </View>
        <Button title="Manage" small variant="outline" icon="dots-horizontal" onPress={() => openMenu(l)} />
      </View>
    );
  };

  return (
    <ListingGrid
      items={items}
      loading={q.isLoading}
      refreshing={q.isRefetching}
      onRefresh={() => q.refetch()}
      renderFooter={renderFooter}
      onLongPressItem={(i) => {
        const l = byId.get(i.id);
        if (l) openMenu(l);
      }}
      empty={
        q.isError ? (
          <ErrorState message={errorMessage(q.error)} onRetry={() => q.refetch()} />
        ) : sold ? (
          <EmptyState icon="check-circle-outline" title="No sold items yet" message="Items you mark as sold show up here." />
        ) : (
          <EmptyState
            icon="storefront-outline"
            title="You're not selling anything yet"
            message="Snap a photo and post your first item in under a minute."
            action={{ label: 'Sell an item', onPress: () => router.push('/sell') }}
          />
        )
      }
    />
  );
}

function Stat({ icon, value, label }: { icon: string; value: number; label: string }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 3 }} accessibilityLabel={`${value} ${label}`}>
      <Icon name={icon} size={14} color={colors.textMuted} />
      <Text style={{ fontSize: 12, color: colors.textMuted }}>{value}</Text>
    </View>
  );
}

function SavedItems({ userId }: { userId: string }) {
  const q = useQuery({ queryKey: qk.favorites(userId), queryFn: fetchFavorites });
  const items = useMemo(
    () =>
      (q.data ?? [])
        .filter((f) => f.listing && f.listing.status !== 'deleted')
        .map((f) => cardFromListing(f.listing!)),
    [q.data],
  );
  const removed = (q.data ?? []).filter((f) => !f.listing || f.listing.status === 'deleted').length;
  return (
    <ListingGrid
      items={items}
      loading={q.isLoading}
      refreshing={q.isRefetching}
      onRefresh={() => q.refetch()}
      header={removed > 0 ? <Text style={styles.note}>{removed} saved item(s) were removed by the seller.</Text> : null}
      empty={
        q.isError ? (
          <ErrorState message={errorMessage(q.error)} onRetry={() => q.refetch()} />
        ) : (
          <EmptyState icon="heart-outline" title="No saved items" message="Tap the heart on any item to save it for later." />
        )
      }
    />
  );
}

function SavedSearches({ userId }: { userId: string }) {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: qk.savedSearches(userId), queryFn: fetchSavedSearches });
  const { byId } = useCategories();
  const del = useMutation({
    mutationFn: deleteSavedSearch,
    onSuccess: () => qc.invalidateQueries({ queryKey: qk.savedSearches(userId) }),
    onError: (e) => Alert.alert('Could not delete', errorMessage(e)),
  });

  const describe = (s: SavedSearchRow) => {
    const parts: string[] = [];
    if (s.category_id != null) parts.push(byId.get(s.category_id)?.name ?? 'Category');
    if (s.community) parts.push(s.community);
    const unit = s.currency ?? 'USD';
    if (s.min_price != null || s.max_price != null) {
      parts.push(
        `${s.min_price != null ? formatPrice(s.min_price, unit, { freeLabel: false }) : 'any'} – ${
          s.max_price != null ? formatPrice(s.max_price, unit, { freeLabel: false }) : 'any'
        }`,
      );
    } else if (s.currency) parts.push(s.currency);
    return parts.join(' · ') || 'All items';
  };

  const open = (s: SavedSearchRow) => {
    const p = new URLSearchParams({ ts: String(Date.now()) });
    if (s.query) p.set('q', s.query);
    if (s.category_id != null) p.set('category', String(s.category_id));
    if (s.min_price != null) p.set('minPrice', String(s.min_price));
    if (s.max_price != null) p.set('maxPrice', String(s.max_price));
    if (s.currency) p.set('currency', s.currency);
    if (s.community) p.set('community', s.community);
    router.push(`/search?${p.toString()}`);
  };

  if (q.isLoading) return <Loading />;
  return (
    <FlatList
      data={q.data ?? []}
      keyExtractor={(s) => s.id}
      contentContainerStyle={{ padding: spacing.md, gap: spacing.sm, flexGrow: 1 }}
      refreshControl={<RefreshControl refreshing={q.isRefetching} onRefresh={() => q.refetch()} colors={[colors.primary]} />}
      renderItem={({ item }) => (
        <Pressable onPress={() => open(item)} style={styles.searchCard} accessibilityRole="button">
          <Icon name="bookmark-outline" size={22} color={colors.secondary} />
          <View style={{ flex: 1 }}>
            <Text style={styles.searchTitle} numberOfLines={1}>
              {item.query ? `"${item.query}"` : 'Any keywords'}
            </Text>
            <Text style={styles.meta} numberOfLines={1}>
              {describe(item)}
            </Text>
          </View>
          {item.notify ? <Badge label="Alerts soon" /> : null}
          <IconButton
            name="trash-can-outline"
            label="Delete saved search"
            color={colors.danger}
            onPress={() =>
              Alert.alert('Delete saved search?', undefined, [
                { text: 'Cancel', style: 'cancel' },
                { text: 'Delete', style: 'destructive', onPress: () => del.mutate(item.id) },
              ])
            }
          />
        </Pressable>
      )}
      ListEmptyComponent={
        q.isError ? (
          <ErrorState message={errorMessage(q.error)} onRetry={() => q.refetch()} />
        ) : (
          <EmptyState
            icon="bookmark-outline"
            title="No saved searches"
            message='In Search, set your filters and tap "Save search".'
            action={{ label: 'Go to Search', onPress: () => router.push('/search') }}
          />
        )
      }
    />
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, padding: spacing.md },
  name: { fontSize: 20, fontWeight: '800', color: colors.text, flexShrink: 1 },
  meta: { fontSize: 13, color: colors.textMuted },
  link: { fontSize: 13, color: colors.secondary, fontWeight: '700', marginTop: 2 },
  note: { color: colors.textMuted, fontSize: 12, marginBottom: spacing.sm },
  searchCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    backgroundColor: colors.card,
    borderRadius: radius.md,
    paddingLeft: spacing.md,
    paddingVertical: spacing.xs,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
    minHeight: 60,
  },
  searchTitle: { fontSize: 15, fontWeight: '700', color: colors.text },
});
