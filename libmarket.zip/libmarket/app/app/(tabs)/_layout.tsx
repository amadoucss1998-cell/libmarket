import { Tabs } from 'expo-router';
import React from 'react';
import { View } from 'react-native';
import { Icon } from '@/components/ui';
import { colors } from '@/constants/colors';
import { useInbox, useInboxRealtime } from '@/hooks/useInbox';

export default function TabsLayout() {
  useInboxRealtime();
  const { totalUnread } = useInbox();

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textMuted,
        tabBarLabelStyle: { fontSize: 12, fontWeight: '600' },
        headerTitleStyle: { fontWeight: '800', color: colors.text },
        headerShadowVisible: false,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
          headerShown: false,
          tabBarIcon: ({ color, focused }) => <Icon name={focused ? 'home' : 'home-outline'} color={color} size={26} />,
        }}
      />
      <Tabs.Screen
        name="search"
        options={{
          title: 'Search',
          headerShown: false,
          tabBarIcon: ({ color }) => <Icon name="magnify" color={color} size={26} />,
        }}
      />
      <Tabs.Screen
        name="sell"
        options={{
          title: 'Sell',
          headerTitle: 'Sell an item',
          tabBarIcon: () => (
            <View
              style={{
                width: 48,
                height: 48,
                borderRadius: 24,
                backgroundColor: colors.primary,
                alignItems: 'center',
                justifyContent: 'center',
                marginTop: -14,
                elevation: 4,
                shadowColor: '#000',
                shadowOpacity: 0.2,
                shadowRadius: 4,
                shadowOffset: { width: 0, height: 2 },
              }}
            >
              <Icon name="plus" color={colors.white} size={30} />
            </View>
          ),
          tabBarAccessibilityLabel: 'Sell an item',
        }}
      />
      <Tabs.Screen
        name="chats"
        options={{
          title: 'Chats',
          tabBarBadge: totalUnread > 0 ? (totalUnread > 99 ? '99+' : totalUnread) : undefined,
          tabBarBadgeStyle: { backgroundColor: colors.primary, color: colors.white, fontSize: 11 },
          tabBarIcon: ({ color, focused }) => (
            <Icon name={focused ? 'chat-processing' : 'chat-processing-outline'} color={color} size={26} />
          ),
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: 'Me',
          headerShown: false,
          tabBarIcon: ({ color, focused }) => <Icon name={focused ? 'account-circle' : 'account-circle-outline'} color={color} size={26} />,
        }}
      />
    </Tabs>
  );
}
