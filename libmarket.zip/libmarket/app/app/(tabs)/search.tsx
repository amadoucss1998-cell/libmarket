import { useInfiniteQuery, useQueryClient } from '@tanstack/react-query';
import { useLocalSearchParams } from 'expo-router';
import React, { useEffect, useMemo, useState } from 'react';
import { Alert, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { countActiveFilters, FiltersSheet } from '@/components/FiltersSheet';
import { cardFromSearch } from '@/components/ListingCard';
import { ListingGrid } from '@/components/ListingGrid';
import { Button, Chip, EmptyState, ErrorState, Icon, OfflineBanner } from '@/components/ui';
import { colors, radius, spacing } from '@/constants/colors';
import { conditionLabel, SORTS } from '@/constants/options';
import { useRequireAuth } from '@/hooks/useAuth';
import { useCategories } from '@/hooks/useReferenceData';
import { filtersToArgs, PAGE_SIZE, saveSearch, searchListings } from '@/lib/api';
import { formatPrice } from '@/lib/format';
import { qk } from '@/lib/queryClient';
import { errorMessage } from '@/lib/supabase';
import { EMPTY_FILTERS, type SearchFilters } from '@/types/app';

type Params = {
  q?: string;
  category?: string;
  minPrice?: string;
  maxPrice?: string;
  currency?: string;
  community?: string;
  ts?: string;
};

const num = (s?: string) => (s != null && s !== '' && Number.isFinite(Number(s)) ? Number(s) : null);

export default function SearchScreen() {
  const params = useLocalSearchParams<Params>();
  const [text, setText] = useState('');
  const [filters, setFilters] = useState<SearchFilters>(EMPTY_FILTERS);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const { byId } = useCategories();
  const requireAuth = useRequireAuth();
  const qc = useQueryClient();

  // Apply a saved search / category shortcut passed as route params.
  useEffect(() => {
    if (!params.ts && !params.q && !params.category) return;
    const f: SearchFilters = {
      ...EMPTY_FILTERS,
      q: params.q ?? '',
      category: num(params.category),
      minPrice: num(params.minPrice),
      maxPrice: num(params.maxPrice),
      currency: params.currency === 'USD' || params.currency === 'LRD' ? params.currency : null,
      community: params.community || null,
    };
    setFilters(f);
    setText(f.q);
  }, [params.ts, params.q, params.category, params.minPrice, params.maxPrice, params.currency, params.community]);

  // Debounce typing -> query (saves data on slow connections).
  useEffect(() => {
    const t = setTimeout(() => setFilters((f) => (f.q === text ? f : { ...f, q: text })), 450);
    return () => clearTimeout(t);
  }, [text]);

  const args = useMemo(() => filtersToArgs(filters), [filters]);
  const q = useInfiniteQuery({
    queryKey: qk.search(args),
    queryFn: ({ pageParam }) => searchListings(args, pageParam),
    initialPageParam: 0,
    getNextPageParam: (last, all) => {
      const loaded = all.reduce((n, p) => n + p.length, 0);
      const total = last[0]?.total_count ?? 0;
      return last.length === PAGE_SIZE && loaded < total ? loaded : undefined;
    },
  });

  const items = useMemo(() => (q.data?.pages ?? []).flat().map(cardFromSearch), [q.data]);
  const total = q.data?.pages[0]?.[0]?.total_count ?? 0;
  const activeCount = countActiveFilters(filters);

  const onSave = async () => {
    if (!requireAuth('save searches')) return;
    setSaving(true);
    try {
      await saveSearch({
        query: filters.q.trim() || null,
        category_id: filters.category,
        min_price: filters.minPrice,
        max_price: filters.maxPrice,
        currency: filters.currency,
        community: filters.community,
      });
      qc.invalidateQueries({ queryKey: ['savedSearches'] });
      Alert.alert('Search saved', 'Find it under Me → Searches.');
    } catch (e) {
      Alert.alert('Could not save search', errorMessage(e));
    } finally {
      setSaving(false);
    }
  };

  const clear = <K extends keyof SearchFilters>(k: K) => setFilters((f) => ({ ...f, [k]: EMPTY_FILTERS[k] }));
  const unit = filters.currency ?? 'USD';
  const activeChips: { key: keyof SearchFilters; label: string }[] = [];
  if (filters.category != null) activeChips.push({ key: 'category', label: byId.get(filters.category)?.name ?? 'Category' });
  if (filters.community) activeChips.push({ key: 'community', label: filters.community });
  if (filters.currency) activeChips.push({ key: 'currency', label: filters.currency });
  if (filters.minPrice != null) activeChips.push({ key: 'minPrice', label: `Min ${formatPrice(filters.minPrice, unit, { freeLabel: false })}` });
  if (filters.maxPrice != null) activeChips.push({ key: 'maxPrice', label: `Max ${formatPrice(filters.maxPrice, unit, { freeLabel: false })}` });
  if (filters.condition) activeChips.push({ key: 'condition', label: conditionLabel(filters.condition) });
  if (filters.sort) activeChips.push({ key: 'sort', label: SORTS.find((s) => s.value === filters.sort)?.label ?? '' });

  const hasCriteria = !!filters.q.trim() || activeCount > 0;

  const header = (
    <View style={{ marginBottom: spacing.xs }}>
      {activeChips.length ? (
        <View style={styles.activeRow}>
          {activeChips.map((c) => (
            <Chip key={c.key} label={`${c.label}  ✕`} selected onPress={() => clear(c.key)} />
          ))}
        </View>
      ) : null}
      <View style={styles.resultRow}>
        <Text style={styles.resultText}>{q.isLoading ? 'Searching…' : `${total.toLocaleString()} result${total === 1 ? '' : 's'}`}</Text>
        {hasCriteria ? (
          <Button title="Save search" icon="bookmark-outline" variant="ghost" small onPress={onSave} loading={saving} />
        ) : null}
      </View>
    </View>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.white }} edges={['top']}>
      <OfflineBanner />
      <View style={styles.top}>
        <View style={styles.searchBar}>
          <Icon name="magnify" size={22} color={colors.textMuted} />
          <TextInput
            value={text}
            onChangeText={setText}
            placeholder="What are you looking for?"
            placeholderTextColor={colors.textLight}
            style={styles.input}
            returnKeyType="search"
            onSubmitEditing={() => setFilters((f) => ({ ...f, q: text }))}
            autoCorrect={false}
            accessibilityLabel="Search"
          />
          {text ? (
            <Pressable onPress={() => setText('')} hitSlop={10} accessibilityLabel="Clear search">
              <Icon name="close-circle" size={20} color={colors.textLight} />
            </Pressable>
          ) : null}
        </View>
        <Pressable onPress={() => setSheetOpen(true)} style={styles.filterBtn} accessibilityRole="button" accessibilityLabel={`Filters, ${activeCount} active`}>
          <Icon name="tune-variant" size={22} color={colors.secondary} />
          {activeCount > 0 ? (
            <View style={styles.filterBadge}>
              <Text style={styles.filterBadgeText}>{activeCount}</Text>
            </View>
          ) : null}
        </Pressable>
      </View>
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <ListingGrid
          items={items}
          loading={q.isLoading}
          refreshing={q.isRefetching && !q.isFetchingNextPage}
          onRefresh={() => q.refetch()}
          onEndReached={() => q.hasNextPage && !q.isFetchingNextPage && q.fetchNextPage()}
          loadingMore={q.isFetchingNextPage}
          header={header}
          empty={
            q.isError ? (
              <ErrorState message={errorMessage(q.error)} onRetry={() => q.refetch()} />
            ) : (
              <EmptyState
                icon="magnify-close"
                title="No results"
                message="Try fewer words, another community, or save this search to check back later."
                action={hasCriteria ? { label: 'Save this search', onPress: onSave } : undefined}
              />
            )
          }
        />
      </View>
      <FiltersSheet visible={sheetOpen} onClose={() => setSheetOpen(false)} value={filters} onApply={setFilters} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  top: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, padding: spacing.md, backgroundColor: colors.white },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    borderRadius: radius.md,
    backgroundColor: colors.background,
    paddingHorizontal: spacing.md,
  },
  input: { flex: 1, minHeight: 46, fontSize: 16, color: colors.text },
  filterBtn: {
    width: 48,
    height: 48,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  filterBadge: {
    position: 'absolute',
    top: 4,
    right: 4,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 4,
  },
  filterBadgeText: { color: colors.white, fontSize: 11, fontWeight: '800' },
  activeRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, marginBottom: spacing.sm },
  resultRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', minHeight: 44 },
  resultText: { color: colors.textMuted, fontWeight: '600' },
});
