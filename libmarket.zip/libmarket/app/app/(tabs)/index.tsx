import { useInfiniteQuery } from '@tanstack/react-query';
import { router } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { CategoryChips } from '@/components/CategoryChips';
import { CommunityPicker } from '@/components/CommunityPicker';
import { cardFromSearch } from '@/components/ListingCard';
import { ListingGrid } from '@/components/ListingGrid';
import { EmptyState, ErrorState, Icon, OfflineBanner } from '@/components/ui';
import { colors, radius, spacing } from '@/constants/colors';
import { useStoredState } from '@/hooks/useStoredState';
import { PAGE_SIZE, searchListings } from '@/lib/api';
import { qk } from '@/lib/queryClient';
import { errorMessage } from '@/lib/supabase';
import type { SearchListingsArgs } from '@/types/database';

export default function HomeScreen() {
  const [category, setCategory] = useState<number | null>(null);
  const [area, setArea] = useStoredState<string | null>('libmarket.homeArea', null);
  const [areaOpen, setAreaOpen] = useState(false);

  const args: SearchListingsArgs = useMemo(() => ({ category, community: area, sort: 'newest' }), [category, area]);

  const q = useInfiniteQuery({
    queryKey: qk.feed(args),
    queryFn: ({ pageParam }) => searchListings(args, pageParam),
    initialPageParam: 0,
    getNextPageParam: (last, all) => {
      const loaded = all.reduce((n, p) => n + p.length, 0);
      const total = last[0]?.total_count ?? 0;
      return last.length === PAGE_SIZE && loaded < total ? loaded : undefined;
    },
  });

  const items = useMemo(() => (q.data?.pages ?? []).flat().map(cardFromSearch), [q.data]);

  const header = (
    <View style={{ marginHorizontal: -spacing.md, marginTop: -spacing.md, marginBottom: spacing.xs }}>
      <View style={{ paddingVertical: spacing.sm }}>
        <CategoryChips value={category} onChange={setCategory} />
      </View>
      {q.isError && items.length > 0 ? (
        <Text style={styles.staleNote}>Couldn't refresh. Showing saved results.</Text>
      ) : null}
    </View>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.white }} edges={['top']}>
      <OfflineBanner />
      <View style={styles.top}>
        <View style={styles.brandRow}>
          <Text style={styles.brand}>
            <Text style={{ color: colors.primary }}>Lib</Text>
            <Text style={{ color: colors.secondary }}>Market</Text>
          </Text>
          <Pressable
            onPress={() => setAreaOpen(true)}
            style={styles.areaChip}
            accessibilityRole="button"
            accessibilityLabel={`Area: ${area ?? 'All Liberia'}. Change area`}
          >
            <Icon name="map-marker" size={16} color={colors.primary} />
            <Text style={styles.areaText} numberOfLines={1}>
              {area ?? 'All Liberia'}
            </Text>
            <Icon name="chevron-down" size={16} color={colors.textMuted} />
          </Pressable>
        </View>
        <Pressable
          onPress={() => router.push('/search')}
          style={styles.searchBar}
          accessibilityRole="search"
          accessibilityLabel="Search LibMarket"
        >
          <Icon name="magnify" size={22} color={colors.textMuted} />
          <Text style={styles.searchText}>Search phones, generators, cars…</Text>
        </Pressable>
      </View>
      <View style={{ flex: 1, backgroundColor: colors.background }}>
        <ListingGrid
          items={items}
          loading={q.isLoading}
          refreshing={q.isRefetching && !q.isFetchingNextPage}
          onRefresh={() => q.refetch()}
          onEndReached={() => q.hasNextPage && !q.isFetchingNextPage && q.fetchNextPage()}
          loadingMore={q.isFetchingNextPage}
          header={header}
          empty={
            q.isError ? (
              <ErrorState message={errorMessage(q.error)} onRetry={() => q.refetch()} />
            ) : (
              <EmptyState
                icon="storefront-outline"
                title="No items here yet"
                message={area ? `Nothing posted in ${area} yet. Try "All Liberia" or be the first to sell!` : 'Be the first to sell something!'}
                action={{ label: 'Sell an item', onPress: () => router.push('/sell') }}
              />
            )
          }
        />
      </View>
      <CommunityPicker
        visible={areaOpen}
        onClose={() => setAreaOpen(false)}
        selected={area}
        onSelect={setArea}
        allowAll
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  top: { paddingHorizontal: spacing.md, paddingBottom: spacing.sm, backgroundColor: colors.white, gap: spacing.sm },
  brandRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: spacing.sm },
  brand: { fontSize: 26, fontWeight: '900', letterSpacing: -0.5 },
  areaChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    minHeight: 40,
    paddingHorizontal: spacing.md,
    borderRadius: radius.pill,
    backgroundColor: colors.background,
    maxWidth: '55%',
  },
  areaText: { fontWeight: '700', color: colors.text, flexShrink: 1 },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    minHeight: 46,
    borderRadius: radius.md,
    backgroundColor: colors.background,
    paddingHorizontal: spacing.md,
  },
  searchText: { color: colors.textMuted, fontSize: 15 },
  staleNote: { textAlign: 'center', color: colors.warning, fontSize: 12, paddingBottom: 4 },
});
