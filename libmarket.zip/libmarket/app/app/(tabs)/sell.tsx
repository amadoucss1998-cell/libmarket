import { router } from 'expo-router';
import React, { useState } from 'react';
import { View } from 'react-native';
import { ListingForm } from '@/components/ListingForm';
import { EmptyState, Loading } from '@/components/ui';
import { colors } from '@/constants/colors';
import { useAuth } from '@/hooks/useAuth';

export default function SellScreen() {
  const { user, initializing } = useAuth();
  const [formKey, setFormKey] = useState(0);

  if (initializing) return <Loading />;
  if (!user) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.white }}>
        <EmptyState
          icon="camera-plus-outline"
          title="Sell in 60 seconds"
          message="Log in with your phone number to post an item. It's free."
          action={{ label: 'Log in to sell', onPress: () => router.push('/auth/login') }}
        />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.white }}>
      <ListingForm
        key={formKey}
        onDone={(id) => {
          setFormKey((k) => k + 1); // fresh form for the next item
          router.push(`/listing/${id}?posted=1`);
        }}
      />
    </View>
  );
}
