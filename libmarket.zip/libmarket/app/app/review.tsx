import { useQuery, useQueryClient } from '@tanstack/react-query';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Alert, ScrollView, StyleSheet, Text } from 'react-native';
import { Button, EmptyState, Loading, StarPicker, TextField } from '@/components/ui';
import { colors, spacing } from '@/constants/colors';
import { useAuth } from '@/hooks/useAuth';
import { createReview, fetchMyReviewForListing, updateReview } from '@/lib/api';
import { qk } from '@/lib/queryClient';
import { errorMessage } from '@/lib/supabase';

const LABELS = ['', 'Bad', 'Not great', 'OK', 'Good', 'Excellent'];

export default function ReviewScreen() {
  const { listingId, revieweeId, name } = useLocalSearchParams<{ listingId: string; revieweeId: string; name?: string }>();
  const { user } = useAuth();
  const qc = useQueryClient();
  const [rating, setRating] = useState<0 | 1 | 2 | 3 | 4 | 5>(0);
  const [comment, setComment] = useState('');
  const [saving, setSaving] = useState(false);

  const existingQ = useQuery({
    queryKey: ['myReview', listingId, user?.id],
    queryFn: () => fetchMyReviewForListing(user!.id, listingId),
    enabled: !!user && !!listingId,
  });
  const existing = existingQ.data;

  useEffect(() => {
    if (existing) {
      setRating(existing.rating);
      setComment(existing.comment ?? '');
    }
  }, [existing]);

  if (!user) return <EmptyState title="Log in to leave a review" />;
  if (!listingId || !revieweeId) return <EmptyState title="Nothing to review" />;
  if (existingQ.isLoading) return <Loading />;

  const submit = async () => {
    if (rating === 0) return;
    setSaving(true);
    try {
      const c = comment.trim() || null;
      if (existing) await updateReview(existing.id, rating, c);
      else await createReview({ reviewee_id: revieweeId, listing_id: listingId, rating, comment: c });
      qc.invalidateQueries({ queryKey: qk.reviews(revieweeId) });
      qc.invalidateQueries({ queryKey: qk.publicProfile(revieweeId) });
      Alert.alert('Thanks for your review!', undefined, [{ text: 'OK', onPress: () => router.back() }]);
    } catch (e) {
      Alert.alert('Could not save review', errorMessage(e));
    } finally {
      setSaving(false);
    }
  };

  return (
    <ScrollView style={{ backgroundColor: colors.white }} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
      <Text style={styles.title}>How was your deal{name ? ` with ${name}` : ''}?</Text>
      <Text style={styles.subtitle}>Your review helps others trade safely.</Text>
      <StarPicker value={rating} onChange={setRating} />
      <Text style={styles.label}>{LABELS[rating]}</Text>
      <TextField
        label="Comment (optional)"
        value={comment}
        onChangeText={setComment}
        placeholder="Item as described? On time? Friendly?"
        multiline
        maxLength={1000}
        counter
      />
      <Button title={existing ? 'Update review' : 'Submit review'} onPress={submit} disabled={rating === 0} loading={saving} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { padding: spacing.xl },
  title: { fontSize: 20, fontWeight: '800', color: colors.text, textAlign: 'center' },
  subtitle: { color: colors.textMuted, textAlign: 'center', marginTop: 4, marginBottom: spacing.xl },
  label: { textAlign: 'center', fontWeight: '700', color: colors.star, minHeight: 24, marginVertical: spacing.md },
});
