import { useQuery, useQueryClient } from '@tanstack/react-query';
import { router, Stack, useLocalSearchParams } from 'expo-router';
import React, { useMemo, useState } from 'react';
import { Alert, ScrollView, StyleSheet, Text, View } from 'react-native';
import { cardFromListing } from '@/components/ListingCard';
import { ListingGrid } from '@/components/ListingGrid';
import { Avatar, EmptyState, ErrorState, IconButton, Loading, Segmented, Stars, VerifiedTick } from '@/components/ui';
import { colors, radius, spacing } from '@/constants/colors';
import { useAuth, useRequireAuth } from '@/hooks/useAuth';
import { blockUser, fetchPublicProfile, fetchReviewsFor, fetchSellerListings } from '@/lib/api';
import { monthYear, timeAgo } from '@/lib/format';
import { qk } from '@/lib/queryClient';
import { errorMessage } from '@/lib/supabase';
import type { ReviewWithReviewer } from '@/types/app';

type Tab = 'listings' | 'reviews';

export default function PublicProfileScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { user } = useAuth();
  const requireAuth = useRequireAuth();
  const qc = useQueryClient();
  const [tab, setTab] = useState<Tab>('listings');

  const profileQ = useQuery({ queryKey: qk.publicProfile(id), queryFn: () => fetchPublicProfile(id), enabled: !!id });
  const listingsQ = useQuery({ queryKey: qk.sellerListings(id), queryFn: () => fetchSellerListings(id), enabled: !!id });
  const reviewsQ = useQuery({ queryKey: qk.reviews(id), queryFn: () => fetchReviewsFor(id), enabled: !!id && tab === 'reviews' });
  const items = useMemo(() => (listingsQ.data ?? []).map(cardFromListing), [listingsQ.data]);

  const p = profileQ.data;
  const isMe = user?.id === id;

  const menu = () => {
    if (!p) return;
    Alert.alert(p.display_name, undefined, [
      { text: 'Report user', onPress: () => requireAuth('report') && router.push(`/report?userId=${p.id}`) },
      {
        text: 'Block user',
        style: 'destructive',
        onPress: () => {
          if (!requireAuth('block users')) return;
          Alert.alert(`Block ${p.display_name}?`, "You won't see each other's items or be able to chat.", [
            { text: 'Cancel', style: 'cancel' },
            {
              text: 'Block',
              style: 'destructive',
              onPress: async () => {
                try {
                  await blockUser(p.id);
                  qc.invalidateQueries({ queryKey: ['feed'] });
                  qc.invalidateQueries({ queryKey: ['search'] });
                  qc.invalidateQueries({ queryKey: ['inbox'] });
                  router.back();
                } catch (e) {
                  Alert.alert('Could not block', errorMessage(e));
                }
              },
            },
          ]);
        },
      },
      { text: 'Cancel', style: 'cancel' },
    ]);
  };

  if (profileQ.isLoading) return <Loading />;
  if (profileQ.isError) return <ErrorState message={errorMessage(profileQ.error)} onRetry={() => profileQ.refetch()} />;
  if (!p) return <EmptyState icon="account-off-outline" title="User not found" />;

  const header = (
    <View style={{ marginHorizontal: -spacing.md, marginTop: -spacing.md, marginBottom: spacing.sm, backgroundColor: colors.white }}>
      <View style={styles.header}>
        <Avatar uri={p.avatar_url} name={p.display_name} size={80} />
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: spacing.sm }}>
          <Text style={styles.name}>{p.display_name}</Text>
          {p.is_verified ? <VerifiedTick size={20} /> : null}
        </View>
        {p.rating_count > 0 ? (
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 }}>
            <Stars value={Number(p.rating_avg)} size={16} />
            <Text style={styles.meta}>
              {Number(p.rating_avg).toFixed(1)} · {p.rating_count} review{p.rating_count === 1 ? '' : 's'}
            </Text>
          </View>
        ) : (
          <Text style={[styles.meta, { marginTop: 4 }]}>No reviews yet</Text>
        )}
        <Text style={[styles.meta, { marginTop: 4 }]}>
          {p.community ? `${p.community} · ` : ''}Member since {monthYear(p.created_at)}
        </Text>
        {p.is_verified ? <Text style={styles.verified}>Verified seller</Text> : null}
        {p.bio ? <Text style={styles.bio}>{p.bio}</Text> : null}
      </View>
      <View style={{ paddingHorizontal: spacing.md, paddingBottom: spacing.md }}>
        <Segmented<Tab>
          options={[
            { value: 'listings', label: `Items (${items.length})` },
            { value: 'reviews', label: `Reviews (${p.rating_count})` },
          ]}
          value={tab}
          onChange={setTab}
        />
      </View>
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Stack.Screen
        options={{
          title: p.display_name,
          headerRight: isMe ? undefined : () => <IconButton name="dots-vertical" label="More options" onPress={menu} />,
        }}
      />
      {tab === 'listings' ? (
        <ListingGrid
          items={items}
          loading={listingsQ.isLoading}
          refreshing={listingsQ.isRefetching}
          onRefresh={() => listingsQ.refetch()}
          header={header}
          empty={<EmptyState icon="storefront-outline" title="No items for sale right now" />}
        />
      ) : (
        <ReviewsList header={header} reviews={reviewsQ.data ?? []} loading={reviewsQ.isLoading} />
      )}
    </View>
  );
}

function ReviewsList({ header, reviews, loading }: { header: React.ReactElement; reviews: ReviewWithReviewer[]; loading: boolean }) {
  return (
    <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingBottom: spacing.xl }}>
      <View style={{ padding: spacing.md }}>{header}</View>
      {loading ? (
        <Loading />
      ) : reviews.length === 0 ? (
        <EmptyState icon="star-outline" title="No reviews yet" message="Reviews appear after a completed deal." />
      ) : (
        <View style={{ paddingHorizontal: spacing.md, gap: spacing.sm }}>
          {reviews.map((r) => (
            <View key={r.id} style={styles.review}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.sm }}>
                <Avatar uri={r.reviewer?.avatar_url} name={r.reviewer?.display_name} size={32} />
                <View style={{ flex: 1 }}>
                  <Text style={{ fontWeight: '700', color: colors.text }}>{r.reviewer?.display_name ?? 'LibMarket user'}</Text>
                  <Text style={styles.meta}>{timeAgo(r.created_at)}</Text>
                </View>
                <Stars value={r.rating} />
              </View>
              {r.comment ? <Text style={styles.comment}>{r.comment}</Text> : null}
            </View>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  header: { alignItems: 'center', padding: spacing.lg },
  name: { fontSize: 22, fontWeight: '800', color: colors.text },
  meta: { fontSize: 13, color: colors.textMuted },
  verified: { color: colors.secondary, fontWeight: '700', marginTop: 4 },
  bio: { color: colors.text, textAlign: 'center', marginTop: spacing.sm, lineHeight: 20 },
  review: { backgroundColor: colors.card, borderRadius: radius.md, padding: spacing.md, gap: spacing.sm },
  comment: { color: colors.text, lineHeight: 20 },
});
