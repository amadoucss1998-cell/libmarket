import { useInfiniteQuery, useQuery, useQueryClient, type InfiniteData } from '@tanstack/react-query';
import { Image } from 'expo-image';
import { router, Stack, useFocusEffect, useLocalSearchParams } from 'expo-router';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MessageBubble } from '@/components/MessageBubble';
import { OfferSheet } from '@/components/OfferSheet';
import { SafetyBanner } from '@/components/SafetyBanner';
import { Button, Chip, EmptyState, ErrorState, Icon, IconButton, Loading } from '@/components/ui';
import { colors, radius, spacing } from '@/constants/colors';
import { BUYER_QUICK_REPLIES, SELLER_QUICK_REPLIES } from '@/constants/options';
import { useAuth } from '@/hooks/useAuth';
import { useOwnerListingActions } from '@/hooks/useListingActions';
import { useStoredState } from '@/hooks/useStoredState';
import {
  blockUser,
  fetchInboxRow,
  fetchMessages,
  markConversationRead,
  MESSAGES_PAGE,
  respondToOffer,
  sendImageMessage,
  sendMessage,
} from '@/lib/api';
import { formatPrice } from '@/lib/format';
import { chooseImageSource, pickImages } from '@/lib/images';
import { qk } from '@/lib/queryClient';
import { errorMessage, listingImageUrl, supabase } from '@/lib/supabase';
import type { MessageRow } from '@/types/database';

type Pages = InfiniteData<MessageRow[], number>;

export default function ChatScreen() {
  const { id, offer, text: prefill } = useLocalSearchParams<{ id: string; offer?: string; text?: string }>();
  const { user } = useAuth();
  const qc = useQueryClient();
  const insets = useSafeAreaInsets();
  const owner = useOwnerListingActions();
  const [text, setText] = useState(prefill ?? '');
  const [sending, setSending] = useState(false);
  const [offerOpen, setOfferOpen] = useState(false);
  const [respondingId, setRespondingId] = useState<string | null>(null);
  const [safetySeen, setSafetySeen, safetyLoaded] = useStoredState('libmarket.chatSafetySeen', false);

  const convQ = useQuery({ queryKey: qk.inboxRow(id), queryFn: () => fetchInboxRow(id), enabled: !!id });
  const conv = convQ.data;
  const isSeller = conv?.my_role === 'seller';

  const msgQ = useInfiniteQuery({
    queryKey: qk.messages(id),
    queryFn: ({ pageParam }) => fetchMessages(id, pageParam),
    initialPageParam: 0,
    getNextPageParam: (last, all) => (last.length === MESSAGES_PAGE ? all.length : undefined),
    enabled: !!id && !!user,
    staleTime: 0,
  });
  const messages = useMemo(() => {
    const seen = new Set<string>();
    return (msgQ.data?.pages ?? []).flat().filter((m) => (seen.has(m.id) ? false : (seen.add(m.id), true)));
  }, [msgQ.data]);

  /* ---------------------------- cache helpers ---------------------------- */
  const upsertMessage = useCallback(
    (m: MessageRow) => {
      qc.setQueryData<Pages>(qk.messages(id), (old) => {
        if (!old) return { pages: [[m]], pageParams: [0] };
        const exists = old.pages.some((p) => p.some((x) => x.id === m.id));
        if (exists) return { ...old, pages: old.pages.map((p) => p.map((x) => (x.id === m.id ? m : x))) };
        const [first = [], ...rest] = old.pages;
        return { ...old, pages: [[m, ...first], ...rest] };
      });
    },
    [qc, id],
  );

  const markRead = useCallback(async () => {
    if (!id || !user) return;
    await markConversationRead(id);
    qc.invalidateQueries({ queryKey: qk.inbox(user.id) });
  }, [id, user, qc]);

  /* ------------------------------ realtime ------------------------------- */
  useEffect(() => {
    if (!id || !user) return;
    const ch = supabase
      .channel(`chat:${id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${id}` }, (p) => {
        const m = p.new as MessageRow;
        upsertMessage(m);
        if (m.sender_id !== user.id) markRead();
        if (m.kind === 'system') qc.invalidateQueries({ queryKey: qk.inboxRow(id) });
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages', filter: `conversation_id=eq.${id}` }, (p) => {
        upsertMessage(p.new as MessageRow);
      })
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [id, user, upsertMessage, markRead, qc]);

  useFocusEffect(
    useCallback(() => {
      markRead();
    }, [markRead]),
  );

  // First-ever chat: one-time safety interstitial.
  useEffect(() => {
    if (safetyLoaded && !safetySeen && conv) {
      setSafetySeen(true);
      Alert.alert(
        'Stay safe on LibMarket',
        'Meet in a busy public place. Inspect the item before you pay. Never send mobile money in advance.',
        [{ text: 'Safety tips', onPress: () => router.push('/safety') }, { text: 'Got it' }],
      );
    }
  }, [safetyLoaded, safetySeen, conv, setSafetySeen]);

  // Opened from "Make offer" on the listing.
  const offerOpened = useRef(false);
  useEffect(() => {
    if (offer && conv && !isSeller && !offerOpened.current) {
      offerOpened.current = true;
      setOfferOpen(true);
    }
  }, [offer, conv, isSeller]);

  /* ------------------------------- actions ------------------------------- */
  const send = async (body: string) => {
    const trimmed = body.trim();
    if (!trimmed || !id) return;
    setSending(true);
    setText('');
    try {
      upsertMessage(await sendMessage({ conversation_id: id, body: trimmed }));
    } catch (e) {
      setText(trimmed);
      Alert.alert('Message not sent', errorMessage(e));
    } finally {
      setSending(false);
    }
  };

  const sendOffer = async (amount: number, note: string) => {
    setSending(true);
    try {
      upsertMessage(await sendMessage({ conversation_id: id, kind: 'offer', offer_amount: amount, body: note || null }));
      setOfferOpen(false);
    } catch (e) {
      Alert.alert('Offer not sent', errorMessage(e));
    } finally {
      setSending(false);
    }
  };

  const sendPhoto = () =>
    chooseImageSource(async (source) => {
      if (!user) return;
      const [img] = await pickImages(source, 1);
      if (!img) return;
      setSending(true);
      try {
        upsertMessage(await sendImageMessage(id, user.id, img));
      } catch (e) {
        Alert.alert('Photo not sent', errorMessage(e));
      } finally {
        setSending(false);
      }
    });

  const respond = useCallback(
    async (messageId: string, accept: boolean) => {
      setRespondingId(messageId);
      try {
        upsertMessage(await respondToOffer(messageId, accept));
        qc.invalidateQueries({ queryKey: qk.inboxRow(id) });
        if (conv) qc.invalidateQueries({ queryKey: ['listing', conv.listing_id] });
      } catch (e) {
        Alert.alert('Could not respond', errorMessage(e));
      } finally {
        setRespondingId(null);
      }
    },
    [upsertMessage, qc, id, conv],
  );

  const menu = () => {
    if (!conv?.other_user_id) return;
    const otherId = conv.other_user_id;
    const name = conv.other_display_name ?? 'this user';
    Alert.alert(name, undefined, [
      { text: 'View profile', onPress: () => router.push(`/user/${otherId}`) },
      { text: 'Report user', onPress: () => router.push(`/report?userId=${otherId}`) },
      {
        text: 'Block user',
        style: 'destructive',
        onPress: () =>
          Alert.alert(`Block ${name}?`, "You won't be able to message each other.", [
            { text: 'Cancel', style: 'cancel' },
            {
              text: 'Block',
              style: 'destructive',
              onPress: async () => {
                try {
                  await blockUser(otherId);
                  qc.invalidateQueries({ queryKey: qk.inboxRow(id) });
                  qc.invalidateQueries({ queryKey: ['inbox'] });
                  qc.invalidateQueries({ queryKey: ['feed'] });
                } catch (e) {
                  Alert.alert('Could not block', errorMessage(e));
                }
              },
            },
          ]),
      },
      { text: 'Cancel', style: 'cancel' },
    ]);
  };

  /* -------------------------------- render ------------------------------- */
  if (convQ.isLoading) return <Loading />;
  if (convQ.isError) return <ErrorState message={errorMessage(convQ.error)} onRetry={() => convQ.refetch()} />;
  if (!conv) return <EmptyState icon="chat-remove-outline" title="Chat not found" />;

  const listingAvailable = conv.listing_status === 'active' || conv.listing_status === 'reserved';
  const hasAcceptedOffer = messages.some((m) => m.kind === 'offer' && m.offer_status === 'accepted');
  const canReview = !!conv.other_user_id && (conv.listing_status === 'sold' || hasAcceptedOffer);
  const cover = listingImageUrl(conv.listing_cover_path, true);
  const quickReplies = isSeller ? SELLER_QUICK_REPLIES : BUYER_QUICK_REPLIES;

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.white }}
      behavior="padding"
      keyboardVerticalOffset={Platform.OS === 'ios' ? insets.top + 44 : 0}
    >
      <Stack.Screen
        options={{
          title: conv.other_display_name ?? 'Chat',
          headerRight: () => <IconButton name="dots-vertical" label="Chat options" onPress={menu} />,
        }}
      />

      {/* Listing header card */}
      <Pressable
        onPress={() => conv.listing_title && router.push(`/listing/${conv.listing_id}`)}
        style={styles.listingCard}
        accessibilityRole="button"
        accessibilityLabel={`Item: ${conv.listing_title ?? 'removed'}`}
      >
        {cover ? (
          <Image source={{ uri: cover }} style={styles.listingThumb} contentFit="cover" cachePolicy="disk" />
        ) : (
          <View style={[styles.listingThumb, { alignItems: 'center', justifyContent: 'center' }]}>
            <Icon name="image-off-outline" size={20} color={colors.textLight} />
          </View>
        )}
        <View style={{ flex: 1 }}>
          <Text style={styles.listingTitle} numberOfLines={1}>
            {conv.listing_title ?? 'Item removed'}
          </Text>
          <Text style={styles.listingMeta}>
            {conv.listing_price != null && conv.listing_currency ? formatPrice(conv.listing_price, conv.listing_currency) : ''}
            {conv.listing_status && conv.listing_status !== 'active' ? ` · ${conv.listing_status.toUpperCase()}` : ''}
          </Text>
        </View>
        {isSeller && listingAvailable ? (
          <Button title="Mark sold" small variant="outline" onPress={() => owner.markSold(conv.listing_id, () => convQ.refetch())} />
        ) : canReview ? (
          <Button
            title="Review"
            small
            variant="outline"
            icon="star-outline"
            onPress={() =>
              router.push(
                `/review?listingId=${conv.listing_id}&revieweeId=${conv.other_user_id}&name=${encodeURIComponent(conv.other_display_name ?? '')}`,
              )
            }
          />
        ) : null}
      </Pressable>

      {/* Messages (inverted: newest at bottom) */}
      {msgQ.isLoading ? (
        <Loading />
      ) : (
        <FlatList
          data={messages}
          inverted
          keyExtractor={(m) => m.id}
          contentContainerStyle={{ padding: spacing.md }}
          renderItem={({ item }) => (
            <MessageBubble
              message={item}
              mine={item.sender_id === user?.id}
              isSeller={isSeller}
              onRespond={respond}
              responding={respondingId === item.id}
            />
          )}
          onEndReached={() => msgQ.hasNextPage && !msgQ.isFetchingNextPage && msgQ.fetchNextPage()}
          onEndReachedThreshold={0.3}
          ListFooterComponent={<SafetyBanner />}
          ListEmptyComponent={
            <Text style={styles.emptyHint}>
              {isSeller ? 'Say hello to your buyer.' : 'Ask the seller a question or make an offer.'}
            </Text>
          }
          keyboardShouldPersistTaps="handled"
        />
      )}

      {/* Composer */}
      {conv.is_blocked ? (
        <View style={[styles.blocked, { paddingBottom: Math.max(insets.bottom, spacing.md) }]}>
          <Icon name="block-helper" size={18} color={colors.textMuted} />
          <Text style={styles.blockedText}>You can't message this user (blocked).</Text>
        </View>
      ) : (
        <View style={{ paddingBottom: Math.max(insets.bottom, spacing.sm), borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.border }}>
          {!text ? (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.quick} keyboardShouldPersistTaps="handled">
              {!isSeller && listingAvailable ? (
                <Chip label="Make offer" icon="tag-outline" selected onPress={() => setOfferOpen(true)} />
              ) : null}
              {quickReplies.map((r) => (
                <Chip key={r} label={r} onPress={() => send(r)} />
              ))}
            </ScrollView>
          ) : null}
          <View style={styles.composer}>
            <IconButton name="camera-outline" label="Send a photo" color={colors.secondary} onPress={sendPhoto} />
            <TextInput
              value={text}
              onChangeText={setText}
              placeholder="Write a message…"
              placeholderTextColor={colors.textLight}
              style={styles.input}
              multiline
              maxLength={4000}
              accessibilityLabel="Message"
            />
            <IconButton
              name="send"
              label="Send"
              color={text.trim() ? colors.primary : colors.textLight}
              onPress={() => send(text)}
              style={{ opacity: sending ? 0.5 : 1 }}
            />
          </View>
        </View>
      )}

      <OfferSheet
        visible={offerOpen}
        onClose={() => setOfferOpen(false)}
        askingPrice={conv.listing_price ?? 0}
        currency={conv.listing_currency ?? 'USD'}
        onSubmit={sendOffer}
        sending={sending}
      />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  listingCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    padding: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
    backgroundColor: colors.white,
  },
  listingThumb: { width: 48, height: 48, borderRadius: radius.sm, backgroundColor: colors.skeleton },
  listingTitle: { fontSize: 15, fontWeight: '700', color: colors.text },
  listingMeta: { fontSize: 13, color: colors.textMuted, marginTop: 2 },
  emptyHint: { textAlign: 'center', color: colors.textMuted, marginVertical: spacing.xl },
  quick: { gap: spacing.sm, paddingHorizontal: spacing.md, paddingTop: spacing.sm },
  composer: { flexDirection: 'row', alignItems: 'flex-end', paddingHorizontal: spacing.xs, paddingTop: spacing.xs },
  input: {
    flex: 1,
    minHeight: 44,
    maxHeight: 120,
    backgroundColor: colors.background,
    borderRadius: 22,
    paddingHorizontal: spacing.lg,
    paddingTop: 11,
    paddingBottom: 11,
    fontSize: 16,
    color: colors.text,
  },
  blocked: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    paddingTop: spacing.md,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.border,
  },
  blockedText: { color: colors.textMuted, fontWeight: '600' },
});
