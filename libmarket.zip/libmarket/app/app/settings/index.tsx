import Constants from 'expo-constants';
import { router } from 'expo-router';
import React from 'react';
import { Alert, Linking, ScrollView, Text, View } from 'react-native';
import { Divider, ListItem } from '@/components/ui';
import { colors, spacing } from '@/constants/colors';
import { useAuth } from '@/hooks/useAuth';
import { useLrdRate } from '@/hooks/useReferenceData';

export default function SettingsScreen() {
  const { user, profile, signOut } = useAuth();
  const rate = useLrdRate();

  const logout = () =>
    Alert.alert('Log out?', undefined, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Log out',
        style: 'destructive',
        onPress: async () => {
          await signOut();
          router.replace('/');
        },
      },
    ]);

  const deleteAccount = () =>
    Alert.alert(
      'Delete account',
      'To delete your account and data, contact LibMarket support. We will remove it within 30 days.',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Email support', onPress: () => Linking.openURL('mailto:support@libmarket.app?subject=Delete%20my%20account') },
      ],
    );

  return (
    <ScrollView style={{ backgroundColor: colors.background }} contentContainerStyle={{ paddingVertical: spacing.md }}>
      {user ? (
        <View style={{ backgroundColor: colors.card }}>
          <ListItem icon="account-edit-outline" title="Edit profile" subtitle={profile?.display_name} onPress={() => router.push('/auth/profile-setup')} />
          <Divider />
          <ListItem
            icon="whatsapp"
            title="Contact preferences"
            subtitle={`WhatsApp ${profile?.show_whatsapp ? 'shown' : 'hidden'} · Calls ${profile?.show_phone ? 'allowed' : 'off'}`}
            onPress={() => router.push('/auth/profile-setup')}
          />
          <Divider />
          <ListItem icon="account-cancel-outline" title="Blocked users" onPress={() => router.push('/settings/blocked')} />
        </View>
      ) : null}

      <View style={{ backgroundColor: colors.card, marginTop: spacing.lg }}>
        <ListItem icon="shield-check-outline" title="Safety tips" onPress={() => router.push('/safety')} />
        <Divider />
        <ListItem
          icon="swap-horizontal"
          title="Exchange rate used"
          subtitle={rate ? `US$1 ≈ L$${rate} (for price hints only)` : 'Not available'}
        />
        <Divider />
        <ListItem icon="signal-cellular-2" title="Data saver" subtitle="Always on: compressed photos, cached images, small pages" />
      </View>

      {user ? (
        <View style={{ backgroundColor: colors.card, marginTop: spacing.lg }}>
          <ListItem icon="logout" title="Log out" onPress={logout} danger />
          <Divider />
          <ListItem icon="account-remove-outline" title="Delete account" onPress={deleteAccount} danger />
        </View>
      ) : null}

      <Text style={{ textAlign: 'center', color: colors.textLight, marginTop: spacing.xl, fontSize: 12 }}>
        LibMarket v{Constants.expoConfig?.version ?? '1.0.0'}
      </Text>
    </ScrollView>
  );
}
