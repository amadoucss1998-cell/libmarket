import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import React from 'react';
import { Alert, FlatList, Text, View } from 'react-native';
import { Avatar, Button, Divider, EmptyState, ErrorState, Loading } from '@/components/ui';
import { colors, spacing } from '@/constants/colors';
import { useAuth } from '@/hooks/useAuth';
import { fetchBlocks, unblockUser } from '@/lib/api';
import { qk } from '@/lib/queryClient';
import { errorMessage } from '@/lib/supabase';

export default function BlockedUsersScreen() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const uid = user?.id ?? 'anon';
  const q = useQuery({ queryKey: qk.blocks(uid), queryFn: fetchBlocks, enabled: !!user });
  const unblock = useMutation({
    mutationFn: unblockUser,
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: qk.blocks(uid) });
      qc.invalidateQueries({ queryKey: ['feed'] });
      qc.invalidateQueries({ queryKey: ['inbox'] });
    },
    onError: (e) => Alert.alert('Could not unblock', errorMessage(e)),
  });

  if (q.isLoading) return <Loading />;
  if (q.isError) return <ErrorState message={errorMessage(q.error)} onRetry={() => q.refetch()} />;

  return (
    <FlatList
      style={{ backgroundColor: colors.white }}
      data={q.data ?? []}
      keyExtractor={(b) => b.blocked_id}
      ItemSeparatorComponent={Divider}
      contentContainerStyle={{ flexGrow: 1 }}
      renderItem={({ item }) => (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.md, padding: spacing.md }}>
          <Avatar uri={item.user?.avatar_url} name={item.user?.display_name} />
          <Text style={{ flex: 1, fontSize: 16, fontWeight: '600', color: colors.text }}>{item.user?.display_name ?? 'LibMarket user'}</Text>
          <Button
            title="Unblock"
            small
            variant="outline"
            loading={unblock.isPending && unblock.variables === item.blocked_id}
            onPress={() => unblock.mutate(item.blocked_id)}
          />
        </View>
      )}
      ListEmptyComponent={<EmptyState icon="account-check-outline" title="No blocked users" />}
    />
  );
}
