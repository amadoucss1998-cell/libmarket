import { useQuery, useQueryClient } from '@tanstack/react-query';
import { router, Stack, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useMemo, useRef } from 'react';
import { Alert, FlatList, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ImageCarousel } from '@/components/ImageCarousel';
import { cardFromSearch, ListingCard } from '@/components/ListingCard';
import { useCardWidth } from '@/components/ListingGrid';
import { Price } from '@/components/Price';
import { SafetyBanner } from '@/components/SafetyBanner';
import { SellerCard } from '@/components/SellerCard';
import { Badge, Button, EmptyState, ErrorState, Icon, IconButton, Loading, SectionTitle } from '@/components/ui';
import { categoryIcon } from '@/constants/categories';
import { colors, radius, spacing } from '@/constants/colors';
import { conditionLabel } from '@/constants/options';
import { useAuth, useRequireAuth } from '@/hooks/useAuth';
import { useFavorites } from '@/hooks/useFavorites';
import { useOwnerListingActions, useStartChat } from '@/hooks/useListingActions';
import { blockUser, fetchListing, incrementListingView, searchListings } from '@/lib/api';
import { timeAgo } from '@/lib/format';
import { qk } from '@/lib/queryClient';
import { callPhone, listingShareText, openWhatsAppChat, shareMenu, shareToWhatsApp } from '@/lib/share';
import { errorMessage } from '@/lib/supabase';

export default function ListingDetailScreen() {
  const { id, posted } = useLocalSearchParams<{ id: string; posted?: string }>();
  const { user } = useAuth();
  const requireAuth = useRequireAuth();
  const insets = useSafeAreaInsets();
  const qc = useQueryClient();
  const { isSaved, toggle } = useFavorites();
  const { start, starting } = useStartChat();
  const owner = useOwnerListingActions();
  const cardWidth = useCardWidth(2.3);

  const q = useQuery({ queryKey: qk.listing(id), queryFn: () => fetchListing(id), enabled: !!id });
  const listing = q.data;

  // Count one view per screen open.
  const counted = useRef(false);
  useEffect(() => {
    if (id && !counted.current) {
      counted.current = true;
      incrementListingView(id).catch(() => {});
    }
  }, [id]);

  const similar = useQuery({
    queryKey: qk.similar(id),
    queryFn: () => searchListings({ category: listing!.category_id, sort: 'newest' }, 0, 11),
    enabled: !!listing,
    staleTime: 5 * 60 * 1000,
  });
  const similarItems = useMemo(
    () => (similar.data ?? []).filter((c) => c.id !== id).slice(0, 10).map(cardFromSearch),
    [similar.data, id],
  );

  const isOwner = !!user && listing?.seller_id === user.id;
  const seller = listing?.seller ?? null;
  const shareText = listing ? listingShareText(listing) : '';
  const photoPaths = useMemo(() => [...(listing?.listing_images ?? [])].sort((a, b) => a.sort - b.sort).map((i) => i.path), [listing]);

  const moreMenu = () => {
    if (!listing) return;
    const buttons: { text: string; style?: 'cancel' | 'destructive'; onPress?: () => void }[] = [
      { text: 'Report this item', onPress: () => requireAuth('report') && router.push(`/report?listingId=${listing.id}`) },
    ];
    if (!isOwner && seller) {
      buttons.push({ text: 'Report seller', onPress: () => requireAuth('report') && router.push(`/report?userId=${seller.id}`) });
      buttons.push({ text: 'Block seller', style: 'destructive', onPress: confirmBlock });
    }
    buttons.push({ text: 'Cancel', style: 'cancel' });
    Alert.alert('More', undefined, buttons);
  };

  const confirmBlock = () => {
    if (!seller || !requireAuth('block users')) return;
    Alert.alert(`Block ${seller.display_name}?`, "You won't see each other's items and can't message each other.", [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Block',
        style: 'destructive',
        onPress: async () => {
          try {
            await blockUser(seller.id);
            qc.invalidateQueries({ queryKey: ['feed'] });
            qc.invalidateQueries({ queryKey: ['search'] });
            qc.invalidateQueries({ queryKey: ['inbox'] });
            Alert.alert('Blocked', `${seller.display_name} is blocked. You can unblock in Settings.`);
            router.back();
          } catch (e) {
            Alert.alert('Could not block', errorMessage(e));
          }
        },
      },
    ]);
  };

  const headerRight = () =>
    listing ? (
      <View style={{ flexDirection: 'row' }}>
        {!isOwner ? (
          <IconButton
            name={isSaved(listing.id) ? 'heart' : 'heart-outline'}
            color={isSaved(listing.id) ? colors.primary : colors.text}
            label={isSaved(listing.id) ? 'Remove from saved' : 'Save item'}
            onPress={() => toggle(listing.id)}
          />
        ) : null}
        <IconButton name="share-variant-outline" label="Share" onPress={() => shareMenu(shareText)} />
        <IconButton name="dots-vertical" label="More options" onPress={moreMenu} />
      </View>
    ) : null;

  if (q.isLoading) return <Loading />;
  if (q.isError) return <ErrorState message={errorMessage(q.error)} onRetry={() => q.refetch()} />;
  if (!listing || listing.status === 'deleted') {
    return (
      <EmptyState
        icon="package-variant-closed-remove"
        title="Item not available"
        message="This item was removed or is no longer visible."
        action={{ label: 'Back to browsing', onPress: () => router.replace('/') }}
      />
    );
  }

  const available = listing.status === 'active' || listing.status === 'reserved';

  return (
    <View style={{ flex: 1, backgroundColor: colors.white }}>
      <Stack.Screen options={{ title: '', headerRight }} />
      <ScrollView contentContainerStyle={{ paddingBottom: 120 }}>
        <ImageCarousel paths={photoPaths} />
        <View style={styles.body}>
          {posted ? (
            <View style={styles.posted}>
              <Icon name="party-popper" size={24} color={colors.success} />
              <View style={{ flex: 1 }}>
                <Text style={styles.postedTitle}>Your item is live!</Text>
                <Text style={styles.postedText}>Share it with friends and groups to sell faster.</Text>
              </View>
              <Button title="WhatsApp" variant="whatsapp" icon="whatsapp" small onPress={() => shareToWhatsApp(shareText)} />
            </View>
          ) : null}

          <View style={styles.badges}>
            {listing.status === 'reserved' ? <Badge label="Reserved" color={colors.warning} bg={colors.warningSoft} /> : null}
            {listing.status === 'sold' ? <Badge label="Sold" color={colors.white} bg={colors.text} /> : null}
            {listing.is_boosted ? <Badge label="Promoted" color={colors.white} bg={colors.primary} icon="star" /> : null}
            {listing.negotiable ? <Badge label="Negotiable" color={colors.success} bg={colors.successSoft} /> : <Badge label="Fixed price" />}
            <Badge label={conditionLabel(listing.condition)} />
          </View>

          <Price amount={listing.price} currency={listing.currency} size={28} inline />
          <Text style={styles.title}>{listing.title}</Text>

          <View style={styles.metaRow}>
            <Meta icon="map-marker-outline" text={listing.community || listing.city} />
            <Meta icon="clock-outline" text={timeAgo(listing.created_at)} />
            <Meta icon="eye-outline" text={`${listing.view_count} views`} />
            {listing.favorite_count > 0 ? <Meta icon="heart-outline" text={`${listing.favorite_count}`} /> : null}
          </View>
          {listing.category ? (
            <View style={[styles.metaRow, { marginTop: 4 }]}>
              <Meta icon={categoryIcon(listing.category)} text={listing.category.name} />
            </View>
          ) : null}

          {listing.description ? (
            <>
              <SectionTitle>Description</SectionTitle>
              <Text style={styles.description}>{listing.description}</Text>
            </>
          ) : null}

          <SafetyBanner />

          {seller ? (
            <>
              <SectionTitle>Seller</SectionTitle>
              <SellerCard seller={seller} />
            </>
          ) : null}

          {similarItems.length ? <SectionTitle>Similar items</SectionTitle> : null}
        </View>
        {similarItems.length ? (
          <FlatList
            horizontal
            data={similarItems}
            keyExtractor={(i) => i.id}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: spacing.md, gap: spacing.md }}
            renderItem={({ item }) => <ListingCard item={item} width={cardWidth} />}
          />
        ) : null}
      </ScrollView>

      {/* Sticky action bar */}
      <View style={[styles.bar, { paddingBottom: Math.max(insets.bottom, spacing.sm) }]}>
        {isOwner ? (
          <>
            {listing.status !== 'sold' ? (
              <Button title="Edit" icon="pencil-outline" variant="outline" small style={{ flex: 1 }} onPress={() => router.push(`/listing/edit/${listing.id}`)} />
            ) : null}
            {listing.status === 'active' ? (
              <Button title="Reserve" icon="bookmark-outline" variant="outline" small style={{ flex: 1 }} onPress={() => owner.setStatus(listing.id, 'reserved')} />
            ) : listing.status === 'reserved' ? (
              <Button title="Unreserve" icon="bookmark-off-outline" variant="outline" small style={{ flex: 1 }} onPress={() => owner.setStatus(listing.id, 'active')} />
            ) : null}
            {listing.status !== 'sold' ? (
              <Button title="Mark sold" icon="check-circle-outline" small style={{ flex: 1.2 }} onPress={() => owner.markSold(listing.id)} />
            ) : (
              <Button title="Relist" icon="refresh" small style={{ flex: 1 }} onPress={() => owner.setStatus(listing.id, 'active')} />
            )}
            <IconButton name="trash-can-outline" color={colors.danger} label="Delete item" onPress={() => owner.remove(listing.id, () => router.back())} />
          </>
        ) : available ? (
          <>
            <Button title="Chat" icon="chat-outline" small style={{ flex: 1.2 }} loading={starting} onPress={() => start(listing.id)} />
            <Button title="Offer" icon="tag-outline" variant="secondary" small style={{ flex: 1 }} onPress={() => start(listing.id, { offer: true })} />
            {seller?.whatsapp ? (
              <IconButton
                name="whatsapp"
                color={colors.whatsapp}
                size={28}
                label="WhatsApp seller"
                style={styles.roundBtn}
                onPress={() => requireAuth('contact the seller') && openWhatsAppChat(seller.whatsapp!, listing.title)}
              />
            ) : null}
            {seller?.phone ? (
              <IconButton
                name="phone-outline"
                color={colors.secondary}
                size={26}
                label="Call seller"
                style={styles.roundBtn}
                onPress={() => requireAuth('call the seller') && callPhone(seller.phone!)}
              />
            ) : null}
          </>
        ) : (
          <Text style={styles.unavailable}>This item has been sold.</Text>
        )}
      </View>
    </View>
  );
}

function Meta({ icon, text }: { icon: string; text: string }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
      <Icon name={icon} size={16} color={colors.textMuted} />
      <Text style={{ color: colors.textMuted, fontSize: 13 }}>{text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  body: { padding: spacing.lg, paddingBottom: 0 },
  badges: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: spacing.sm },
  title: { fontSize: 20, fontWeight: '700', color: colors.text, marginTop: spacing.xs, lineHeight: 26 },
  metaRow: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.md, marginTop: spacing.sm },
  description: { fontSize: 15, color: colors.text, lineHeight: 22 },
  posted: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.successSoft,
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  postedTitle: { fontWeight: '800', color: colors.success, fontSize: 16 },
  postedText: { color: colors.text, fontSize: 13 },
  bar: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    paddingHorizontal: spacing.md,
    paddingTop: spacing.sm,
    backgroundColor: colors.white,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.border,
  },
  roundBtn: { borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, width: 48, height: 44 },
  unavailable: { flex: 1, textAlign: 'center', color: colors.textMuted, fontWeight: '700', paddingVertical: spacing.md },
});
