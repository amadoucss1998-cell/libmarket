import { useQuery } from '@tanstack/react-query';
import { router, useLocalSearchParams } from 'expo-router';
import React from 'react';
import { View } from 'react-native';
import { ListingForm } from '@/components/ListingForm';
import { Button, EmptyState, ErrorState, Loading } from '@/components/ui';
import { colors, spacing } from '@/constants/colors';
import { useAuth } from '@/hooks/useAuth';
import { useOwnerListingActions } from '@/hooks/useListingActions';
import { fetchListing } from '@/lib/api';
import { qk } from '@/lib/queryClient';
import { errorMessage } from '@/lib/supabase';

export default function EditListingScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { user } = useAuth();
  const owner = useOwnerListingActions();
  const q = useQuery({ queryKey: qk.listing(id), queryFn: () => fetchListing(id), enabled: !!id });

  if (q.isLoading) return <Loading />;
  if (q.isError) return <ErrorState message={errorMessage(q.error)} onRetry={() => q.refetch()} />;
  const listing = q.data;
  if (!listing || !user || listing.seller_id !== user.id) {
    return <EmptyState icon="lock-outline" title="You can't edit this item" message="Only the seller can edit an item." />;
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.white }}>
      <ListingForm initial={listing} onDone={() => router.back()} />
      <View style={{ flexDirection: 'row', gap: spacing.sm, padding: spacing.md, borderTopWidth: 1, borderTopColor: colors.border }}>
        {listing.status === 'active' ? (
          <Button title="Reserve" variant="outline" small style={{ flex: 1 }} onPress={() => owner.setStatus(listing.id, 'reserved')} />
        ) : listing.status === 'reserved' ? (
          <Button title="Unreserve" variant="outline" small style={{ flex: 1 }} onPress={() => owner.setStatus(listing.id, 'active')} />
        ) : null}
        <Button title="Mark sold" variant="outline" small style={{ flex: 1 }} onPress={() => owner.markSold(listing.id, () => router.back())} />
        <Button title="Delete" variant="danger" small style={{ flex: 1 }} onPress={() => owner.remove(listing.id, () => router.replace('/profile'))} />
      </View>
    </View>
  );
}
