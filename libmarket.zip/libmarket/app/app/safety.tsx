import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { Icon } from '@/components/ui';
import { colors, radius, spacing } from '@/constants/colors';
import { SAFETY_TIPS } from '@/constants/options';

const ICONS = ['account-group-outline', 'magnify-scan', 'cash-remove', 'cellphone-check', 'message-alert-outline', 'flag-outline'];

export default function SafetyScreen() {
  return (
    <ScrollView style={{ backgroundColor: colors.white }} contentContainerStyle={{ padding: spacing.lg, gap: spacing.md }}>
      <Text style={styles.intro}>Most deals on LibMarket go well. Follow these tips to stay safe every time.</Text>
      {SAFETY_TIPS.map((tip, i) => (
        <View key={tip} style={styles.tip}>
          <Icon name={ICONS[i] ?? 'shield-check-outline'} size={26} color={colors.secondary} />
          <Text style={styles.tipText}>{tip}</Text>
        </View>
      ))}
      <Text style={styles.footer}>
        Prohibited on LibMarket: weapons, drugs, bushmeat and wildlife, stolen goods, prescription medicines, counterfeit money and
        adult content. Report anything suspicious with the ⋮ menu.
      </Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  intro: { fontSize: 15, color: colors.textMuted, lineHeight: 22 },
  tip: {
    flexDirection: 'row',
    gap: spacing.md,
    alignItems: 'center',
    backgroundColor: colors.secondarySoft,
    borderRadius: radius.md,
    padding: spacing.md,
  },
  tipText: { flex: 1, fontSize: 15, color: colors.text, lineHeight: 21 },
  footer: { fontSize: 13, color: colors.textMuted, lineHeight: 19, marginTop: spacing.md },
});
