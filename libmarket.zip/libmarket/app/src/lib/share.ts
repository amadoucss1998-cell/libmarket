import { Alert, Linking, Share } from 'react-native';
import { formatPrice, waDigits } from './format';
import type { CurrencyCode } from '@/types/database';

const BASE = (process.env.EXPO_PUBLIC_SHARE_BASE_URL || 'https://libmarket.app').replace(/\/$/, '');

export function listingLink(id: string) {
  return `${BASE}/l/${id}`;
}

export function listingShareText(l: { id: string; title: string; price: number; currency: CurrencyCode; community: string | null; city: string }) {
  return `${l.title} – ${formatPrice(l.price, l.currency)} in ${l.community || l.city}. See it on LibMarket: ${listingLink(l.id)}`;
}

/** Share straight to WhatsApp; falls back to the native share sheet if WhatsApp isn't installed. */
export async function shareToWhatsApp(text: string) {
  try {
    await Linking.openURL(`whatsapp://send?text=${encodeURIComponent(text)}`);
  } catch {
    await Share.share({ message: text });
  }
}

export async function shareNative(text: string) {
  try {
    await Share.share({ message: text });
  } catch {
    /* user cancelled */
  }
}

export function shareMenu(text: string) {
  Alert.alert('Share item', undefined, [
    { text: 'WhatsApp', onPress: () => shareToWhatsApp(text) },
    { text: 'More options…', onPress: () => shareNative(text) },
    { text: 'Cancel', style: 'cancel' },
  ]);
}

/** Open a WhatsApp chat with the seller, prefilled with the listing title. */
export async function openWhatsAppChat(phone: string, title: string) {
  const text = `Hi, I saw your "${title}" on LibMarket. Is it still available?`;
  const url = `https://wa.me/${waDigits(phone)}?text=${encodeURIComponent(text)}`;
  try {
    await Linking.openURL(url);
  } catch {
    Alert.alert('Could not open WhatsApp', `You can message the seller at ${phone}.`);
  }
}

export async function callPhone(phone: string) {
  try {
    await Linking.openURL(`tel:${phone.replace(/[^0-9+]/g, '')}`);
  } catch {
    Alert.alert('Could not start the call', phone);
  }
}
