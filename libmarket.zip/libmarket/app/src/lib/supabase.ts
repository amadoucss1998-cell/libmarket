import 'react-native-url-polyfill/auto';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createClient } from '@supabase/supabase-js';
import { AppState, Platform } from 'react-native';
import type { Database } from '@/types/database';

const url = process.env.EXPO_PUBLIC_SUPABASE_URL ?? '';
const anonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ?? '';

/** False when .env is missing: the app shows a setup screen instead of crashing. */
export const isSupabaseConfigured = /^https?:\/\//.test(url) && anonKey.length > 20;

export const supabase = createClient<Database>(
  isSupabaseConfigured ? url : 'https://placeholder.supabase.co',
  isSupabaseConfigured ? anonKey : 'placeholder-anon-key-placeholder-anon-key',
  {
    auth: {
      storage: AsyncStorage,
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: false,
    },
  },
);

// Only refresh tokens while the app is in the foreground (saves data and battery).
if (Platform.OS !== 'web') {
  AppState.addEventListener('change', (state) => {
    if (state === 'active') supabase.auth.startAutoRefresh();
    else supabase.auth.stopAutoRefresh();
  });
}

export const BUCKET = {
  listingImages: 'listing-images',
  avatars: 'avatars',
  messageImages: 'message-images',
} as const;

const useTransforms = process.env.EXPO_PUBLIC_IMAGE_TRANSFORMS === 'true';

/** Public URL of a listing image. `thumb` requests ~400px when image transforms are enabled. */
export function listingImageUrl(path: string | null | undefined, thumb = false): string | null {
  if (!path) return null;
  const opts = thumb && useTransforms ? { transform: { width: 400, quality: 60 } } : undefined;
  return supabase.storage.from(BUCKET.listingImages).getPublicUrl(path, opts).data.publicUrl;
}

/** Turn a Supabase/PostgREST error into a message users can read. */
export function errorMessage(err: unknown, fallback = 'Something went wrong. Please try again.'): string {
  if (!err) return fallback;
  if (typeof err === 'string') return err;
  const e = err as { message?: string; code?: string };
  if (e.code === '42501') return 'You are not allowed to do that (the user may be blocked).';
  if (e.message?.includes('Network request failed') || e.message?.includes('Failed to fetch')) {
    return 'No internet connection. Check your data and try again.';
  }
  return e.message || fallback;
}
