import { router } from 'expo-router';
import { fetchMyProfile } from './api';
import { queryClient, qk } from './queryClient';

/**
 * After a successful sign-in: go to profile setup if the profile is incomplete,
 * otherwise close the auth screens and return the user to where they were.
 * `depth` = how many auth screens are on the stack (login = 1, login+verify = 2).
 */
export async function finishSignIn(userId: string, depth: number) {
  let needsSetup = false;
  try {
    const profile = await fetchMyProfile(userId);
    queryClient.setQueryData(qk.profile(userId), profile);
    needsSetup = !profile?.community;
  } catch {
    needsSetup = false;
  }
  if (needsSetup) {
    router.replace(`/auth/profile-setup?onboarding=1&depth=${depth}`);
  } else {
    closeAuth(depth);
  }
}

export function closeAuth(depth: number) {
  if (router.canGoBack()) router.dismiss(Math.max(1, depth));
  else router.replace('/');
}
