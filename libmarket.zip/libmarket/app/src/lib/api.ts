/**
 * All Supabase calls used by the app. Schema reference: ../supabase/API.md.
 * Functions throw on error so React Query can surface error states.
 */
import type {
  BlockWithUser,
  FavoriteWithListing,
  ListingDetail,
  ListingWithImages,
  ReviewWithReviewer,
  SearchFilters,
} from '@/types/app';
import type {
  CategoryRow,
  ConversationRow,
  InboxRow,
  ListingCard,
  ListingInsert,
  ListingRow,
  ListingStatus,
  ListingUpdate,
  MessageInsert,
  MessageRow,
  ProfileRow,
  ProfileUpdate,
  PublicProfileRow,
  ReportInsert,
  ReviewInsert,
  SavedSearchInsert,
  SavedSearchRow,
  SearchListingsArgs,
} from '@/types/database';
import { compressImage, newImageName, uploadJpeg, type PickedImage } from './images';
import { BUCKET, supabase } from './supabase';

export const PAGE_SIZE = 20;
export const MESSAGES_PAGE = 30;

/** Throw on error, return non-null data (lists, .single(), RPCs). */
function must<D>(res: { data: D; error: unknown }): NonNullable<D> {
  if (res.error) throw res.error;
  return res.data as NonNullable<D>;
}

/** Throw on error, return data that may be null (.maybeSingle()). */
function maybe<D>(res: { data: D; error: unknown }): D {
  if (res.error) throw res.error;
  return res.data;
}

/* ------------------------------ reference data ----------------------------- */

export async function fetchCategories(): Promise<CategoryRow[]> {
  return must(await supabase.from('categories').select('*').order('sort'));
}

export async function fetchLrdPerUsd(): Promise<number | null> {
  const row = maybe(await supabase.from('app_config').select('*').eq('key', 'lrd_per_usd').maybeSingle());
  const n = Number(row?.value);
  return Number.isFinite(n) && n > 0 ? n : null;
}

/* ---------------------------------- search --------------------------------- */

export function filtersToArgs(f: Partial<SearchFilters>): SearchListingsArgs {
  return {
    q: f.q?.trim() || null,
    category: f.category ?? null,
    min_price: f.minPrice ?? null,
    max_price: f.maxPrice ?? null,
    currency: f.currency ?? null,
    condition: f.condition ?? null,
    community: f.community ?? null,
    sort: f.sort ?? null,
  };
}

export async function searchListings(args: SearchListingsArgs, offset: number, limit = PAGE_SIZE): Promise<ListingCard[]> {
  return must(await supabase.rpc('search_listings', { ...args, limit, offset })) ?? [];
}

/* --------------------------------- listings -------------------------------- */

const LISTING_COLS =
  'id, seller_id, title, description, price, currency, negotiable, condition, category_id, community, city, lat, lng, status, view_count, favorite_count, is_boosted, boosted_until, sold_at, created_at, updated_at';

export async function fetchListing(id: string): Promise<ListingDetail | null> {
  const res = await supabase
    .from('listings')
    .select(`${LISTING_COLS}, seller:public_profiles(*), category:categories(*), listing_images(id, path, sort)`)
    .eq('id', id)
    .order('sort', { referencedTable: 'listing_images' })
    .maybeSingle();
  return maybe(res) as unknown as ListingDetail | null;
}

export async function incrementListingView(id: string): Promise<void> {
  await supabase.rpc('increment_listing_view', { listing_id: id });
}

export async function fetchMyListings(userId: string): Promise<ListingWithImages[]> {
  const res = await supabase
    .from('listings')
    .select(`${LISTING_COLS}, listing_images(id, path, sort)`)
    .eq('seller_id', userId)
    .neq('status', 'deleted')
    .order('created_at', { ascending: false })
    .order('sort', { referencedTable: 'listing_images' });
  return must(res) as unknown as ListingWithImages[];
}

export async function fetchSellerListings(sellerId: string): Promise<ListingWithImages[]> {
  const res = await supabase
    .from('listings')
    .select(`${LISTING_COLS}, listing_images(id, path, sort)`)
    .eq('seller_id', sellerId)
    .in('status', ['active', 'reserved'])
    .order('created_at', { ascending: false })
    .order('sort', { referencedTable: 'listing_images' })
    .limit(60);
  return must(res) as unknown as ListingWithImages[];
}

export async function createListing(input: ListingInsert): Promise<ListingRow> {
  return must(await supabase.from('listings').insert(input).select().single());
}

export async function updateListing(id: string, patch: ListingUpdate): Promise<void> {
  must(await supabase.from('listings').update(patch).eq('id', id).select('id').single());
}

export async function setListingStatus(id: string, status: Exclude<ListingStatus, 'sold'>): Promise<void> {
  await updateListing(id, { status });
}

export async function markListingSold(id: string): Promise<ListingRow> {
  return must(await supabase.rpc('mark_listing_sold', { listing_id: id }));
}

/** Compress + upload photos one at a time, inserting listing_images rows. Returns the number that failed. */
export async function uploadListingPhotos(
  userId: string,
  listingId: string,
  photos: { image: PickedImage; sort: number }[],
  onProgress?: (done: number, total: number) => void,
): Promise<number> {
  let failed = 0;
  for (let i = 0; i < photos.length; i++) {
    const { image, sort } = photos[i];
    try {
      const c = await compressImage(image);
      const path = `${userId}/${listingId}/${newImageName()}`;
      await uploadJpeg(BUCKET.listingImages, path, c.base64);
      must(await supabase.from('listing_images').insert({ listing_id: listingId, path, sort }).select('id').single());
    } catch (e) {
      console.warn('photo upload failed', e);
      failed++;
    }
    onProgress?.(i + 1, photos.length);
  }
  return failed;
}

export async function deleteListingImage(id: string, path: string): Promise<void> {
  must(await supabase.from('listing_images').delete().eq('id', id));
  await supabase.storage.from(BUCKET.listingImages).remove([path]);
}

export async function updateListingImageSort(id: string, sort: number): Promise<void> {
  must(await supabase.from('listing_images').update({ sort }).eq('id', id));
}

/* -------------------------------- favorites -------------------------------- */

export async function fetchFavoriteIds(): Promise<string[]> {
  const rows = must(await supabase.from('favorites').select('listing_id'));
  return (rows ?? []).map((r) => r.listing_id);
}

export async function fetchFavorites(): Promise<FavoriteWithListing[]> {
  const res = await supabase
    .from('favorites')
    .select(`created_at, listing:listings(${LISTING_COLS}, listing_images(id, path, sort))`)
    .order('created_at', { ascending: false });
  return must(res) as unknown as FavoriteWithListing[];
}

export async function addFavorite(listingId: string): Promise<void> {
  must(await supabase.from('favorites').upsert({ listing_id: listingId }, { ignoreDuplicates: true }));
}

export async function removeFavorite(listingId: string): Promise<void> {
  must(await supabase.from('favorites').delete().eq('listing_id', listingId));
}

/* ----------------------------------- chat ---------------------------------- */

export async function startConversation(listingId: string): Promise<ConversationRow> {
  return must(await supabase.rpc('start_conversation', { listing_id: listingId }));
}

export async function fetchInbox(): Promise<InboxRow[]> {
  const res = await supabase.from('inbox').select('*').order('last_message_at', { ascending: false, nullsFirst: false });
  return must(res) ?? [];
}

export async function fetchInboxRow(conversationId: string): Promise<InboxRow | null> {
  return maybe(await supabase.from('inbox').select('*').eq('id', conversationId).maybeSingle());
}

export async function fetchMessages(conversationId: string, page: number): Promise<MessageRow[]> {
  const from = page * MESSAGES_PAGE;
  const res = await supabase
    .from('messages')
    .select('*')
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: false })
    .range(from, from + MESSAGES_PAGE - 1);
  return must(res) ?? [];
}

export async function sendMessage(msg: MessageInsert): Promise<MessageRow> {
  return must(await supabase.from('messages').insert(msg).select().single());
}

export async function sendImageMessage(conversationId: string, userId: string, image: PickedImage): Promise<MessageRow> {
  const c = await compressImage(image);
  const path = `${conversationId}/${userId}/${newImageName()}`;
  await uploadJpeg(BUCKET.messageImages, path, c.base64);
  return sendMessage({ conversation_id: conversationId, kind: 'image', image_path: path, body: null });
}

export async function respondToOffer(messageId: string, accept: boolean): Promise<MessageRow> {
  return must(await supabase.rpc('respond_to_offer', { message_id: messageId, accept }));
}

export async function markConversationRead(conversationId: string): Promise<void> {
  const { error } = await supabase.rpc('mark_conversation_read', { conversation_id: conversationId });
  if (error) console.warn('mark read failed', error.message);
}

export async function signedMessageImageUrl(path: string): Promise<string> {
  const { data, error } = await supabase.storage.from(BUCKET.messageImages).createSignedUrl(path, 60 * 60);
  if (error || !data) throw error ?? new Error('No URL');
  return data.signedUrl;
}

/* --------------------------------- profiles -------------------------------- */

export async function fetchMyProfile(userId: string): Promise<ProfileRow | null> {
  return maybe(await supabase.from('profiles').select('*').eq('id', userId).maybeSingle());
}

export async function updateMyProfile(userId: string, patch: ProfileUpdate): Promise<void> {
  must(await supabase.from('profiles').update(patch).eq('id', userId));
}

export async function uploadAvatar(userId: string, image: PickedImage): Promise<string> {
  const c = await compressImage(image, 512);
  const path = `${userId}/avatar.jpg`;
  await uploadJpeg(BUCKET.avatars, path, c.base64, { upsert: true });
  const url = supabase.storage.from(BUCKET.avatars).getPublicUrl(path).data.publicUrl;
  // Cache-bust so expo-image shows the new picture immediately.
  return `${url}?v=${Date.now()}`;
}

export async function fetchPublicProfile(id: string): Promise<PublicProfileRow | null> {
  return maybe(await supabase.from('public_profiles').select('*').eq('id', id).maybeSingle());
}

/* ---------------------------------- reviews -------------------------------- */

export async function fetchReviewsFor(userId: string): Promise<ReviewWithReviewer[]> {
  const res = await supabase
    .from('reviews')
    .select('*, reviewer:public_profiles!reviews_reviewer_id_fkey(display_name, avatar_url)')
    .eq('reviewee_id', userId)
    .order('created_at', { ascending: false })
    .limit(50);
  return must(res) as unknown as ReviewWithReviewer[];
}

export async function fetchMyReviewForListing(reviewerId: string, listingId: string) {
  return maybe(
    await supabase.from('reviews').select('*').eq('reviewer_id', reviewerId).eq('listing_id', listingId).maybeSingle(),
  );
}

export async function createReview(input: ReviewInsert): Promise<void> {
  must(await supabase.from('reviews').insert(input));
}

export async function updateReview(id: string, rating: ReviewInsert['rating'], comment: string | null): Promise<void> {
  must(await supabase.from('reviews').update({ rating, comment }).eq('id', id));
}

/* ----------------------------- reports & blocks ---------------------------- */

export async function submitReport(input: ReportInsert): Promise<void> {
  // No .select(): users cannot read reports. Exactly one target is set.
  const res =
    'listing_id' in input && input.listing_id
      ? await supabase.from('reports').insert({ listing_id: input.listing_id, reason: input.reason, details: input.details ?? null })
      : await supabase
          .from('reports')
          .insert({ reported_user_id: (input as { reported_user_id: string }).reported_user_id, reason: input.reason, details: input.details ?? null });
  if (res.error) throw res.error;
}

export async function blockUser(userId: string): Promise<void> {
  const { error } = await supabase.from('blocks').insert({ blocked_id: userId });
  // 23505 = already blocked: treat as success.
  if (error && error.code !== '23505') throw error;
}

export async function unblockUser(userId: string): Promise<void> {
  must(await supabase.from('blocks').delete().eq('blocked_id', userId));
}

export async function fetchBlocks(): Promise<BlockWithUser[]> {
  const res = await supabase
    .from('blocks')
    .select('blocked_id, created_at, user:public_profiles!blocks_blocked_id_fkey(display_name, avatar_url)')
    .order('created_at', { ascending: false });
  return must(res) as unknown as BlockWithUser[];
}

/* ------------------------------ saved searches ----------------------------- */

export async function fetchSavedSearches(): Promise<SavedSearchRow[]> {
  return must(await supabase.from('saved_searches').select('*').order('created_at', { ascending: false })) ?? [];
}

export async function saveSearch(input: SavedSearchInsert): Promise<void> {
  must(await supabase.from('saved_searches').insert(input));
}

export async function deleteSavedSearch(id: string): Promise<void> {
  must(await supabase.from('saved_searches').delete().eq('id', id));
}
