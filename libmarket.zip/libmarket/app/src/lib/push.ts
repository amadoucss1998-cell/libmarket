import AsyncStorage from '@react-native-async-storage/async-storage';
import Constants, { ExecutionEnvironment } from 'expo-constants';
import * as Device from 'expo-device';
import { Platform } from 'react-native';
import { supabase } from './supabase';

const TOKEN_KEY = 'libmarket.pushToken';

/**
 * Remote push is unavailable in Expo Go (Android, SDK 53+) and on emulators/simulators,
 * and needs an EAS projectId (set by `eas init`). In those cases we skip silently.
 */
function pushSupported(): boolean {
  if (Platform.OS === 'web') return false;
  if (!Device.isDevice) return false;
  if (Constants.executionEnvironment === ExecutionEnvironment.StoreClient) return false;
  return !!projectId();
}

function projectId(): string | undefined {
  const extra = Constants.expoConfig?.extra as { eas?: { projectId?: string } } | undefined;
  return extra?.eas?.projectId ?? Constants.easConfig?.projectId ?? undefined;
}

/** Ask permission, get the Expo push token and store it with register_push_token. */
export async function registerForPush(): Promise<string | null> {
  if (!pushSupported()) return null;
  try {
    // Imported lazily so Expo Go never evaluates the push module.
    const Notifications = await import('expo-notifications');
    Notifications.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowBanner: true,
        shouldShowList: true,
        shouldPlaySound: true,
        shouldSetBadge: false,
      }),
    });
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('default', {
        name: 'Messages',
        importance: Notifications.AndroidImportance.HIGH,
        lightColor: '#C8102E',
      });
    }
    let { status } = await Notifications.getPermissionsAsync();
    if (status !== 'granted') status = (await Notifications.requestPermissionsAsync()).status;
    if (status !== 'granted') return null;

    const token = (await Notifications.getExpoPushTokenAsync({ projectId: projectId() })).data;
    const { error } = await supabase.rpc('register_push_token', {
      token,
      platform: Platform.OS === 'ios' ? 'ios' : 'android',
    });
    if (error) throw error;
    await AsyncStorage.setItem(TOKEN_KEY, token);
    return token;
  } catch (e) {
    console.warn('push registration skipped:', e);
    return null;
  }
}

/** Remove this device's token before signing out so the old account stops receiving pushes. */
export async function unregisterPush(): Promise<void> {
  try {
    const token = await AsyncStorage.getItem(TOKEN_KEY);
    if (token) {
      await supabase.from('push_tokens').delete().eq('token', token);
      await AsyncStorage.removeItem(TOKEN_KEY);
    }
  } catch (e) {
    console.warn('push unregister failed', e);
  }
}
