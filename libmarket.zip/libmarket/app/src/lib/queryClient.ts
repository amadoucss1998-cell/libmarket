import AsyncStorage from '@react-native-async-storage/async-storage';
import NetInfo from '@react-native-community/netinfo';
import { createAsyncStoragePersister } from '@tanstack/query-async-storage-persister';
import { focusManager, onlineManager, QueryClient } from '@tanstack/react-query';
import { AppState, Platform } from 'react-native';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60_000,
      gcTime: 24 * 60 * 60 * 1000,
      retry: 2,
      refetchOnWindowFocus: true,
    },
    mutations: { retry: 0 },
  },
});

/** Persist only small, useful-offline queries (reference data + first feed pages). */
const PERSISTED_ROOTS = new Set(['categories', 'lrdRate', 'feed']);

export const persister = createAsyncStoragePersister({
  storage: AsyncStorage,
  key: 'libmarket.queryCache',
  throttleTime: 2000,
});

export const persistOptions = {
  persister,
  maxAge: 24 * 60 * 60 * 1000,
  buster: 'v1',
  dehydrateOptions: {
    shouldDehydrateQuery: (q: { queryKey: readonly unknown[]; state: { status: string } }) =>
      q.state.status === 'success' && PERSISTED_ROOTS.has(String(q.queryKey[0])),
  },
};

// React Query <-> React Native wiring: refetch on app focus, pause when offline.
onlineManager.setEventListener((setOnline) =>
  NetInfo.addEventListener((state) => setOnline(state.isConnected !== false)),
);
if (Platform.OS !== 'web') {
  AppState.addEventListener('change', (s) => focusManager.setFocused(s === 'active'));
}

/** Central query keys. */
export const qk = {
  categories: ['categories'] as const,
  lrdRate: ['lrdRate'] as const,
  feed: (args: unknown) => ['feed', args] as const,
  search: (args: unknown) => ['search', args] as const,
  listing: (id: string) => ['listing', id] as const,
  similar: (id: string) => ['similar', id] as const,
  myListings: (uid: string) => ['myListings', uid] as const,
  sellerListings: (id: string) => ['sellerListings', id] as const,
  favoriteIds: (uid: string) => ['favoriteIds', uid] as const,
  favorites: (uid: string) => ['favorites', uid] as const,
  inbox: (uid: string) => ['inbox', uid] as const,
  inboxRow: (id: string) => ['inboxRow', id] as const,
  messages: (id: string) => ['messages', id] as const,
  profile: (uid: string) => ['profile', uid] as const,
  publicProfile: (id: string) => ['publicProfile', id] as const,
  reviews: (id: string) => ['reviews', id] as const,
  blocks: (uid: string) => ['blocks', uid] as const,
  savedSearches: (uid: string) => ['savedSearches', uid] as const,
  signedUrl: (path: string) => ['signedUrl', path] as const,
};
