import type { CurrencyCode } from '@/types/database';

/** 1234567.5 -> "1,234,568" (no Intl dependency, safe on all Hermes builds). */
export function groupThousands(n: number, decimals = 0): string {
  const fixed = Math.abs(n).toFixed(decimals);
  const [int, frac] = fixed.split('.');
  const withCommas = int.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return (n < 0 ? '-' : '') + withCommas + (frac && Number(frac) !== 0 ? '.' + frac : '');
}

/** USD "$1,200" (cents shown only if present), LRD "L$25,000". Price 0 -> "Free". */
export function formatPrice(amount: number, currency: CurrencyCode, opts: { freeLabel?: boolean } = {}): string {
  if (opts.freeLabel !== false && amount === 0) return 'Free';
  if (currency === 'USD') {
    const hasCents = Math.round(amount * 100) % 100 !== 0;
    return '$' + groupThousands(amount, hasCents ? 2 : 0);
  }
  return 'L$' + groupThousands(Math.round(amount));
}

/** "≈ L$228,000" / "≈ $63" — approximate value in the other currency, or null. */
export function approxOther(amount: number, currency: CurrencyCode, lrdPerUsd: number | null | undefined): string | null {
  if (!lrdPerUsd || lrdPerUsd <= 0 || amount <= 0) return null;
  if (currency === 'USD') return '≈ ' + formatPrice(roundNice(amount * lrdPerUsd), 'LRD');
  return '≈ ' + formatPrice(Math.max(1, Math.round(amount / lrdPerUsd)), 'USD');
}

function roundNice(n: number): number {
  if (n >= 10000) return Math.round(n / 100) * 100;
  if (n >= 1000) return Math.round(n / 10) * 10;
  return Math.round(n);
}

export function timeAgo(iso: string | null | undefined): string {
  if (!iso) return '';
  const diff = Math.max(0, Date.now() - new Date(iso).getTime());
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 7) return `${d}d ago`;
  if (d < 30) return `${Math.floor(d / 7)}w ago`;
  if (d < 365) return `${Math.floor(d / 30)}mo ago`;
  return `${Math.floor(d / 365)}y ago`;
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
export function monthYear(iso: string): string {
  const d = new Date(iso);
  return `${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

export function clockTime(iso: string): string {
  const d = new Date(iso);
  const h = d.getHours();
  const mm = String(d.getMinutes()).padStart(2, '0');
  return `${((h + 11) % 12) + 1}:${mm} ${h < 12 ? 'AM' : 'PM'}`;
}

/** Liberian phone normalisation: "0770 123 456" / "770123456" / "+231770123456" -> "+231770123456". */
export function normalizeLiberianPhone(input: string): string {
  const digits = input.replace(/[^0-9+]/g, '');
  if (digits.startsWith('+')) return '+' + digits.slice(1).replace(/\+/g, '');
  if (digits.startsWith('00')) return '+' + digits.slice(2);
  if (digits.startsWith('231')) return '+' + digits;
  if (digits.startsWith('0')) return '+231' + digits.slice(1);
  return '+231' + digits;
}

/** Matches the DB check: ^\+?[0-9][0-9 -]{5,19}$ */
export function isValidPhone(p: string): boolean {
  return /^\+?[0-9][0-9 -]{5,19}$/.test(p);
}

/** Digits only, for wa.me links. */
export function waDigits(phone: string): string {
  return normalizeLiberianPhone(phone).replace(/[^0-9]/g, '');
}

/** Parse a user-typed price like "1,200.50" -> 1200.5, or null. */
export function parsePrice(text: string): number | null {
  const cleaned = text.replace(/[^0-9.]/g, '');
  if (!cleaned) return null;
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : null;
}
