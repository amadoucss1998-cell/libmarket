import { decode } from 'base64-arraybuffer';
import * as Crypto from 'expo-crypto';
import { ImageManipulator, SaveFormat } from 'expo-image-manipulator';
import * as ImagePicker from 'expo-image-picker';
import { Alert } from 'react-native';
import { BUCKET, supabase } from './supabase';

export type PickedImage = { uri: string; width: number; height: number };
export type CompressedImage = { uri: string; base64: string; bytes: number; width: number; height: number };

const MAX_EDGE = 1080;
const TARGET_BYTES = 250 * 1024;

/**
 * Resize so the long edge is <= 1080px and save as JPEG ~70%.
 * If the result is still well over ~250KB, re-encode at lower quality (max 2 extra passes).
 */
export async function compressImage(img: PickedImage, maxEdge = MAX_EDGE): Promise<CompressedImage> {
  let ctx = ImageManipulator.manipulate(img.uri);
  const longEdge = Math.max(img.width || 0, img.height || 0);
  if (longEdge > maxEdge) {
    ctx = (img.width || 0) >= (img.height || 0) ? ctx.resize({ width: maxEdge }) : ctx.resize({ height: maxEdge });
  }
  const ref = await ctx.renderAsync();
  let quality = 0.7;
  let out = await ref.saveAsync({ compress: quality, format: SaveFormat.JPEG, base64: true });
  let bytes = base64Bytes(out.base64 ?? '');
  for (let i = 0; i < 2 && bytes > TARGET_BYTES * 1.2; i++) {
    quality -= 0.15;
    out = await ref.saveAsync({ compress: quality, format: SaveFormat.JPEG, base64: true });
    bytes = base64Bytes(out.base64 ?? '');
  }
  if (!out.base64) throw new Error('Could not read the photo. Please try another one.');
  return { uri: out.uri, base64: out.base64, bytes, width: out.width, height: out.height };
}

function base64Bytes(b64: string): number {
  return Math.floor((b64.length * 3) / 4);
}

/** Upload a compressed JPEG to a bucket, retrying on network failure. Returns the storage path. */
export async function uploadJpeg(
  bucket: (typeof BUCKET)[keyof typeof BUCKET],
  path: string,
  base64: string,
  { upsert = false, retries = 2 }: { upsert?: boolean; retries?: number } = {},
): Promise<string> {
  let lastError: unknown;
  for (let attempt = 0; attempt <= retries; attempt++) {
    const { error } = await supabase.storage
      .from(bucket)
      .upload(path, decode(base64), { contentType: 'image/jpeg', upsert, cacheControl: '31536000' });
    if (!error) return path;
    lastError = error;
    await new Promise((r) => setTimeout(r, 800 * (attempt + 1)));
  }
  throw lastError;
}

export const newImageName = () => `${Crypto.randomUUID()}.jpg`;

/** Ask for camera / library permission and pick photos. Returns [] if cancelled. */
export async function pickImages(source: 'camera' | 'library', limit: number): Promise<PickedImage[]> {
  if (limit <= 0) return [];
  if (source === 'camera') {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('Camera permission needed', 'Allow camera access in your phone settings to take photos.');
      return [];
    }
    const res = await ImagePicker.launchCameraAsync({ mediaTypes: ['images'], quality: 0.8 });
    if (res.canceled) return [];
    return res.assets.map((a) => ({ uri: a.uri, width: a.width, height: a.height }));
  }
  const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!perm.granted) {
    Alert.alert('Photos permission needed', 'Allow photo access in your phone settings to add pictures.');
    return [];
  }
  const res = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ['images'],
    allowsMultipleSelection: limit > 1,
    selectionLimit: limit,
    quality: 0.8,
  });
  if (res.canceled) return [];
  return res.assets.slice(0, limit).map((a) => ({ uri: a.uri, width: a.width, height: a.height }));
}

/** Let the user choose camera or gallery via a simple alert. */
export function chooseImageSource(onPick: (source: 'camera' | 'library') => void) {
  Alert.alert('Add photo', undefined, [
    { text: 'Take photo', onPress: () => onPick('camera') },
    { text: 'Choose from gallery', onPress: () => onPick('library') },
    { text: 'Cancel', style: 'cancel' },
  ]);
}
