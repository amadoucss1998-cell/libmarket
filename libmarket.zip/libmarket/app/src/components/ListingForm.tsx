import { useQueryClient } from '@tanstack/react-query';
import * as Crypto from 'expo-crypto';
import { Image } from 'expo-image';
import React, { useMemo, useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import { colors, radius, spacing } from '@/constants/colors';
import { cityForCommunity } from '@/constants/communities';
import { CONDITIONS, DESCRIPTION_MAX, MAX_PHOTOS, PHOTO_TIPS, TITLE_MAX } from '@/constants/options';
import { useAuth } from '@/hooks/useAuth';
import { useCategories, useLrdRate } from '@/hooks/useReferenceData';
import {
  createListing,
  deleteListingImage,
  updateListing,
  updateListingImageSort,
  uploadListingPhotos,
} from '@/lib/api';
import { approxOther, parsePrice } from '@/lib/format';
import { chooseImageSource, pickImages, type PickedImage } from '@/lib/images';
import { errorMessage, listingImageUrl } from '@/lib/supabase';
import type { ListingDetail } from '@/types/app';
import type { CurrencyCode, ListingCondition } from '@/types/database';
import { CategoryPicker } from './CategoryChips';
import { CommunityPicker } from './CommunityPicker';
import { Picker } from './FiltersSheet';
import { Badge, Button, Chip, Icon, IconButton, TextField } from './ui';

type Photo =
  | { key: string; kind: 'local'; image: PickedImage }
  | { key: string; kind: 'remote'; id: string; path: string };

function photoUri(p: Photo): string {
  return p.kind === 'local' ? p.image.uri : listingImageUrl(p.path, true) ?? '';
}

export function ListingForm({ initial, onDone }: { initial?: ListingDetail | null; onDone: (listingId: string) => void }) {
  const { user, profile } = useAuth();
  const qc = useQueryClient();
  const { byId } = useCategories();
  const rate = useLrdRate();
  const isEdit = !!initial;

  const initialPhotos: Photo[] = useMemo(
    () =>
      [...(initial?.listing_images ?? [])]
        .sort((a, b) => a.sort - b.sort)
        .map((img) => ({ key: img.id, kind: 'remote' as const, id: img.id, path: img.path })),
    [initial],
  );

  const [photos, setPhotos] = useState<Photo[]>(initialPhotos);
  const [title, setTitle] = useState(initial?.title ?? '');
  const [description, setDescription] = useState(initial?.description ?? '');
  const [categoryId, setCategoryId] = useState<number | null>(initial?.category_id ?? null);
  const [condition, setCondition] = useState<ListingCondition | null>(initial?.condition ?? null);
  const [priceText, setPriceText] = useState(initial ? String(initial.price) : '');
  const [currency, setCurrency] = useState<CurrencyCode>(initial?.currency ?? 'USD');
  const [negotiable, setNegotiable] = useState(initial?.negotiable ?? true);
  const [community, setCommunity] = useState<string | null>(initial?.community ?? profile?.community ?? null);
  const [catOpen, setCatOpen] = useState(false);
  const [commOpen, setCommOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [progress, setProgress] = useState<string | null>(null);
  const [touched, setTouched] = useState(false);

  const price = parsePrice(priceText);
  const errors = {
    photos: photos.length === 0 ? 'Add at least one photo' : null,
    title: title.trim().length < 3 ? 'Title must be at least 3 characters' : null,
    category: categoryId == null ? 'Choose a category' : null,
    condition: condition == null ? 'Choose the condition' : null,
    price: price == null ? 'Enter a price (0 for free)' : null,
    community: !community ? 'Choose where the item is' : null,
  };
  const firstError = Object.values(errors).find(Boolean) ?? null;

  const addPhotos = async (source: 'camera' | 'library') => {
    const remaining = MAX_PHOTOS - photos.length;
    const picked = await pickImages(source, remaining);
    if (picked.length) {
      setPhotos((prev) => [...prev, ...picked.map((image) => ({ key: Crypto.randomUUID(), kind: 'local' as const, image }))].slice(0, MAX_PHOTOS));
    }
  };

  const removePhoto = (key: string) => setPhotos((prev) => prev.filter((p) => p.key !== key));
  const makeCover = (key: string) =>
    setPhotos((prev) => {
      const p = prev.find((x) => x.key === key);
      return p ? [p, ...prev.filter((x) => x.key !== key)] : prev;
    });

  const invalidate = (id: string) => {
    qc.invalidateQueries({ queryKey: ['listing', id] });
    qc.invalidateQueries({ queryKey: ['myListings'] });
    qc.invalidateQueries({ queryKey: ['feed'] });
    qc.invalidateQueries({ queryKey: ['search'] });
  };

  const submit = async () => {
    setTouched(true);
    if (firstError || !user || price == null || categoryId == null || condition == null) {
      if (firstError) Alert.alert('Check your item', firstError);
      return;
    }
    setSubmitting(true);
    const fields = {
      title: title.trim(),
      description: description.trim(),
      price,
      currency,
      negotiable,
      condition,
      category_id: categoryId,
      community,
      city: cityForCommunity(community),
    };
    try {
      let listingId: string;
      if (!isEdit) {
        setProgress('Creating your ad…');
        const row = await createListing(fields);
        listingId = row.id;
      } else {
        listingId = initial!.id;
        setProgress('Saving changes…');
        await updateListing(listingId, fields);
        // Removed photos
        const keep = new Set(photos.filter((p) => p.kind === 'remote').map((p) => p.key));
        for (const old of initialPhotos) {
          if (old.kind === 'remote' && !keep.has(old.key)) await deleteListingImage(old.id, old.path);
        }
        // Re-order kept photos
        const oldSort = new Map((initial!.listing_images ?? []).map((i) => [i.id, i.sort]));
        for (let i = 0; i < photos.length; i++) {
          const p = photos[i];
          if (p.kind === 'remote' && oldSort.get(p.id) !== i) await updateListingImageSort(p.id, i);
        }
      }

      const toUpload = photos
        .map((p, i) => ({ p, sort: i }))
        .filter((x): x is { p: Extract<Photo, { kind: 'local' }>; sort: number } => x.p.kind === 'local')
        .map((x) => ({ image: x.p.image, sort: x.sort }));
      let failed = 0;
      if (toUpload.length) {
        setProgress(`Uploading photo 1 of ${toUpload.length}…`);
        failed = await uploadListingPhotos(user.id, listingId, toUpload, (done, total) =>
          setProgress(`Uploading photo ${Math.min(done + 1, total)} of ${total}…`),
        );
      }
      invalidate(listingId);
      if (failed > 0) {
        Alert.alert(
          'Some photos did not upload',
          `${failed} photo${failed > 1 ? 's' : ''} failed (weak connection?). Your ad is saved. Open "Edit" to add them again.`,
        );
      }
      onDone(listingId);
    } catch (e) {
      Alert.alert(isEdit ? 'Could not save changes' : 'Could not post your item', errorMessage(e));
    } finally {
      setSubmitting(false);
      setProgress(null);
    }
  };

  const approx = price != null && price > 0 ? approxOther(price, currency, rate) : null;

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        {/* Photos */}
        <Text style={styles.label}>
          Photos <Text style={styles.muted}>({photos.length}/{MAX_PHOTOS})</Text>
        </Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: spacing.sm }}>
          {photos.length < MAX_PHOTOS ? (
            <Pressable
              onPress={() => chooseImageSource(addPhotos)}
              accessibilityRole="button"
              accessibilityLabel="Add photos"
              style={[styles.addPhoto, touched && errors.photos ? { borderColor: colors.danger } : null]}
            >
              <Icon name="camera-plus-outline" size={30} color={colors.primary} />
              <Text style={styles.addPhotoText}>Add photos</Text>
            </Pressable>
          ) : null}
          {photos.map((p, i) => (
            <View key={p.key} style={styles.thumbWrap}>
              <Pressable onPress={() => i > 0 && makeCover(p.key)} accessibilityLabel={i === 0 ? 'Cover photo' : 'Make cover photo'}>
                <Image source={{ uri: photoUri(p) }} style={styles.thumb} contentFit="cover" />
              </Pressable>
              {i === 0 ? (
                <View style={styles.coverBadge}>
                  <Badge label="Cover" color={colors.white} bg={colors.secondary} />
                </View>
              ) : null}
              <IconButton
                name="close-circle"
                color={colors.white}
                size={22}
                label="Remove photo"
                onPress={() => removePhoto(p.key)}
                style={styles.removeBtn}
              />
            </View>
          ))}
        </ScrollView>
        <View style={styles.tips}>
          <Icon name="lightbulb-on-outline" size={16} color={colors.secondary} />
          <Text style={styles.tipsText}>{PHOTO_TIPS.join(' · ')}. Tap a photo to make it the cover.</Text>
        </View>
        {touched && errors.photos ? <Text style={styles.error}>{errors.photos}</Text> : null}

        {/* Details */}
        <TextField
          label="Title"
          value={title}
          onChangeText={setTitle}
          placeholder="e.g. Tecno Camon 20 Pro 256GB"
          maxLength={TITLE_MAX}
          counter
          error={touched ? errors.title : null}
          style={{ marginTop: spacing.lg }}
        />

        <Text style={styles.label}>Category</Text>
        <Picker
          value={categoryId != null ? byId.get(categoryId)?.name ?? 'Category' : null}
          placeholder="Choose category"
          icon="shape-outline"
          onPress={() => setCatOpen(true)}
        />
        {touched && errors.category ? <Text style={styles.error}>{errors.category}</Text> : null}

        <Text style={[styles.label, { marginTop: spacing.lg }]}>Condition</Text>
        <View style={styles.wrap}>
          {CONDITIONS.map((c) => (
            <Chip key={c.value} label={c.label} selected={condition === c.value} onPress={() => setCondition(c.value)} />
          ))}
        </View>
        {touched && errors.condition ? <Text style={styles.error}>{errors.condition}</Text> : null}

        <Text style={[styles.label, { marginTop: spacing.lg }]}>Price</Text>
        <View style={{ flexDirection: 'row', gap: spacing.sm, alignItems: 'flex-start' }}>
          <TextField
            value={priceText}
            onChangeText={setPriceText}
            placeholder="0"
            keyboardType="numeric"
            prefix={currency === 'USD' ? '$' : 'L$'}
            style={{ flex: 1 }}
            error={touched ? errors.price : null}
            hint={approx ?? 'Enter 0 to give it away free'}
            accessibilityLabel="Price"
          />
          <View style={styles.currencyToggle}>
            {(['USD', 'LRD'] as const).map((c) => (
              <Pressable
                key={c}
                onPress={() => setCurrency(c)}
                accessibilityRole="button"
                accessibilityState={{ selected: currency === c }}
                style={[styles.currencyBtn, currency === c && styles.currencyBtnActive]}
              >
                <Text style={[styles.currencyText, currency === c && { color: colors.white }]}>{c}</Text>
              </Pressable>
            ))}
          </View>
        </View>
        <View style={styles.switchRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.switchLabel}>Price is negotiable</Text>
            <Text style={styles.muted}>Buyers can make offers</Text>
          </View>
          <Switch
            value={negotiable}
            onValueChange={setNegotiable}
            trackColor={{ true: colors.primary, false: colors.border }}
            thumbColor={colors.white}
            accessibilityLabel="Price is negotiable"
          />
        </View>

        <Text style={[styles.label, { marginTop: spacing.lg }]}>Location</Text>
        <Picker value={community} placeholder="Choose community" icon="map-marker-outline" onPress={() => setCommOpen(true)} />
        {touched && errors.community ? <Text style={styles.error}>{errors.community}</Text> : null}

        <TextField
          label="Description"
          value={description}
          onChangeText={setDescription}
          placeholder="Size, model, how long you used it, any damage, what's included, landmark for meeting…"
          multiline
          maxLength={DESCRIPTION_MAX}
          counter
          style={{ marginTop: spacing.lg }}
        />

        <Button
          title={isEdit ? 'Save changes' : 'Post item'}
          icon={isEdit ? 'content-save-outline' : 'check'}
          onPress={submit}
          loading={submitting}
          style={{ marginTop: spacing.sm }}
        />
        {progress ? <Text style={[styles.muted, { textAlign: 'center', marginTop: spacing.sm }]}>{progress}</Text> : null}
        <Text style={[styles.muted, { textAlign: 'center', marginTop: spacing.md }]}>
          Photos are compressed to save data (~250KB each). By posting you agree not to sell prohibited items.
        </Text>
      </ScrollView>

      <CategoryPicker visible={catOpen} onClose={() => setCatOpen(false)} value={categoryId} onSelect={setCategoryId} />
      <CommunityPicker visible={commOpen} onClose={() => setCommOpen(false)} selected={community} onSelect={setCommunity} />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  content: { padding: spacing.lg, paddingBottom: 120 },
  label: { fontSize: 15, fontWeight: '700', color: colors.text, marginBottom: spacing.sm },
  muted: { fontSize: 12, color: colors.textMuted, fontWeight: '400' },
  error: { fontSize: 12, color: colors.danger, marginTop: 4 },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  addPhoto: {
    width: 104,
    height: 104,
    borderRadius: radius.md,
    borderWidth: 2,
    borderStyle: 'dashed',
    borderColor: colors.primary,
    backgroundColor: colors.primarySoft,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
  },
  addPhotoText: { color: colors.primary, fontWeight: '700', fontSize: 13 },
  thumbWrap: { width: 104, height: 104 },
  thumb: { width: 104, height: 104, borderRadius: radius.md, backgroundColor: colors.skeleton },
  coverBadge: { position: 'absolute', bottom: 6, left: 6 },
  removeBtn: { position: 'absolute', top: -6, right: -6, minWidth: 36, minHeight: 36 },
  tips: {
    flexDirection: 'row',
    gap: 6,
    alignItems: 'flex-start',
    backgroundColor: colors.secondarySoft,
    borderRadius: radius.sm,
    padding: spacing.sm,
    marginTop: spacing.sm,
  },
  tipsText: { flex: 1, fontSize: 12, color: colors.secondary, lineHeight: 17 },
  currencyToggle: {
    flexDirection: 'row',
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: 'hidden',
    height: 48,
  },
  currencyBtn: { paddingHorizontal: 14, justifyContent: 'center', backgroundColor: colors.white, minWidth: 56, alignItems: 'center' },
  currencyBtnActive: { backgroundColor: colors.secondary },
  currencyText: { fontWeight: '800', color: colors.secondary },
  switchRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: spacing.sm },
  switchLabel: { fontSize: 15, fontWeight: '600', color: colors.text },
});
