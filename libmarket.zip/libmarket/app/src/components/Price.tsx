import React from 'react';
import { Text, View, type StyleProp, type TextStyle } from 'react-native';
import { colors } from '@/constants/colors';
import { useLrdRate } from '@/hooks/useReferenceData';
import { approxOther, formatPrice } from '@/lib/format';
import type { CurrencyCode } from '@/types/database';

/** Price in its own currency, with an optional grey "≈ other currency" hint. */
export function Price({
  amount,
  currency,
  showApprox = true,
  size = 16,
  style,
  inline,
}: {
  amount: number;
  currency: CurrencyCode;
  showApprox?: boolean;
  size?: number;
  style?: StyleProp<TextStyle>;
  inline?: boolean;
}) {
  const rate = useLrdRate();
  const approx = showApprox ? approxOther(amount, currency, rate) : null;
  return (
    <View style={inline ? { flexDirection: 'row', alignItems: 'baseline', gap: 6, flexWrap: 'wrap' } : undefined}>
      <Text style={[{ fontSize: size, fontWeight: '800', color: colors.text }, style]} numberOfLines={1}>
        {formatPrice(amount, currency)}
      </Text>
      {approx ? (
        <Text style={{ fontSize: Math.max(11, size * 0.62), color: colors.textMuted }} numberOfLines={1}>
          {approx}
        </Text>
      ) : null}
    </View>
  );
}
