import { router } from 'expo-router';
import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, radius, spacing } from '@/constants/colors';
import { monthYear } from '@/lib/format';
import type { PublicProfileRow } from '@/types/database';
import { Avatar, Icon, Stars, VerifiedTick } from './ui';

/** Seller trust card: avatar, name, verified, rating, member since, community. */
export function SellerCard({ seller }: { seller: PublicProfileRow }) {
  return (
    <Pressable
      onPress={() => router.push(`/user/${seller.id}`)}
      accessibilityRole="button"
      accessibilityLabel={`Seller ${seller.display_name}. View profile`}
      style={({ pressed }) => [styles.card, pressed && { opacity: 0.9 }]}
    >
      <Avatar uri={seller.avatar_url} name={seller.display_name} size={56} />
      <View style={{ flex: 1, gap: 3 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
          <Text style={styles.name} numberOfLines={1}>
            {seller.display_name}
          </Text>
          {seller.is_verified ? <VerifiedTick /> : null}
        </View>
        {seller.rating_count > 0 ? (
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
            <Stars value={Number(seller.rating_avg)} />
            <Text style={styles.meta}>
              {Number(seller.rating_avg).toFixed(1)} ({seller.rating_count})
            </Text>
          </View>
        ) : (
          <Text style={styles.meta}>No reviews yet</Text>
        )}
        <Text style={styles.meta}>
          Member since {monthYear(seller.created_at)}
          {seller.community ? ` · ${seller.community}` : ''}
        </Text>
        {seller.is_verified ? <Text style={[styles.meta, { color: colors.secondary, fontWeight: '700' }]}>Verified seller</Text> : null}
      </View>
      <Icon name="chevron-right" size={24} color={colors.textLight} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    padding: spacing.md,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.card,
  },
  name: { fontSize: 17, fontWeight: '800', color: colors.text, flexShrink: 1 },
  meta: { fontSize: 13, color: colors.textMuted },
});
