import { router } from 'expo-router';
import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, radius, spacing } from '@/constants/colors';
import { SAFETY_BANNER } from '@/constants/options';
import { Icon, IconButton } from './ui';

export function SafetyBanner({ text = SAFETY_BANNER, onDismiss, compact }: { text?: string; onDismiss?: () => void; compact?: boolean }) {
  return (
    <Pressable
      onPress={() => router.push('/safety')}
      accessibilityRole="button"
      accessibilityHint="Opens safety tips"
      style={[styles.banner, compact && { marginHorizontal: 0, marginVertical: 0, borderRadius: 0 }]}
    >
      <Icon name="shield-check-outline" size={22} color={colors.warning} />
      <View style={{ flex: 1 }}>
        <Text style={styles.text}>{text}</Text>
        <Text style={styles.link}>Safety tips ›</Text>
      </View>
      {onDismiss ? <IconButton name="close" size={18} label="Hide safety notice" onPress={onDismiss} color={colors.warning} /> : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  banner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.warningSoft,
    padding: spacing.md,
    borderRadius: radius.md,
    marginVertical: spacing.md,
  },
  text: { color: '#78350F', fontSize: 13, lineHeight: 18, fontWeight: '600' },
  link: { color: colors.warning, fontSize: 12, fontWeight: '700', marginTop: 2 },
});
