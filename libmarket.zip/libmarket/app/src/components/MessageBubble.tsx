import { useQuery } from '@tanstack/react-query';
import { Image } from 'expo-image';
import React, { memo, useState } from 'react';
import { ActivityIndicator, Modal, Pressable, StyleSheet, Text, useWindowDimensions, View } from 'react-native';
import { colors, radius, spacing } from '@/constants/colors';
import { SCAM_PATTERN } from '@/constants/options';
import { signedMessageImageUrl } from '@/lib/api';
import { clockTime, formatPrice } from '@/lib/format';
import { qk } from '@/lib/queryClient';
import type { MessageRow } from '@/types/database';
import { Button, Icon, IconButton } from './ui';

type Props = {
  message: MessageRow;
  mine: boolean;
  isSeller: boolean;
  onRespond?: (messageId: string, accept: boolean) => void;
  responding?: boolean;
};

export const MessageBubble = memo(function MessageBubble({ message: m, mine, isSeller, onRespond, responding }: Props) {
  if (m.kind === 'system') {
    return (
      <View style={styles.systemWrap}>
        <Text style={styles.system}>{m.body}</Text>
        {m.body?.toLowerCase().includes('accepted') ? (
          <Text style={styles.systemHint}>Deal agreed. Meet in a public place and inspect before you pay.</Text>
        ) : null}
      </View>
    );
  }

  const suspicious = !mine && m.kind === 'text' && !!m.body && SCAM_PATTERN.test(m.body);

  return (
    <View style={[styles.row, mine ? styles.rowMine : styles.rowOther]}>
      {m.kind === 'offer' ? (
        <OfferCard m={m} mine={mine} isSeller={isSeller} onRespond={onRespond} responding={responding} />
      ) : m.kind === 'image' && m.image_path ? (
        <ChatImage path={m.image_path} />
      ) : (
        <View style={[styles.bubble, mine ? styles.bubbleMine : styles.bubbleOther]}>
          <Text style={[styles.text, mine && { color: colors.white }]}>{m.body}</Text>
        </View>
      )}
      {suspicious ? (
        <View style={styles.warn}>
          <Icon name="alert-outline" size={16} color={colors.warning} />
          <Text style={styles.warnText}>Careful: never send mobile money or a "deposit" before you see the item.</Text>
        </View>
      ) : null}
      <Text style={[styles.time, mine && { textAlign: 'right' }]}>
        {clockTime(m.created_at)}
        {mine ? (m.read_at ? ' · Seen' : ' · Sent') : ''}
      </Text>
    </View>
  );
});

function OfferCard({ m, mine, isSeller, onRespond, responding }: Omit<Props, 'message'> & { m: MessageRow }) {
  const amount = m.offer_amount != null && m.offer_currency ? formatPrice(m.offer_amount, m.offer_currency, { freeLabel: false }) : '';
  const status = m.offer_status ?? 'pending';
  const statusStyle =
    status === 'accepted'
      ? { bg: colors.successSoft, fg: colors.success, label: 'Accepted' }
      : status === 'declined'
        ? { bg: colors.background, fg: colors.textMuted, label: 'Declined' }
        : { bg: colors.warningSoft, fg: colors.warning, label: 'Waiting for seller' };
  return (
    <View style={styles.offer}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
        <Icon name="tag-outline" size={18} color={colors.secondary} />
        <Text style={styles.offerLabel}>{mine ? 'Your offer' : 'Offer'}</Text>
      </View>
      <Text style={styles.offerAmount}>{amount}</Text>
      {m.body ? <Text style={styles.text}>{m.body}</Text> : null}
      <View style={[styles.offerStatus, { backgroundColor: statusStyle.bg }]}>
        <Text style={{ color: statusStyle.fg, fontWeight: '700', fontSize: 12 }}>{statusStyle.label}</Text>
      </View>
      {isSeller && !mine && status === 'pending' && onRespond ? (
        <View style={{ flexDirection: 'row', gap: spacing.sm, marginTop: spacing.sm }}>
          <Button title="Decline" variant="outline" small style={{ flex: 1 }} disabled={responding} onPress={() => onRespond(m.id, false)} />
          <Button title="Accept" small style={{ flex: 1 }} loading={responding} onPress={() => onRespond(m.id, true)} />
        </View>
      ) : null}
      {status === 'accepted' ? <Text style={styles.offerHint}>Deal agreed. Meet safely and inspect before paying.</Text> : null}
    </View>
  );
}

function ChatImage({ path }: { path: string }) {
  const { width, height } = useWindowDimensions();
  const [open, setOpen] = useState(false);
  const q = useQuery({ queryKey: qk.signedUrl(path), queryFn: () => signedMessageImageUrl(path), staleTime: 50 * 60 * 1000 });
  const size = Math.min(220, width * 0.6);
  if (!q.data) {
    return (
      <View style={[styles.imageBox, { width: size, height: size }]}>
        {q.isError ? <Icon name="image-broken-variant" size={28} color={colors.textLight} /> : <ActivityIndicator color={colors.primary} />}
      </View>
    );
  }
  return (
    <>
      <Pressable onPress={() => setOpen(true)} accessibilityLabel="Open photo">
        <Image source={{ uri: q.data }} style={[styles.imageBox, { width: size, height: size }]} contentFit="cover" cachePolicy="disk" />
      </Pressable>
      <Modal visible={open} onRequestClose={() => setOpen(false)} animationType="fade" statusBarTranslucent>
        <View style={{ flex: 1, backgroundColor: '#000' }}>
          <Image source={{ uri: q.data }} style={{ width, height }} contentFit="contain" />
          <IconButton name="close" color={colors.white} label="Close" onPress={() => setOpen(false)} style={{ position: 'absolute', top: 40, right: 8 }} />
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  row: { marginVertical: 3, maxWidth: '82%' },
  rowMine: { alignSelf: 'flex-end', alignItems: 'flex-end' },
  rowOther: { alignSelf: 'flex-start', alignItems: 'flex-start' },
  bubble: { paddingHorizontal: 14, paddingVertical: 9, borderRadius: 18 },
  bubbleMine: { backgroundColor: colors.secondary, borderBottomRightRadius: 4 },
  bubbleOther: { backgroundColor: colors.background, borderBottomLeftRadius: 4 },
  text: { fontSize: 15, color: colors.text, lineHeight: 21 },
  time: { fontSize: 11, color: colors.textLight, marginTop: 2, marginHorizontal: 4 },
  systemWrap: { alignSelf: 'center', alignItems: 'center', marginVertical: spacing.sm, maxWidth: '90%' },
  system: {
    fontSize: 13,
    color: colors.textMuted,
    backgroundColor: colors.background,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: radius.pill,
    overflow: 'hidden',
    fontWeight: '600',
  },
  systemHint: { fontSize: 12, color: colors.success, marginTop: 4, textAlign: 'center' },
  offer: {
    borderWidth: 1,
    borderColor: colors.secondary,
    borderRadius: radius.lg,
    padding: spacing.md,
    backgroundColor: colors.white,
    minWidth: 220,
    gap: 4,
  },
  offerLabel: { fontSize: 13, fontWeight: '700', color: colors.secondary },
  offerAmount: { fontSize: 24, fontWeight: '900', color: colors.text },
  offerStatus: { alignSelf: 'flex-start', paddingHorizontal: 8, paddingVertical: 3, borderRadius: radius.pill, marginTop: 4 },
  offerHint: { fontSize: 12, color: colors.success, marginTop: 4 },
  imageBox: { borderRadius: radius.md, backgroundColor: colors.skeleton, alignItems: 'center', justifyContent: 'center' },
  warn: {
    flexDirection: 'row',
    gap: 6,
    alignItems: 'flex-start',
    backgroundColor: colors.warningSoft,
    borderRadius: radius.sm,
    padding: spacing.sm,
    marginTop: 4,
  },
  warnText: { flex: 1, fontSize: 12, color: '#78350F' },
});
