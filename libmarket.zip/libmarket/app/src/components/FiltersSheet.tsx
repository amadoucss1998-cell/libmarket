import React, { useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { colors, radius, spacing } from '@/constants/colors';
import { CONDITIONS, SORTS } from '@/constants/options';
import { useCategories } from '@/hooks/useReferenceData';
import { parsePrice } from '@/lib/format';
import { EMPTY_FILTERS, type SearchFilters } from '@/types/app';
import { CategoryPicker } from './CategoryChips';
import { CommunityPicker } from './CommunityPicker';
import { Sheet } from './Sheet';
import { Button, Chip, Icon, TextField } from './ui';

export function countActiveFilters(f: SearchFilters): number {
  return [f.category, f.minPrice, f.maxPrice, f.currency, f.condition, f.community, f.sort].filter((v) => v != null).length;
}

export function FiltersSheet({
  visible,
  onClose,
  value,
  onApply,
}: {
  visible: boolean;
  onClose: () => void;
  value: SearchFilters;
  onApply: (f: SearchFilters) => void;
}) {
  const [draft, setDraft] = useState<SearchFilters>(value);
  const [minText, setMinText] = useState('');
  const [maxText, setMaxText] = useState('');
  const [catOpen, setCatOpen] = useState(false);
  const [commOpen, setCommOpen] = useState(false);
  const { byId } = useCategories();

  useEffect(() => {
    if (visible) {
      setDraft(value);
      setMinText(value.minPrice != null ? String(value.minPrice) : '');
      setMaxText(value.maxPrice != null ? String(value.maxPrice) : '');
    }
  }, [visible, value]);

  const set = <K extends keyof SearchFilters>(k: K, v: SearchFilters[K]) => setDraft((d) => ({ ...d, [k]: v }));

  const min = parsePrice(minText);
  const max = parsePrice(maxText);
  const rangeError = min != null && max != null && min > max ? 'Min price must be lower than max price' : null;
  const priceUnit = draft.currency === 'LRD' ? 'L$' : '$';

  const apply = () => {
    onApply({ ...draft, minPrice: min, maxPrice: max });
    onClose();
  };

  return (
    <Sheet
      visible={visible}
      onClose={onClose}
      title="Filters"
      fullHeight
      footer={
        <View style={{ flexDirection: 'row', gap: spacing.sm }}>
          <Button
            title="Reset"
            variant="outline"
            style={{ flex: 1 }}
            onPress={() => {
              setDraft({ ...EMPTY_FILTERS, q: draft.q });
              setMinText('');
              setMaxText('');
            }}
          />
          <Button title="Show results" style={{ flex: 2 }} onPress={apply} disabled={!!rangeError} />
        </View>
      }
    >
      <ScrollView contentContainerStyle={{ padding: spacing.lg, paddingTop: 0 }} keyboardShouldPersistTaps="handled">
        <Text style={styles.label}>Category</Text>
        <Picker value={draft.category != null ? byId.get(draft.category)?.name ?? 'Category' : 'Any category'} icon="shape-outline" onPress={() => setCatOpen(true)} />

        <Text style={styles.label}>Community</Text>
        <Picker value={draft.community ?? 'All Liberia'} icon="map-marker-outline" onPress={() => setCommOpen(true)} />

        <Text style={styles.label}>Currency</Text>
        <View style={styles.row}>
          {([null, 'USD', 'LRD'] as const).map((c) => (
            <Chip key={String(c)} label={c ?? 'Any'} selected={draft.currency === c} onPress={() => set('currency', c)} />
          ))}
        </View>

        <Text style={styles.label}>Price {draft.currency ? `(${draft.currency})` : '(USD, LRD converted)'}</Text>
        <View style={styles.row}>
          <TextField
            value={minText}
            onChangeText={setMinText}
            placeholder="Min"
            keyboardType="numeric"
            prefix={priceUnit}
            style={{ flex: 1, marginBottom: 0 }}
          />
          <Text style={{ color: colors.textMuted }}>–</Text>
          <TextField
            value={maxText}
            onChangeText={setMaxText}
            placeholder="Max"
            keyboardType="numeric"
            prefix={priceUnit}
            style={{ flex: 1, marginBottom: 0 }}
          />
        </View>
        {rangeError ? <Text style={styles.error}>{rangeError}</Text> : null}

        <Text style={styles.label}>Condition</Text>
        <View style={styles.wrap}>
          <Chip label="Any" selected={draft.condition == null} onPress={() => set('condition', null)} />
          {CONDITIONS.map((c) => (
            <Chip key={c.value} label={c.label} selected={draft.condition === c.value} onPress={() => set('condition', c.value)} />
          ))}
        </View>

        <Text style={styles.label}>Sort by</Text>
        <View style={styles.wrap}>
          {SORTS.map((s) => {
            const selected = draft.sort === s.value || (draft.sort == null && s.value === (draft.q ? 'relevance' : 'newest'));
            return <Chip key={s.value} label={s.label} selected={selected} onPress={() => set('sort', s.value)} />;
          })}
        </View>
      </ScrollView>

      <CategoryPicker visible={catOpen} onClose={() => setCatOpen(false)} value={draft.category} onSelect={(id) => set('category', id)} allowAny />
      <CommunityPicker
        visible={commOpen}
        onClose={() => setCommOpen(false)}
        selected={draft.community}
        onSelect={(c) => set('community', c)}
        allowAll
      />
    </Sheet>
  );
}

export function Picker({ value, icon, onPress, placeholder }: { value: string | null; icon: string; onPress: () => void; placeholder?: string }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" style={({ pressed }) => [styles.picker, pressed && { backgroundColor: colors.background }]}>
      <Icon name={icon} size={20} color={colors.secondary} />
      <Text style={[styles.pickerText, !value && { color: colors.textLight }]} numberOfLines={1}>
        {value ?? placeholder}
      </Text>
      <Icon name="chevron-down" size={20} color={colors.textMuted} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  label: { fontSize: 14, fontWeight: '700', color: colors.text, marginTop: spacing.lg, marginBottom: spacing.sm },
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  wrap: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm },
  error: { color: colors.danger, fontSize: 12, marginTop: 4 },
  picker: {
    minHeight: 48,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.white,
  },
  pickerText: { flex: 1, fontSize: 16, color: colors.text },
});
