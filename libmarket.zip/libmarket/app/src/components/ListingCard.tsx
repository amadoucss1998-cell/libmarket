import { Image } from 'expo-image';
import { router } from 'expo-router';
import React, { memo } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, radius, spacing } from '@/constants/colors';
import { timeAgo } from '@/lib/format';
import { listingImageUrl } from '@/lib/supabase';
import type { ListingWithImages } from '@/types/app';
import type { CurrencyCode, ListingCard as ListingCardRow, ListingStatus } from '@/types/database';
import { Price } from './Price';
import { Badge, Icon, Skeleton } from './ui';

/** Minimal data a grid card needs (from search_listings or a listings select). */
export type CardData = {
  id: string;
  title: string;
  price: number;
  currency: CurrencyCode;
  community: string | null;
  city: string;
  created_at: string;
  cover_path: string | null;
  is_boosted: boolean;
  status: ListingStatus;
  negotiable: boolean;
};

export function cardFromSearch(r: ListingCardRow): CardData {
  return {
    id: r.id,
    title: r.title,
    price: r.price,
    currency: r.currency,
    community: r.community,
    city: r.city,
    created_at: r.created_at,
    cover_path: r.cover_path,
    is_boosted: r.is_boosted,
    status: r.status,
    negotiable: r.negotiable,
  };
}

export function cardFromListing(l: ListingWithImages): CardData {
  const cover = [...(l.listing_images ?? [])].sort((a, b) => a.sort - b.sort)[0];
  const boostActive = l.is_boosted && (!l.boosted_until || new Date(l.boosted_until).getTime() > Date.now());
  return {
    id: l.id,
    title: l.title,
    price: l.price,
    currency: l.currency,
    community: l.community,
    city: l.city,
    created_at: l.created_at,
    cover_path: cover?.path ?? null,
    is_boosted: boostActive,
    status: l.status,
    negotiable: l.negotiable,
  };
}

type Props = {
  item: CardData;
  width: number;
  saved?: boolean;
  onToggleSave?: (id: string) => void;
  onLongPress?: () => void;
  footer?: React.ReactNode;
};

export const ListingCard = memo(function ListingCard({ item, width, saved, onToggleSave, onLongPress, footer }: Props) {
  const uri = listingImageUrl(item.cover_path, true);
  const statusBadge =
    item.status === 'reserved' ? (
      <Badge label="Reserved" color={colors.warning} bg={colors.warningSoft} />
    ) : item.status === 'sold' ? (
      <Badge label="Sold" color={colors.white} bg={colors.text} />
    ) : item.is_boosted ? (
      <Badge label="Promoted" color={colors.white} bg={colors.primary} icon="star" />
    ) : null;

  return (
    <Pressable
      onPress={() => router.push(`/listing/${item.id}`)}
      onLongPress={onLongPress}
      accessibilityRole="button"
      accessibilityLabel={`${item.title}`}
      style={({ pressed }) => [styles.card, { width, opacity: pressed ? 0.9 : 1 }]}
    >
      <View style={{ width, height: width, backgroundColor: colors.skeleton }}>
        {uri ? (
          <Image
            source={{ uri }}
            style={StyleSheet.absoluteFill}
            contentFit="cover"
            cachePolicy="disk"
            recyclingKey={item.id}
            transition={150}
          />
        ) : (
          <View style={styles.noPhoto}>
            <Icon name="image-off-outline" size={32} color={colors.textLight} />
          </View>
        )}
        {statusBadge ? <View style={styles.badgePos}>{statusBadge}</View> : null}
        {onToggleSave ? (
          <Pressable
            onPress={() => onToggleSave(item.id)}
            hitSlop={6}
            accessibilityRole="button"
            accessibilityLabel={saved ? 'Remove from saved' : 'Save item'}
            style={styles.heart}
          >
            <Icon name={saved ? 'heart' : 'heart-outline'} size={20} color={saved ? colors.primary : colors.text} />
          </Pressable>
        ) : null}
      </View>
      <View style={styles.body}>
        <Price amount={item.price} currency={item.currency} size={16} showApprox={false} />
        <Text style={styles.title} numberOfLines={2}>
          {item.title}
        </Text>
        <Text style={styles.meta} numberOfLines={1}>
          {item.community || item.city} · {timeAgo(item.created_at)}
        </Text>
        {footer}
      </View>
    </Pressable>
  );
});

export function ListingCardSkeleton({ width }: { width: number }) {
  return (
    <View style={[styles.card, { width }]}>
      <Skeleton style={{ width, height: width, borderRadius: 0 }} />
      <View style={styles.body}>
        <Skeleton style={{ width: width * 0.4, height: 16 }} />
        <Skeleton style={{ width: width * 0.8, height: 12, marginTop: 8 }} />
        <Skeleton style={{ width: width * 0.5, height: 10, marginTop: 8 }} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    overflow: 'hidden',
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: colors.border,
  },
  noPhoto: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  badgePos: { position: 'absolute', top: 8, left: 8 },
  heart: {
    position: 'absolute',
    top: 6,
    right: 6,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.92)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  body: { padding: spacing.sm + 2, gap: 2 },
  title: { fontSize: 14, color: colors.text, lineHeight: 19 },
  meta: { fontSize: 12, color: colors.textMuted, marginTop: 2 },
});
