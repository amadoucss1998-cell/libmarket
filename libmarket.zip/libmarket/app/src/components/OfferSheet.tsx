import React, { useEffect, useState } from 'react';
import { Text, View } from 'react-native';
import { colors, spacing } from '@/constants/colors';
import { formatPrice, parsePrice } from '@/lib/format';
import type { CurrencyCode } from '@/types/database';
import { Sheet } from './Sheet';
import { Button, TextField } from './ui';

/** "Make offer" amount sheet. Currency is fixed to the listing's currency (server rule). */
export function OfferSheet({
  visible,
  onClose,
  askingPrice,
  currency,
  onSubmit,
  sending,
}: {
  visible: boolean;
  onClose: () => void;
  askingPrice: number;
  currency: CurrencyCode;
  onSubmit: (amount: number, note: string) => void;
  sending?: boolean;
}) {
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  useEffect(() => {
    if (visible) {
      setAmount('');
      setNote('');
    }
  }, [visible]);
  const value = parsePrice(amount);
  const valid = value != null && value > 0;

  return (
    <Sheet
      visible={visible}
      onClose={onClose}
      title="Make your offer"
      footer={
        <Button
          title={valid ? `Send offer of ${formatPrice(value!, currency, { freeLabel: false })}` : 'Send offer'}
          icon="tag-outline"
          disabled={!valid}
          loading={sending}
          onPress={() => valid && onSubmit(value!, note.trim())}
        />
      }
    >
      <View style={{ paddingHorizontal: spacing.lg }}>
        <Text style={{ color: colors.textMuted, marginBottom: spacing.md }}>
          Asking price: <Text style={{ fontWeight: '800', color: colors.text }}>{formatPrice(askingPrice, currency)}</Text>
        </Text>
        <TextField
          label={`Your offer (${currency})`}
          value={amount}
          onChangeText={setAmount}
          keyboardType="numeric"
          prefix={currency === 'USD' ? '$' : 'L$'}
          placeholder="0"
          autoFocus
        />
        <TextField label="Message (optional)" value={note} onChangeText={setNote} placeholder="Can you take this price?" maxLength={300} />
      </View>
    </Sheet>
  );
}
