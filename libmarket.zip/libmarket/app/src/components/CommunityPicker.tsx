import React, { useMemo, useState } from 'react';
import { Pressable, SectionList, StyleSheet, Text, TextInput, View } from 'react-native';
import { colors, radius, spacing } from '@/constants/colors';
import { COMMUNITY_ALIASES, COMMUNITY_GROUPS } from '@/constants/communities';
import { Sheet } from './Sheet';
import { Icon } from './ui';

/**
 * Searchable, grouped community picker (Greater Monrovia areas + other counties).
 * If nothing matches, the user can use what they typed.
 */
export function CommunityPicker({
  visible,
  onClose,
  onSelect,
  selected,
  allowAll,
  allLabel = 'All Liberia',
}: {
  visible: boolean;
  onClose: () => void;
  onSelect: (community: string | null) => void;
  selected?: string | null;
  allowAll?: boolean;
  allLabel?: string;
}) {
  const [query, setQuery] = useState('');

  const sections = useMemo(() => {
    const q = query.trim().toLowerCase();
    return COMMUNITY_GROUPS.map((g) => ({
      title: g.title,
      data: q
        ? g.items.filter(
            (name) =>
              name.toLowerCase().includes(q) ||
              g.title.toLowerCase().includes(q) ||
              (COMMUNITY_ALIASES[name] ?? []).some((a) => a.toLowerCase().includes(q)),
          )
        : g.items,
    })).filter((s) => s.data.length > 0);
  }, [query]);

  const pick = (v: string | null) => {
    onSelect(v);
    setQuery('');
    onClose();
  };

  const typed = query.trim();

  return (
    <Sheet visible={visible} onClose={onClose} title="Choose community" fullHeight>
      <View style={styles.searchWrap}>
        <Icon name="magnify" size={20} color={colors.textMuted} />
        <TextInput
          value={query}
          onChangeText={setQuery}
          placeholder="Search e.g. Sinkor, Red Light, Ganta"
          placeholderTextColor={colors.textLight}
          style={styles.search}
          autoCorrect={false}
          accessibilityLabel="Search communities"
        />
      </View>
      <SectionList
        sections={sections}
        keyExtractor={(item, i) => `${item}-${i}`}
        keyboardShouldPersistTaps="handled"
        stickySectionHeadersEnabled
        ListHeaderComponent={
          <>
            {allowAll && !typed ? <Item label={allLabel} icon="earth" active={!selected} onPress={() => pick(null)} /> : null}
            {typed.length >= 2 ? (
              <Item label={`Use "${typed}"`} icon="map-marker-plus-outline" onPress={() => pick(typed)} />
            ) : null}
          </>
        }
        renderSectionHeader={({ section }) => <Text style={styles.section}>{section.title}</Text>}
        renderItem={({ item }) => <Item label={item} active={item === selected} onPress={() => pick(item)} />}
        contentContainerStyle={{ paddingBottom: spacing.xl }}
        initialNumToRender={30}
      />
    </Sheet>
  );
}

function Item({ label, active, onPress, icon }: { label: string; active?: boolean; onPress: () => void; icon?: string }) {
  return (
    <Pressable
      onPress={onPress}
      accessibilityRole="button"
      accessibilityState={{ selected: !!active }}
      style={({ pressed }) => [styles.item, pressed && { backgroundColor: colors.background }]}
    >
      {icon ? <Icon name={icon} size={20} color={colors.secondary} /> : null}
      <Text style={[styles.itemText, active && { color: colors.primary, fontWeight: '700' }]}>{label}</Text>
      {active ? <Icon name="check" size={20} color={colors.primary} /> : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  searchWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginHorizontal: spacing.lg,
    marginBottom: spacing.sm,
    paddingHorizontal: spacing.md,
    borderRadius: radius.md,
    backgroundColor: colors.background,
  },
  search: { flex: 1, minHeight: 46, fontSize: 16, color: colors.text },
  section: {
    backgroundColor: colors.white,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: 4,
    fontSize: 13,
    fontWeight: '800',
    color: colors.textMuted,
    textTransform: 'uppercase',
  },
  item: {
    minHeight: 48,
    paddingHorizontal: spacing.lg,
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  itemText: { flex: 1, fontSize: 16, color: colors.text },
});
