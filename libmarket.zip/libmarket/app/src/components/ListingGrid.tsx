import React, { useCallback } from 'react';
import {
  ActivityIndicator,
  FlatList,
  RefreshControl,
  StyleSheet,
  useWindowDimensions,
  View,
  type ListRenderItem,
} from 'react-native';
import { colors, spacing } from '@/constants/colors';
import { useFavorites } from '@/hooks/useFavorites';
import { ListingCard, ListingCardSkeleton, type CardData } from './ListingCard';

const GAP = spacing.md;
const PAD = spacing.md;

export function useCardWidth(columns = 2) {
  const { width } = useWindowDimensions();
  return Math.floor((width - PAD * 2 - GAP * (columns - 1)) / columns);
}

/** 2-column grid with pull-to-refresh, infinite scroll, skeletons and empty/error slots. */
export function ListingGrid({
  items,
  loading,
  refreshing,
  onRefresh,
  onEndReached,
  loadingMore,
  header,
  empty,
  renderFooter,
  onLongPressItem,
}: {
  items: CardData[];
  loading?: boolean;
  refreshing?: boolean;
  onRefresh?: () => void;
  onEndReached?: () => void;
  loadingMore?: boolean;
  header?: React.ReactElement | null;
  empty?: React.ReactElement | null;
  renderFooter?: (item: CardData) => React.ReactNode;
  onLongPressItem?: (item: CardData) => void;
}) {
  const cardWidth = useCardWidth();
  const { isSaved, toggle } = useFavorites();

  const renderItem: ListRenderItem<CardData> = useCallback(
    ({ item }) => (
      <ListingCard
        item={item}
        width={cardWidth}
        saved={isSaved(item.id)}
        onToggleSave={toggle}
        onLongPress={onLongPressItem ? () => onLongPressItem(item) : undefined}
        footer={renderFooter?.(item)}
      />
    ),
    [cardWidth, isSaved, toggle, renderFooter, onLongPressItem],
  );

  if (loading && items.length === 0) {
    return (
      <FlatList
        data={[0, 1, 2, 3, 4, 5]}
        keyExtractor={(i) => `sk${i}`}
        numColumns={2}
        ListHeaderComponent={header}
        columnWrapperStyle={styles.row}
        contentContainerStyle={styles.content}
        renderItem={() => <ListingCardSkeleton width={cardWidth} />}
        scrollEnabled={false}
      />
    );
  }

  return (
    <FlatList
      data={items}
      keyExtractor={(i) => i.id}
      numColumns={2}
      renderItem={renderItem}
      ListHeaderComponent={header}
      ListEmptyComponent={empty}
      columnWrapperStyle={styles.row}
      contentContainerStyle={[styles.content, items.length === 0 && { flexGrow: 1 }]}
      onEndReached={onEndReached}
      onEndReachedThreshold={0.6}
      refreshControl={
        onRefresh ? (
          <RefreshControl refreshing={!!refreshing} onRefresh={onRefresh} colors={[colors.primary]} tintColor={colors.primary} />
        ) : undefined
      }
      ListFooterComponent={
        loadingMore ? (
          <View style={{ padding: spacing.lg }}>
            <ActivityIndicator color={colors.primary} />
          </View>
        ) : null
      }
      initialNumToRender={6}
      maxToRenderPerBatch={8}
      windowSize={7}
      removeClippedSubviews
    />
  );
}

const styles = StyleSheet.create({
  content: { padding: PAD, paddingBottom: 96, gap: GAP },
  row: { gap: GAP },
});
