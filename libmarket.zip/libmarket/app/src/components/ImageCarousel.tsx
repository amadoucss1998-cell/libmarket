import { Image } from 'expo-image';
import React, { useState } from 'react';
import { FlatList, Modal, Pressable, StyleSheet, Text, useWindowDimensions, View, type NativeScrollEvent, type NativeSyntheticEvent } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '@/constants/colors';
import { listingImageUrl } from '@/lib/supabase';
import { Icon, IconButton } from './ui';

/**
 * Swipeable photo gallery. Images load lazily (FlatList only renders nearby pages),
 * so on slow data only the first photo is downloaded until the user swipes.
 */
export function ImageCarousel({ paths, height }: { paths: string[]; height?: number }) {
  const { width } = useWindowDimensions();
  const h = height ?? Math.round(width * 0.9);
  const [index, setIndex] = useState(0);
  const [fullscreen, setFullscreen] = useState(false);

  const onScroll = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const i = Math.round(e.nativeEvent.contentOffset.x / width);
    if (i !== index) setIndex(i);
  };

  if (paths.length === 0) {
    return (
      <View style={[styles.empty, { width, height: h }]}>
        <Icon name="image-off-outline" size={48} color={colors.textLight} />
      </View>
    );
  }

  return (
    <View>
      <FlatList
        data={paths}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        keyExtractor={(p) => p}
        onMomentumScrollEnd={onScroll}
        initialNumToRender={1}
        windowSize={3}
        renderItem={({ item }) => (
          <Pressable onPress={() => setFullscreen(true)} accessibilityLabel="Open photo full screen">
            <Image
              source={{ uri: listingImageUrl(item) ?? undefined }}
              style={{ width, height: h, backgroundColor: colors.skeleton }}
              contentFit="cover"
              cachePolicy="disk"
              transition={150}
            />
          </Pressable>
        )}
      />
      {paths.length > 1 ? (
        <View style={styles.counter}>
          <Text style={styles.counterText}>
            {index + 1}/{paths.length}
          </Text>
        </View>
      ) : null}
      {paths.length > 1 ? (
        <View style={styles.dots}>
          {paths.map((p, i) => (
            <View key={p} style={[styles.dot, i === index && styles.dotActive]} />
          ))}
        </View>
      ) : null}
      <FullscreenGallery visible={fullscreen} onClose={() => setFullscreen(false)} paths={paths} initialIndex={index} />
    </View>
  );
}

function FullscreenGallery({ visible, onClose, paths, initialIndex }: { visible: boolean; onClose: () => void; paths: string[]; initialIndex: number }) {
  const { width, height } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  return (
    <Modal visible={visible} onRequestClose={onClose} animationType="fade" statusBarTranslucent>
      <View style={{ flex: 1, backgroundColor: '#000' }}>
        <FlatList
          data={paths}
          horizontal
          pagingEnabled
          initialScrollIndex={initialIndex}
          getItemLayout={(_, i) => ({ length: width, offset: width * i, index: i })}
          keyExtractor={(p) => p}
          renderItem={({ item }) => (
            <Image source={{ uri: listingImageUrl(item) ?? undefined }} style={{ width, height }} contentFit="contain" cachePolicy="disk" />
          )}
        />
        <IconButton
          name="close"
          label="Close"
          color={colors.white}
          onPress={onClose}
          style={{ position: 'absolute', top: insets.top + 8, right: 8 }}
        />
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  empty: { alignItems: 'center', justifyContent: 'center', backgroundColor: colors.skeleton },
  counter: {
    position: 'absolute',
    bottom: 12,
    right: 12,
    backgroundColor: 'rgba(0,0,0,0.55)',
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  counterText: { color: colors.white, fontSize: 12, fontWeight: '700' },
  dots: { position: 'absolute', bottom: 14, alignSelf: 'center', flexDirection: 'row', gap: 5 },
  dot: { width: 6, height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.6)' },
  dotActive: { backgroundColor: colors.white, width: 8, height: 8, borderRadius: 4, marginTop: -1 },
});
