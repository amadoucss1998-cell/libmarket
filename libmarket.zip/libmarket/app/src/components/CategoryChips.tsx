import React from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { categoryIcon } from '@/constants/categories';
import { colors, radius, spacing } from '@/constants/colors';
import { useCategories } from '@/hooks/useReferenceData';
import { Sheet } from './Sheet';
import { Chip, Icon, Skeleton } from './ui';

/** Horizontal category chip row with an "All" chip. */
export function CategoryChips({ value, onChange }: { value: number | null; onChange: (id: number | null) => void }) {
  const { categories, isLoading } = useCategories();
  if (isLoading && categories.length === 0) {
    return (
      <View style={{ flexDirection: 'row', gap: 8, paddingHorizontal: spacing.md }}>
        {[80, 110, 90, 100].map((w, i) => (
          <Skeleton key={i} style={{ width: w, height: 36, borderRadius: 18 }} />
        ))}
      </View>
    );
  }
  return (
    <FlatList
      horizontal
      data={[{ id: -1, name: 'All', slug: 'all', icon: 'view-grid-outline', sort: 0 }, ...categories]}
      keyExtractor={(c) => String(c.id)}
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={{ paddingHorizontal: spacing.md, gap: 8 }}
      renderItem={({ item }) => {
        const selected = item.id === -1 ? value == null : value === item.id;
        return (
          <Chip
            label={item.name}
            icon={categoryIcon(item)}
            selected={selected}
            onPress={() => onChange(item.id === -1 ? null : item.id)}
          />
        );
      }}
    />
  );
}

/** Grid picker of categories in a sheet (used by the post form and filters). */
export function CategoryPicker({
  visible,
  onClose,
  value,
  onSelect,
  allowAny,
}: {
  visible: boolean;
  onClose: () => void;
  value: number | null;
  onSelect: (id: number | null) => void;
  allowAny?: boolean;
}) {
  const { categories } = useCategories();
  const data = allowAny ? [{ id: -1, name: 'Any category', slug: 'any', icon: 'view-grid-outline', sort: 0 }, ...categories] : categories;
  return (
    <Sheet visible={visible} onClose={onClose} title="Choose category" fullHeight>
      <FlatList
        data={data}
        numColumns={3}
        keyExtractor={(c) => String(c.id)}
        contentContainerStyle={{ padding: spacing.md, gap: spacing.sm }}
        columnWrapperStyle={{ gap: spacing.sm }}
        renderItem={({ item }) => {
          const selected = item.id === -1 ? value == null : value === item.id;
          return (
            <Pressable
              onPress={() => {
                onSelect(item.id === -1 ? null : item.id);
                onClose();
              }}
              accessibilityRole="button"
              accessibilityState={{ selected }}
              style={[styles.tile, selected && styles.tileSelected]}
            >
              <Icon name={categoryIcon(item)} size={28} color={selected ? colors.primary : colors.secondary} />
              <Text style={styles.tileText} numberOfLines={2}>
                {item.name}
              </Text>
            </Pressable>
          );
        }}
      />
    </Sheet>
  );
}

const styles = StyleSheet.create({
  tile: {
    flex: 1,
    minHeight: 92,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.sm,
    gap: 6,
  },
  tileSelected: { borderColor: colors.primary, backgroundColor: colors.primarySoft },
  tileText: { fontSize: 13, textAlign: 'center', color: colors.text, fontWeight: '600' },
});
