import { useQueryClient } from '@tanstack/react-query';
import { router } from 'expo-router';
import { useCallback, useState } from 'react';
import { Alert } from 'react-native';
import { markListingSold, setListingStatus, startConversation } from '@/lib/api';
import { errorMessage } from '@/lib/supabase';
import type { ListingStatus } from '@/types/database';
import { useRequireAuth } from './useAuth';

/** Owner actions on a listing: mark sold, reserve / relist, soft delete. Refreshes affected queries. */
export function useOwnerListingActions() {
  const qc = useQueryClient();

  const refresh = useCallback(
    (id: string) => {
      qc.invalidateQueries({ queryKey: ['listing', id] });
      qc.invalidateQueries({ queryKey: ['myListings'] });
      qc.invalidateQueries({ queryKey: ['feed'] });
      qc.invalidateQueries({ queryKey: ['search'] });
      qc.invalidateQueries({ queryKey: ['sellerListings'] });
    },
    [qc],
  );

  const markSold = useCallback(
    (id: string, onDone?: () => void) => {
      Alert.alert('Mark as sold?', 'Buyers will no longer see this item. Pending offers will be declined.', [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Mark sold',
          onPress: async () => {
            try {
              await markListingSold(id);
              refresh(id);
              onDone?.();
              Alert.alert('Congratulations!', 'Your item is marked as sold. You can leave a review for the buyer from your chat.');
            } catch (e) {
              Alert.alert('Could not mark as sold', errorMessage(e));
            }
          },
        },
      ]);
    },
    [refresh],
  );

  const setStatus = useCallback(
    async (id: string, status: Exclude<ListingStatus, 'sold' | 'deleted'>) => {
      try {
        await setListingStatus(id, status);
        refresh(id);
      } catch (e) {
        Alert.alert('Could not update item', errorMessage(e));
      }
    },
    [refresh],
  );

  const remove = useCallback(
    (id: string, onDone?: () => void) => {
      Alert.alert('Delete this item?', 'It will be removed from LibMarket.', [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await setListingStatus(id, 'deleted');
              refresh(id);
              onDone?.();
            } catch (e) {
              Alert.alert('Could not delete', errorMessage(e));
            }
          },
        },
      ]);
    },
    [refresh],
  );

  /** One-tap action menu for "my listings". */
  const openMenu = useCallback(
    (l: { id: string; status: ListingStatus; title: string }) => {
      const buttons: { text: string; style?: 'cancel' | 'destructive'; onPress?: () => void }[] = [];
      if (l.status !== 'sold') buttons.push({ text: 'Edit', onPress: () => router.push(`/listing/edit/${l.id}`) });
      if (l.status === 'active') buttons.push({ text: 'Mark reserved', onPress: () => setStatus(l.id, 'reserved') });
      if (l.status === 'reserved') buttons.push({ text: 'Make active again', onPress: () => setStatus(l.id, 'active') });
      if (l.status !== 'sold') buttons.push({ text: 'Mark as sold', onPress: () => markSold(l.id) });
      if (l.status === 'sold') buttons.push({ text: 'Relist (active)', onPress: () => setStatus(l.id, 'active') });
      buttons.push({ text: 'Delete', style: 'destructive', onPress: () => remove(l.id) });
      buttons.push({ text: 'Cancel', style: 'cancel' });
      Alert.alert(l.title, undefined, buttons);
    },
    [markSold, remove, setStatus],
  );

  return { markSold, setStatus, remove, openMenu };
}

/** Start (or reopen) a chat about a listing and navigate to it. */
export function useStartChat() {
  const requireAuth = useRequireAuth();
  const [starting, setStarting] = useState(false);
  const start = useCallback(
    async (listingId: string, opts: { offer?: boolean; text?: string } = {}) => {
      if (!requireAuth('chat with the seller')) return;
      setStarting(true);
      try {
        const conv = await startConversation(listingId);
        const params = new URLSearchParams();
        if (opts.offer) params.set('offer', '1');
        if (opts.text) params.set('text', opts.text);
        const qs = params.toString();
        router.push(`/chat/${conv.id}${qs ? `?${qs}` : ''}`);
      } catch (e) {
        Alert.alert('Could not open chat', errorMessage(e));
      } finally {
        setStarting(false);
      }
    },
    [requireAuth],
  );
  return { start, starting };
}
