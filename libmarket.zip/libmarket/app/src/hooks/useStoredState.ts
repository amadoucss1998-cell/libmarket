import AsyncStorage from '@react-native-async-storage/async-storage';
import { useCallback, useEffect, useState } from 'react';

/** Small JSON value persisted in AsyncStorage (e.g. home area, dismissed banners). */
export function useStoredState<T>(key: string, initial: T): [T, (v: T) => void, boolean] {
  const [value, setValue] = useState<T>(initial);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    let alive = true;
    AsyncStorage.getItem(key)
      .then((raw) => {
        if (alive && raw != null) setValue(JSON.parse(raw) as T);
      })
      .catch(() => {})
      .finally(() => alive && setLoaded(true));
    return () => {
      alive = false;
    };
  }, [key]);

  const set = useCallback(
    (v: T) => {
      setValue(v);
      AsyncStorage.setItem(key, JSON.stringify(v)).catch(() => {});
    },
    [key],
  );

  return [value, set, loaded];
}
