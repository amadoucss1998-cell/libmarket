import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useCallback, useMemo } from 'react';
import { Alert } from 'react-native';
import { addFavorite, fetchFavoriteIds, removeFavorite } from '@/lib/api';
import { qk } from '@/lib/queryClient';
import { errorMessage } from '@/lib/supabase';
import { useAuth, useRequireAuth } from './useAuth';

/** Set of saved listing ids + an optimistic toggle that prompts login for guests. */
export function useFavorites() {
  const { user } = useAuth();
  const requireAuth = useRequireAuth();
  const qc = useQueryClient();
  const uid = user?.id ?? 'anon';

  const idsQuery = useQuery({ queryKey: qk.favoriteIds(uid), queryFn: fetchFavoriteIds, enabled: !!user });
  const ids = useMemo(() => new Set(idsQuery.data ?? []), [idsQuery.data]);

  const mutation = useMutation({
    mutationFn: async ({ id, save }: { id: string; save: boolean }) => (save ? addFavorite(id) : removeFavorite(id)),
    onMutate: async ({ id, save }) => {
      await qc.cancelQueries({ queryKey: qk.favoriteIds(uid) });
      const prev = qc.getQueryData<string[]>(qk.favoriteIds(uid)) ?? [];
      qc.setQueryData<string[]>(qk.favoriteIds(uid), save ? [...prev, id] : prev.filter((x) => x !== id));
      return { prev };
    },
    onError: (e, _v, ctx) => {
      if (ctx) qc.setQueryData(qk.favoriteIds(uid), ctx.prev);
      Alert.alert('Could not update saved items', errorMessage(e));
    },
    onSettled: () => {
      qc.invalidateQueries({ queryKey: qk.favorites(uid) });
    },
  });

  const toggle = useCallback(
    (id: string) => {
      if (!requireAuth('save items')) return;
      mutation.mutate({ id, save: !ids.has(id) });
    },
    [ids, mutation, requireAuth],
  );

  return { ids, isSaved: (id: string) => ids.has(id), toggle };
}
