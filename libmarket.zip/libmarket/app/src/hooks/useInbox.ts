import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useEffect } from 'react';
import { fetchInbox } from '@/lib/api';
import { qk } from '@/lib/queryClient';
import { supabase } from '@/lib/supabase';
import { useAuth } from './useAuth';

/** Inbox rows (view `inbox`) for the signed-in user + total unread. */
export function useInbox() {
  const { user } = useAuth();
  const q = useQuery({
    queryKey: qk.inbox(user?.id ?? 'anon'),
    queryFn: fetchInbox,
    enabled: !!user,
  });
  const totalUnread = (q.data ?? []).reduce((n, c) => n + (c.unread || 0), 0);
  return { ...q, rows: q.data ?? [], totalUnread };
}

/**
 * Keeps the inbox (and unread badge) live. Mount once while signed in (tabs layout).
 * RLS limits realtime rows to the user's own conversations.
 */
export function useInboxRealtime() {
  const { user } = useAuth();
  const qc = useQueryClient();
  useEffect(() => {
    if (!user) return;
    const ch = supabase
      .channel(`inbox:${user.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'conversations' }, () => {
        qc.invalidateQueries({ queryKey: qk.inbox(user.id) });
      })
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [user, qc]);
}
