import { useQuery } from '@tanstack/react-query';
import { useMemo } from 'react';
import { fetchCategories, fetchLrdPerUsd } from '@/lib/api';
import { qk } from '@/lib/queryClient';
import type { CategoryRow } from '@/types/database';

export function useCategories() {
  const q = useQuery({ queryKey: qk.categories, queryFn: fetchCategories, staleTime: 6 * 60 * 60 * 1000 });
  const byId = useMemo(() => {
    const m = new Map<number, CategoryRow>();
    (q.data ?? []).forEach((c) => m.set(c.id, c));
    return m;
  }, [q.data]);
  return { ...q, categories: q.data ?? [], byId };
}

/** LRD per 1 USD from app_config (used for "≈" hints). */
export function useLrdRate(): number | null {
  const q = useQuery({ queryKey: qk.lrdRate, queryFn: fetchLrdPerUsd, staleTime: 60 * 60 * 1000 });
  return q.data ?? null;
}
