import type { Session, User } from '@supabase/supabase-js';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { router } from 'expo-router';
import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { Alert } from 'react-native';
import { fetchMyProfile } from '@/lib/api';
import { registerForPush, unregisterPush } from '@/lib/push';
import { qk } from '@/lib/queryClient';
import { supabase } from '@/lib/supabase';
import type { ProfileRow } from '@/types/database';

type AuthState = {
  session: Session | null;
  user: User | null;
  profile: ProfileRow | null;
  /** true until the stored session has been read */
  initializing: boolean;
  profileLoading: boolean;
  refreshProfile: () => Promise<void>;
  signOut: () => Promise<void>;
};

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [initializing, setInitializing] = useState(true);
  const qc = useQueryClient();
  const pushDoneFor = useRef<string | null>(null);

  useEffect(() => {
    supabase.auth
      .getSession()
      .then(({ data }) => setSession(data.session))
      .finally(() => setInitializing(false));
    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);

  const user = session?.user ?? null;
  const uid = user?.id;

  // Register this device for push once per signed-in user.
  useEffect(() => {
    if (uid && pushDoneFor.current !== uid) {
      pushDoneFor.current = uid;
      registerForPush();
    }
  }, [uid]);

  const profileQuery = useQuery({
    queryKey: qk.profile(uid ?? 'anon'),
    queryFn: () => fetchMyProfile(uid!),
    enabled: !!uid,
  });

  const refreshProfile = useCallback(async () => {
    if (uid) await qc.invalidateQueries({ queryKey: qk.profile(uid) });
  }, [qc, uid]);

  const signOut = useCallback(async () => {
    await unregisterPush();
    await supabase.auth.signOut();
    pushDoneFor.current = null;
    // Drop everything user-specific; public reference data will be refetched.
    qc.clear();
  }, [qc]);

  const value = useMemo<AuthState>(
    () => ({
      session,
      user,
      profile: profileQuery.data ?? null,
      initializing,
      profileLoading: profileQuery.isLoading,
      refreshProfile,
      signOut,
    }),
    [session, user, profileQuery.data, profileQuery.isLoading, initializing, refreshProfile, signOut],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}

/**
 * Returns a guard for gated actions (post, chat, save, report...).
 * `requireAuth()` returns the user id, or prompts to log in and returns null.
 */
export function useRequireAuth() {
  const { user } = useAuth();
  return useCallback(
    (reason = 'continue'): string | null => {
      if (user) return user.id;
      Alert.alert('Log in needed', `Please log in or create an account to ${reason}.`, [
        { text: 'Not now', style: 'cancel' },
        { text: 'Log in', onPress: () => router.push('/auth/login') },
      ]);
      return null;
    },
    [user],
  );
}
