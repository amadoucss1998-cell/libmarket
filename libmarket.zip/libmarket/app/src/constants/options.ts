import type { CurrencyCode, ListingCondition, ReportReason, SearchSort } from '@/types/database';

export const CONDITIONS: { value: ListingCondition; label: string }[] = [
  { value: 'new', label: 'New' },
  { value: 'like_new', label: 'Like new' },
  { value: 'good', label: 'Good' },
  { value: 'fair', label: 'Fair' },
  { value: 'for_parts', label: 'For parts' },
];
export const conditionLabel = (c: ListingCondition) => CONDITIONS.find((x) => x.value === c)?.label ?? c;

export const CURRENCIES: CurrencyCode[] = ['USD', 'LRD'];

export const SORTS: { value: SearchSort; label: string }[] = [
  { value: 'relevance', label: 'Best match' },
  { value: 'newest', label: 'Newest' },
  { value: 'price_asc', label: 'Price: low to high' },
  { value: 'price_desc', label: 'Price: high to low' },
];

export const REPORT_REASONS: { value: ReportReason; label: string; forListing: boolean; forUser: boolean }[] = [
  { value: 'scam', label: 'Scam or fraud', forListing: true, forUser: true },
  { value: 'prohibited_item', label: 'Prohibited item', forListing: true, forUser: false },
  { value: 'spam', label: 'Spam', forListing: true, forUser: true },
  { value: 'wrong_category', label: 'Wrong category', forListing: true, forUser: false },
  { value: 'duplicate', label: 'Duplicate ad', forListing: true, forUser: false },
  { value: 'offensive', label: 'Offensive content', forListing: true, forUser: true },
  { value: 'harassment', label: 'Harassment', forListing: false, forUser: true },
  { value: 'other', label: 'Something else', forListing: true, forUser: true },
];

export const BUYER_QUICK_REPLIES = ['Is this still available?', "What's your last price?", 'Where can we meet?'];
export const SELLER_QUICK_REPLIES = ['Yes, still available', 'Price is fixed', 'Sold, sorry'];

export const SAFETY_TIPS = [
  'Meet in a busy public place, in the daytime. Bring someone with you.',
  'Inspect the item well before you pay.',
  'Never send mobile money (Orange Money / MoMo) in advance.',
  'For phones, check the IMEI (dial *#06#) and that it is not locked.',
  'Sellers: check your mobile money balance yourself before handing over. Never trust an SMS or screenshot.',
  'Report anyone who asks for a deposit, "transport fare" or payment first.',
];

export const SAFETY_BANNER = 'Meet in public. Inspect before you pay. Never send mobile money in advance.';

/** Advance-payment scam patterns (spec §4). Shown as a warning on incoming chat messages. */
export const SCAM_PATTERN =
  /(send (the )?(money|momo|orange money|cash)|momo first|pay first|transport fare|deposit|advance payment|pay before)/i;

export const PHOTO_TIPS = ['Use daylight', 'Plain background', 'Show any damage', 'First photo is the cover'];

export const MAX_PHOTOS = 10;
export const TITLE_MAX = 70;
export const DESCRIPTION_MAX = 2000;
