/** LibMarket palette: Liberia-inspired red + deep blue on white. */
export const colors = {
  primary: '#C8102E',
  primaryDark: '#A00C24',
  primarySoft: '#FDECEF',
  secondary: '#002868',
  secondarySoft: '#E6ECF6',
  white: '#FFFFFF',
  background: '#F4F5F7',
  card: '#FFFFFF',
  text: '#111827',
  textMuted: '#6B7280',
  textLight: '#9CA3AF',
  border: '#E5E7EB',
  skeleton: '#E9EBEF',
  success: '#15803D',
  successSoft: '#DCFCE7',
  warning: '#B45309',
  warningSoft: '#FEF3C7',
  danger: '#B91C1C',
  star: '#F59E0B',
  whatsapp: '#25D366',
  overlay: 'rgba(0,0,0,0.45)',
} as const;

export const radius = { sm: 8, md: 12, lg: 16, xl: 24, pill: 999 } as const;
export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24 } as const;
/** Minimum accessible touch target (dp). */
export const TOUCH = 44;
