/**
 * Location picker data from docs/research-and-spec.md §5.
 * Greater Monrovia is grouped by area; other counties list their capital + main towns.
 * Entries marked † in the spec are colloquial names (ops to confirm locally).
 * The stored value is the plain community / town name (listings.community, profiles.community).
 */
export type CommunityGroup = { title: string; county: string; items: string[] };

export const COMMUNITY_GROUPS: CommunityGroup[] = [
  {
    title: 'Central Monrovia',
    county: 'Montserrado',
    items: [
      'Broad Street / Downtown', 'Waterside', 'Capitol Hill', 'Mamba Point', 'Snapper Hill', 'Crown Hill',
      'Center Street', 'Randall Street', 'Camp Johnson Road', 'Slipway', 'West Point', 'Jallah Town',
      'Bishop Brooks', 'Soniwein', 'Clay Street',
    ],
  },
  {
    title: 'Sinkor',
    county: 'Montserrado',
    items: [
      'Sinkor', 'Old Road', 'Sinkor 3rd–24th Street', 'Tubman Boulevard', 'Airfield', 'Fiamah', 'Lakpazee',
      '9th Street', 'Matadi', 'Wroto Town', 'Raymond Field',
    ],
  },
  {
    title: 'Congo Town',
    county: 'Montserrado',
    items: [
      'Congo Town', 'Oldest Congo Town', 'Congo Town Old Road', 'Swankamore', 'Chugbor', 'Tarr Town',
      'Peace Island', 'Pagos Island', 'Smythe Road', 'Catholic Hospital', 'Key & Death Hole',
    ],
  },
  {
    title: 'Paynesville',
    county: 'Montserrado',
    items: [
      'Paynesville Joe Bar', 'Red Light', 'ELWA', 'Rehab / Borbor Town', '72nd', 'Duport Road', 'Pipeline',
      'Police Academy', 'GSA Road / Rockville', 'Jacob Town', 'Kpelle Town', 'Soul Clinic', 'S.D. Cooper',
      'Town Hall', 'Wood Camp', 'Zinc Factory', 'A.B. Tolbert Road', 'Morris Farm', 'Omega / Kemah Town',
      'Kendeja', 'Double Bridge', 'SKD Boulevard', 'Somalia Drive', 'Coca-Cola Factory', 'Nancy Doe Market',
    ],
  },
  {
    title: 'Gardnersville',
    county: 'Montserrado',
    items: [
      'Gardnersville', 'Barnersville Road', 'Stephen Tolbert Estate', 'Kesselly Boulevard', 'JJY / Snow Hill',
      'Shoe Factory', 'MTA', 'Mangrove Island', 'Grass Field',
    ],
  },
  {
    title: 'Barnersville',
    county: 'Montserrado',
    items: ['Barnersville Estate', 'Kaba Town', 'Dabwe Town', 'Johnsonville Road', 'Old Field', 'Behwein Community'],
  },
  {
    title: 'New Georgia',
    county: 'Montserrado',
    items: [
      'New Georgia', 'New Georgia Estate', 'Chocolate City', 'Battery Factory', 'Iron Factory', 'SOS',
      'Topoe Village', 'Flahn Town',
    ],
  },
  {
    title: 'Bushrod Island',
    county: 'Montserrado',
    items: [
      'Clara Town', 'Logan Town', 'Vai Town', 'Freeport', 'Jamaica Road', 'Stockton Creek', 'Point Four',
      'Doe Community', 'Duala', 'Duala Market', 'New Kru Town', 'Popo Beach', 'Crab Hole', 'Zinc Camp',
    ],
  },
  {
    title: 'Caldwell / Virginia / Brewerville',
    county: 'Montserrado',
    items: ['Caldwell', 'Upper Caldwell', 'Caldwell Market', 'Cassava Hill', 'Louisiana', 'Dixville', 'Virginia', 'Brewerville', 'Kpallah'],
  },
  {
    title: 'Johnsonville & east',
    county: 'Montserrado',
    items: ['Johnsonville', 'Rock Hill', 'City View', 'Mount Barclay', 'Bensonville', 'Duazon'],
  },
  { title: 'Margibi County', county: 'Margibi', items: ['Kakata', 'Harbel / Firestone', 'Marshall', 'Unification Town'] },
  { title: 'Bong County', county: 'Bong', items: ['Gbarnga', 'Salala', 'Totota'] },
  { title: 'Nimba County', county: 'Nimba', items: ['Ganta', 'Sanniquellie', 'Saclepea', 'Tappita', 'Yekepa'] },
  { title: 'Grand Bassa County', county: 'Grand Bassa', items: ['Buchanan', 'Compound #1'] },
  { title: 'Grand Cape Mount County', county: 'Grand Cape Mount', items: ['Robertsport', 'Sinje', 'Bo Waterside'] },
  { title: 'Bomi County', county: 'Bomi', items: ['Tubmanburg'] },
  { title: 'Gbarpolu County', county: 'Gbarpolu', items: ['Bopolu'] },
  { title: 'Lofa County', county: 'Lofa', items: ['Voinjama', 'Foya', 'Zorzor'] },
  { title: 'Grand Gedeh County', county: 'Grand Gedeh', items: ['Zwedru'] },
  { title: 'River Gee County', county: 'River Gee', items: ['Fish Town'] },
  { title: 'Maryland County', county: 'Maryland', items: ['Harper', 'Pleebo'] },
  { title: 'Grand Kru County', county: 'Grand Kru', items: ['Barclayville'] },
  { title: 'Sinoe County', county: 'Sinoe', items: ['Greenville'] },
  { title: 'Rivercess County', county: 'Rivercess', items: ['Cestos City'] },
];

/** Alternate spellings, so searching the picker finds both. */
export const COMMUNITY_ALIASES: Record<string, string[]> = {
  'Barnersville Estate': ['Barnesville'],
  'Barnersville Road': ['Barnesville'],
  Fiamah: ['Fiama'],
  'Paynesville Joe Bar': ['Joe Bar', 'Paynesville'],
  ELWA: ['King Gray', 'ELWA Junction'],
  Matadi: ['Old Matadi', 'New Matadi'],
};

/** City for a community: Greater Monrovia groups -> Monrovia, otherwise the town itself. */
export function cityForCommunity(community: string | null | undefined): string {
  if (!community) return 'Monrovia';
  const g = COMMUNITY_GROUPS.find((grp) => grp.items.includes(community));
  if (!g || g.county === 'Montserrado') return 'Monrovia';
  return community;
}
