import type { CategoryRow } from '@/types/database';

/**
 * Fallback icons by slug, mirroring supabase/migrations/0005_seed.sql.
 * Real category ids always come from the `categories` table (see useCategories).
 */
export const CATEGORY_ICON_FALLBACK: Record<string, string> = {
  'phones-tablets': 'cellphone',
  electronics: 'television',
  computers: 'laptop',
  vehicles: 'car',
  'motorbikes-keke': 'motorbike',
  'vehicle-parts': 'car-cog',
  furniture: 'sofa',
  'home-appliances': 'fridge',
  'generators-solar': 'solar-power',
  fashion: 'tshirt-crew',
  beauty: 'lipstick',
  'baby-kids': 'baby-carriage',
  'sports-outdoors': 'soccer',
  'books-education': 'book-open-variant',
  'tools-equipment': 'hammer-wrench',
  'building-materials': 'wall',
  agriculture: 'sprout',
  pets: 'paw',
  services: 'account-wrench',
  other: 'dots-horizontal',
};

export function categoryIcon(c: Pick<CategoryRow, 'slug' | 'icon'>): string {
  return c.icon || CATEGORY_ICON_FALLBACK[c.slug] || 'tag-outline';
}
