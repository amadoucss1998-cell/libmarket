/**
 * App-level shapes built on the backend types (src/types/database.ts, a copy of supabase/types.ts).
 * These describe the embedded selects the app makes.
 */
import type {
  CategoryRow,
  ConversationRow,
  ListingImageRow,
  ListingRow,
  PublicProfileRow,
  ReviewRow,
  SavedSearchRow,
} from './database';

export * from './database';

export type ListingImageLite = Pick<ListingImageRow, 'id' | 'path' | 'sort'>;

/** listings + seller:public_profiles + category + images (detail screen). */
export type ListingDetail = Omit<ListingRow, 'search'> & {
  seller: PublicProfileRow | null;
  category: CategoryRow | null;
  listing_images: ListingImageLite[];
};

/** listings + images (my listings, seller profile, favorites). */
export type ListingWithImages = Omit<ListingRow, 'search'> & {
  listing_images: ListingImageLite[];
};

export type FavoriteWithListing = {
  created_at: string;
  listing: ListingWithImages | null;
};

export type ReviewWithReviewer = ReviewRow & {
  reviewer: Pick<PublicProfileRow, 'display_name' | 'avatar_url'> | null;
};

export type BlockWithUser = {
  blocked_id: string;
  created_at: string;
  user: Pick<PublicProfileRow, 'display_name' | 'avatar_url'> | null;
};

export type ConversationDetail = ConversationRow;

export type SavedSearch = SavedSearchRow;

/** Filters used by the Search tab and saved searches. */
export type SearchFilters = {
  q: string;
  category: number | null;
  minPrice: number | null;
  maxPrice: number | null;
  currency: 'USD' | 'LRD' | null;
  condition: import('./database').ListingCondition | null;
  community: string | null;
  sort: import('./database').SearchSort | null;
};

export const EMPTY_FILTERS: SearchFilters = {
  q: '',
  category: null,
  minPrice: null,
  maxPrice: null,
  currency: null,
  condition: null,
  community: null,
  sort: null,
};
