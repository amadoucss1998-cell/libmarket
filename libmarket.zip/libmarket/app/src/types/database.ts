/**
 * LibMarket — Supabase database types.
 *
 * Hand-written to match supabase/migrations/0001..0005. Shape is compatible with
 * `supabase gen types typescript`, so you can use it directly:
 *
 *   import { createClient } from '@supabase/supabase-js';
 *   import type { Database } from './types';
 *   export const supabase = createClient<Database>(
 *     process.env.EXPO_PUBLIC_SUPABASE_URL!,
 *     process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!,
 *   );
 *
 * Insert/Update types list ONLY the columns the app is allowed to write
 * (the database enforces this with column-level grants).
 * If you later run `supabase gen types`, keep the convenience aliases at the bottom.
 * (Object types are `type` aliases, not interfaces: supabase-js generics need index-compatible types.)
 */

export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

/* -------------------------------------------------------------------------- */
/* Enums                                                                      */
/* -------------------------------------------------------------------------- */
export type CurrencyCode = 'USD' | 'LRD';
export type ListingCondition = 'new' | 'like_new' | 'good' | 'fair' | 'for_parts';
export type ListingStatus = 'active' | 'reserved' | 'sold' | 'deleted';
export type MessageKind = 'text' | 'offer' | 'system' | 'image';
export type OfferStatus = 'pending' | 'accepted' | 'declined';
export type ReportReason =
  | 'spam'
  | 'scam'
  | 'prohibited_item'
  | 'offensive'
  | 'wrong_category'
  | 'duplicate'
  | 'harassment'
  | 'other';
export type ReportStatus = 'open' | 'reviewing' | 'resolved' | 'dismissed';
export type PushPlatform = 'ios' | 'android' | 'web';
export type SearchSort = 'newest' | 'price_asc' | 'price_desc' | 'nearest' | 'relevance';

/** UUID string */
type uuid = string;
/** ISO-8601 timestamp string, e.g. "2026-09-26T10:15:00.000Z" */
type timestamptz = string;

/* -------------------------------------------------------------------------- */
/* Row types                                                                   */
/* -------------------------------------------------------------------------- */
export type AppConfigRow = {
  key: string;
  value: Json;
  updated_at: timestamptz;
};

/** Full profile row — only readable by its owner. */
export type ProfileRow = {
  id: uuid;
  display_name: string;
  avatar_url: string | null;
  phone: string | null;
  whatsapp: string | null;
  show_phone: boolean;
  show_whatsapp: boolean;
  community: string | null;
  city: string;
  bio: string | null;
  is_verified: boolean;
  /** numeric(3,2) — PostgREST returns numerics as JSON numbers */
  rating_avg: number;
  rating_count: number;
  created_at: timestamptz;
  updated_at: timestamptz;
};

/** Row of the `public_profiles` view — what everyone can see about a user. */
export type PublicProfileRow = {
  id: uuid;
  display_name: string;
  avatar_url: string | null;
  /** null unless the user enabled show_phone */
  phone: string | null;
  /** null unless the user enabled show_whatsapp (default on) */
  whatsapp: string | null;
  community: string | null;
  city: string;
  bio: string | null;
  is_verified: boolean;
  rating_avg: number;
  rating_count: number;
  created_at: timestamptz;
};

export type CategoryRow = {
  id: number;
  slug: string;
  name: string;
  /** MaterialCommunityIcons name */
  icon: string | null;
  sort: number;
};

export type ListingRow = {
  id: uuid;
  seller_id: uuid;
  title: string;
  description: string;
  price: number;
  currency: CurrencyCode;
  negotiable: boolean;
  condition: ListingCondition;
  category_id: number;
  community: string | null;
  city: string;
  lat: number | null;
  lng: number | null;
  status: ListingStatus;
  view_count: number;
  favorite_count: number;
  is_boosted: boolean;
  boosted_until: timestamptz | null;
  sold_at: timestamptz | null;
  created_at: timestamptz;
  updated_at: timestamptz;
  /** generated tsvector (string form); don't use in the app */
  search: unknown;
};

export type ListingImageRow = {
  id: uuid;
  listing_id: uuid;
  /** Storage path in bucket `listing-images`: `<user_id>/<listing_id>/<file>` */
  path: string;
  sort: number;
  created_at: timestamptz;
};

export type FavoriteRow = {
  user_id: uuid;
  listing_id: uuid;
  created_at: timestamptz;
};

export type ConversationRow = {
  id: uuid;
  listing_id: uuid;
  buyer_id: uuid;
  seller_id: uuid;
  last_message: string | null;
  last_message_at: timestamptz | null;
  buyer_unread: number;
  seller_unread: number;
  created_at: timestamptz;
};

export type MessageRow = {
  id: uuid;
  conversation_id: uuid;
  sender_id: uuid;
  body: string | null;
  kind: MessageKind;
  offer_amount: number | null;
  /** currency of the listing at the time of the offer */
  offer_currency: CurrencyCode | null;
  offer_status: OfferStatus | null;
  /** Storage path in private bucket `message-images`: `<conversation_id>/<user_id>/<file>` */
  image_path: string | null;
  created_at: timestamptz;
  read_at: timestamptz | null;
};

export type ReviewRow = {
  id: uuid;
  reviewer_id: uuid;
  reviewee_id: uuid;
  listing_id: uuid | null;
  rating: 1 | 2 | 3 | 4 | 5;
  comment: string | null;
  created_at: timestamptz;
  updated_at: timestamptz;
};

export type ReportRow = {
  id: uuid;
  reporter_id: uuid;
  listing_id: uuid | null;
  reported_user_id: uuid | null;
  reason: ReportReason;
  details: string | null;
  status: ReportStatus;
  created_at: timestamptz;
  updated_at: timestamptz;
};

export type BlockRow = {
  blocker_id: uuid;
  blocked_id: uuid;
  created_at: timestamptz;
};

export type SavedSearchRow = {
  id: uuid;
  user_id: uuid;
  query: string | null;
  category_id: number | null;
  min_price: number | null;
  max_price: number | null;
  currency: CurrencyCode | null;
  community: string | null;
  notify: boolean;
  created_at: timestamptz;
};

export type PushTokenRow = {
  token: string;
  user_id: uuid;
  platform: PushPlatform;
  created_at: timestamptz;
  updated_at: timestamptz;
};

/** Row of the `inbox` view (one per conversation of the signed-in user). */
export type InboxRow = {
  id: uuid;
  listing_id: uuid;
  buyer_id: uuid;
  seller_id: uuid;
  last_message: string | null;
  last_message_at: timestamptz | null;
  created_at: timestamptz;
  my_role: 'buyer' | 'seller';
  /** unread count for the signed-in user */
  unread: number;
  other_user_id: uuid | null;
  other_display_name: string | null;
  other_avatar_url: string | null;
  other_is_verified: boolean | null;
  /** listing fields are null if the listing was deleted */
  listing_title: string | null;
  listing_price: number | null;
  listing_currency: CurrencyCode | null;
  listing_status: ListingStatus | null;
  listing_cover_path: string | null;
  /** true if either side blocked the other — disable the composer */
  is_blocked: boolean;
};

/* -------------------------------------------------------------------------- */
/* Insert / Update payloads (only writable columns)                           */
/* -------------------------------------------------------------------------- */
export type ProfileUpdate = {
  display_name?: string;
  avatar_url?: string | null;
  phone?: string | null;
  whatsapp?: string | null;
  show_phone?: boolean;
  show_whatsapp?: boolean;
  community?: string | null;
  city?: string;
  bio?: string | null;
};

export type ListingInsert = {
  /** defaults to auth.uid(); must equal it if given */
  seller_id?: uuid;
  title: string;
  description?: string;
  price: number;
  currency?: CurrencyCode;
  negotiable?: boolean;
  condition?: ListingCondition;
  category_id: number;
  community?: string | null;
  city?: string;
  lat?: number | null;
  lng?: number | null;
};

export type ListingUpdate = {
  title?: string;
  description?: string;
  price?: number;
  currency?: CurrencyCode;
  negotiable?: boolean;
  condition?: ListingCondition;
  category_id?: number;
  community?: string | null;
  city?: string;
  lat?: number | null;
  lng?: number | null;
  /** e.g. 'deleted' to remove, 'reserved' / 'active'. Prefer mark_listing_sold RPC for 'sold'. */
  status?: ListingStatus;
};

export type ListingImageInsert = {
  listing_id: uuid;
  path: string;
  sort?: number;
};
export type ListingImageUpdate = {
  sort?: number;
};

export type FavoriteInsert = {
  user_id?: uuid;
  listing_id: uuid;
};

export type MessageInsert = {
  conversation_id: uuid;
  sender_id?: uuid;
  body?: string | null;
  /** 'system' is rejected for users */
  kind?: Exclude<MessageKind, 'system'>;
  /** required (> 0) for kind 'offer'; buyer only */
  offer_amount?: number | null;
  /** required for kind 'image' */
  image_path?: string | null;
};

export type ReviewInsert = {
  reviewer_id?: uuid;
  reviewee_id: uuid;
  listing_id: uuid;
  rating: 1 | 2 | 3 | 4 | 5;
  comment?: string | null;
};
export type ReviewUpdate = {
  rating?: 1 | 2 | 3 | 4 | 5;
  comment?: string | null;
};

/** Provide exactly one of listing_id / reported_user_id. */
export type ReportInsert = {
  reporter_id?: uuid;
  reason: ReportReason;
  details?: string | null;
} & ({ listing_id: uuid; reported_user_id?: null } | { reported_user_id: uuid; listing_id?: null });

export type BlockInsert = {
  blocker_id?: uuid;
  blocked_id: uuid;
};

export type SavedSearchInsert = {
  user_id?: uuid;
  query?: string | null;
  category_id?: number | null;
  min_price?: number | null;
  max_price?: number | null;
  currency?: CurrencyCode | null;
  community?: string | null;
  notify?: boolean;
};
export type SavedSearchUpdate = Omit<SavedSearchInsert, 'user_id'>;

export type PushTokenInsert = {
  token: string;
  user_id?: uuid;
  platform: PushPlatform;
};

/* -------------------------------------------------------------------------- */
/* RPC params / returns                                                        */
/* -------------------------------------------------------------------------- */
export type StartConversationArgs = {
  listing_id: uuid;
};
export type MarkConversationReadArgs = {
  conversation_id: uuid;
};
export type IncrementListingViewArgs = {
  listing_id: uuid;
};
export type RespondToOfferArgs = {
  message_id: uuid;
  accept: boolean;
};
export type MarkListingSoldArgs = {
  listing_id: uuid;
};
export type RegisterPushTokenArgs = {
  token: string;
  platform: PushPlatform;
};

export type SearchListingsArgs = {
  q?: string | null;
  /** categories.id */
  category?: number | null;
  min_price?: number | null;
  max_price?: number | null;
  /** when set: filter by currency and compare min/max in it; otherwise min/max are USD-equivalent */
  currency?: CurrencyCode | null;
  condition?: ListingCondition | null;
  community?: string | null;
  /** default: 'relevance' if q is given, else 'newest' */
  sort?: SearchSort | null;
  lat?: number | null;
  lng?: number | null;
  radius_km?: number | null;
  /** 1..100, default 20 */
  limit?: number;
  /** default 0 */
  offset?: number;
};

/** One card returned by search_listings. */
export type ListingCard = {
  id: uuid;
  seller_id: uuid;
  title: string;
  price: number;
  currency: CurrencyCode;
  /** price converted to USD with app_config.lrd_per_usd */
  price_usd: number;
  negotiable: boolean;
  condition: ListingCondition;
  category_id: number;
  community: string | null;
  city: string;
  lat: number | null;
  lng: number | null;
  status: ListingStatus;
  view_count: number;
  favorite_count: number;
  /** effective boost (is_boosted and boost not expired) */
  is_boosted: boolean;
  created_at: timestamptz;
  /** path of first image in `listing-images` bucket */
  cover_path: string | null;
  seller_display_name: string;
  seller_avatar_url: string | null;
  seller_is_verified: boolean;
  seller_rating_avg: number;
  /** km from (lat,lng) if provided and listing has coordinates */
  distance_km: number | null;
  rank: number;
  /** total matches ignoring limit/offset */
  total_count: number;
};

/* -------------------------------------------------------------------------- */
/* Database type for createClient<Database>()                                  */
/* -------------------------------------------------------------------------- */
type Rel<FK extends string, Cols extends string[], Ref extends string, RefCols extends string[] = ['id']> = {
  foreignKeyName: FK;
  columns: Cols;
  isOneToOne: false;
  referencedRelation: Ref;
  referencedColumns: RefCols;
};

type NoWrite = { [K in never]: never };

export type Database = {
  public: {
    Tables: {
      app_config: {
        Row: AppConfigRow;
        Insert: NoWrite;
        Update: NoWrite;
        Relationships: [];
      };
      profiles: {
        Row: ProfileRow;
        Insert: NoWrite;
        Update: ProfileUpdate;
        Relationships: [];
      };
      categories: {
        Row: CategoryRow;
        Insert: NoWrite;
        Update: NoWrite;
        Relationships: [];
      };
      listings: {
        Row: ListingRow;
        Insert: ListingInsert;
        Update: ListingUpdate;
        Relationships: [
          Rel<'listings_seller_id_fkey', ['seller_id'], 'profiles'>,
          Rel<'listings_seller_id_fkey', ['seller_id'], 'public_profiles'>,
          Rel<'listings_category_id_fkey', ['category_id'], 'categories'>,
        ];
      };
      listing_images: {
        Row: ListingImageRow;
        Insert: ListingImageInsert;
        Update: ListingImageUpdate;
        Relationships: [Rel<'listing_images_listing_id_fkey', ['listing_id'], 'listings'>];
      };
      favorites: {
        Row: FavoriteRow;
        Insert: FavoriteInsert;
        Update: NoWrite;
        Relationships: [
          Rel<'favorites_listing_id_fkey', ['listing_id'], 'listings'>,
          Rel<'favorites_user_id_fkey', ['user_id'], 'profiles'>,
        ];
      };
      conversations: {
        Row: ConversationRow;
        Insert: NoWrite;
        Update: NoWrite;
        Relationships: [
          Rel<'conversations_listing_id_fkey', ['listing_id'], 'listings'>,
          Rel<'conversations_buyer_id_fkey', ['buyer_id'], 'public_profiles'>,
          Rel<'conversations_seller_id_fkey', ['seller_id'], 'public_profiles'>,
        ];
      };
      messages: {
        Row: MessageRow;
        Insert: MessageInsert;
        Update: NoWrite;
        Relationships: [
          Rel<'messages_conversation_id_fkey', ['conversation_id'], 'conversations'>,
          Rel<'messages_sender_id_fkey', ['sender_id'], 'public_profiles'>,
        ];
      };
      reviews: {
        Row: ReviewRow;
        Insert: ReviewInsert;
        Update: ReviewUpdate;
        Relationships: [
          Rel<'reviews_reviewer_id_fkey', ['reviewer_id'], 'public_profiles'>,
          Rel<'reviews_reviewee_id_fkey', ['reviewee_id'], 'public_profiles'>,
          Rel<'reviews_listing_id_fkey', ['listing_id'], 'listings'>,
        ];
      };
      reports: {
        Row: ReportRow;
        Insert: ReportInsert;
        Update: NoWrite;
        Relationships: [];
      };
      blocks: {
        Row: BlockRow;
        Insert: BlockInsert;
        Update: NoWrite;
        Relationships: [Rel<'blocks_blocked_id_fkey', ['blocked_id'], 'public_profiles'>];
      };
      saved_searches: {
        Row: SavedSearchRow;
        Insert: SavedSearchInsert;
        Update: SavedSearchUpdate;
        Relationships: [Rel<'saved_searches_category_id_fkey', ['category_id'], 'categories'>];
      };
      push_tokens: {
        Row: PushTokenRow;
        Insert: PushTokenInsert;
        Update: NoWrite;
        Relationships: [];
      };
    };
    Views: {
      public_profiles: {
        Row: PublicProfileRow;
        Relationships: [];
      };
      inbox: {
        Row: InboxRow;
        Relationships: [];
      };
    };
    Functions: {
      start_conversation: { Args: StartConversationArgs; Returns: ConversationRow };
      mark_conversation_read: { Args: MarkConversationReadArgs; Returns: undefined };
      increment_listing_view: { Args: IncrementListingViewArgs; Returns: number };
      respond_to_offer: { Args: RespondToOfferArgs; Returns: MessageRow };
      mark_listing_sold: { Args: MarkListingSoldArgs; Returns: ListingRow };
      register_push_token: { Args: RegisterPushTokenArgs; Returns: undefined };
      search_listings: { Args: SearchListingsArgs; Returns: ListingCard[] };
    };
    Enums: {
      currency_code: CurrencyCode;
      listing_condition: ListingCondition;
      listing_status: ListingStatus;
      message_kind: MessageKind;
      offer_status: OfferStatus;
      report_reason: ReportReason;
      report_status: ReportStatus;
      push_platform: PushPlatform;
    };
    CompositeTypes: { [_ in never]: never };
  };
};

/* -------------------------------------------------------------------------- */
/* Convenience                                                                 */
/* -------------------------------------------------------------------------- */
export type Tables<T extends keyof Database['public']['Tables']> = Database['public']['Tables'][T]['Row'];
export type Views<T extends keyof Database['public']['Views']> = Database['public']['Views'][T]['Row'];
export type RpcArgs<T extends keyof Database['public']['Functions']> = Database['public']['Functions'][T]['Args'];
export type RpcReturns<T extends keyof Database['public']['Functions']> = Database['public']['Functions'][T]['Returns'];

/** Storage bucket names */
export const BUCKETS = {
  listingImages: 'listing-images',
  avatars: 'avatars',
  messageImages: 'message-images',
} as const;
