# LibMarket: mobile app (Expo)

LibMarket is a used-goods marketplace for Liberia, starting in Monrovia. This folder holds the Android/iOS app. It is built with **Expo SDK 57** (React Native 0.86), TypeScript (strict), Expo Router and React Query, and it talks directly to the Supabase backend in [`../supabase`](../supabase).

- Anyone can browse without an account. Posting, chatting, saving, reporting and contacting a seller ask the user to log in first.
- Login works with a phone number and an SMS code (+231 is filled in), or with email and a password.
- Prices can be in USD or LRD. The app always shows the other currency as an approximate value, using `app_config.lrd_per_usd`.
- The app is built for cheap phones and expensive data. Photos are compressed to about 1080px and 250KB, images are cached on disk, feed cards use thumbnails, and screens show skeleton loaders. An offline banner appears when there is no connection, and the reference data and last feed are saved on the phone.

---

## 1. Set up Supabase (once)

1. Create a project at https://supabase.com. Pick a region close to West Africa, such as London or Frankfurt.
2. Run the migrations in order: `0001_schema.sql` → `0002_rls.sql` → `0003_functions.sql` → `0004_storage.sql` → `0005_seed.sql`. You can paste them into the **SQL Editor**, or run `supabase db push`. Full steps are in [`../supabase/README.md`](../supabase/README.md).
3. Go to **Database → Publications** and check that `supabase_realtime` includes `messages` and `conversations`. Chat and unread badges need this.
4. Set up **Authentication → Providers**:
   - **Phone.** Turn it on and connect an SMS provider (Twilio, MessageBird, Vonage or Textlocal). Check that SMS actually arrives on Liberian numbers (+231 77x/88x Orange, +231 55x/555 Lonestar/MTN).
     - For testing without SMS, go to **Auth → Phone → Test phone numbers** and add, for example, `231770000000=123456`.
   - **Email.** Turn it on. While you are developing, you can switch off **Confirm email** so sign-up logs the user in right away. If you leave it on, the app tells the user to check their email.
5. Copy your **Project URL** and **anon public key** from **Project Settings → API**.

## 2. Configure the app

```bash
cd app
cp .env.example .env
# edit .env:
# EXPO_PUBLIC_SUPABASE_URL=https://<project-ref>.supabase.co
# EXPO_PUBLIC_SUPABASE_ANON_KEY=<anon public key>
npm install
```

Optional `.env` values:

| Variable | Default | Purpose |
|---|---|---|
| `EXPO_PUBLIC_IMAGE_TRANSFORMS` | `false` | Set to `true` only if your Supabase plan has Image Transformations (Pro). Feed cards then download ~400px thumbnails instead of the ~1080px photo. |
| `EXPO_PUBLIC_SHARE_BASE_URL` | `https://libmarket.app` | The base of the link in shared text (`<base>/l/<listing id>`). |

If the Supabase variables are missing, the app shows a "setup needed" screen instead of crashing.

**Database types.** `src/types/database.ts` is a copy of `../supabase/types.ts`. It is copied so that EAS Build, which uploads only this folder, has everything it needs. After you change the backend types, run `npm run sync-types`.

## 3. Run it on your phone with Expo Go (free)

1. Install **Expo Go** from the Play Store. It must support SDK 57.
2. Run `npx expo start`, then scan the QR code with Expo Go. Your phone and computer need to be on the same Wi-Fi. If they aren't, run `npx expo start --tunnel`.
3. After you edit `.env`, restart with `npx expo start -c`.

Expo Go cannot receive remote push notifications (this has been the case on Android since SDK 53). The app detects Expo Go and emulators and skips push registration without an error. Everything else works in Expo Go.

## 4. Build an installable APK for free with EAS

```bash
npm i -g eas-cli
eas login                       # free Expo account
eas init                        # links the project, writes extra.eas.projectId into app.json (needed for push)
eas build -p android --profile preview
```

- The `preview` profile builds an **APK** (`android.buildType: "apk"`). When the build finishes, EAS gives you a link and a QR code. Open it on the phone to install the app. Free accounts may wait in a queue.
- For EAS Build, set the environment variables in one of these ways:
  - Run `eas env:create --name EXPO_PUBLIC_SUPABASE_URL --value ... --environment preview`, and do the same for the anon key.
  - Or commit a non-secret `.env`. The anon key is safe to ship because RLS protects the data.
- The `production` profile builds an **AAB** for the Play Store: `eas build -p android --profile production`, then `eas submit -p android`.
- **Push notifications in builds.**
  1. Run `eas init`, which sets the projectId.
  2. For Android, add FCM credentials: create a Firebase project, run `eas credentials`, and upload the FCM v1 service account key.
  3. Nothing on the server sends pushes yet (see Open items).
- Android package: `com.libmarket.app`. The app icon and splash images in `assets/` are placeholders (a white star and "LM" on Liberian blue), generated with Python PIL.

## 5. Features

| Area | What's implemented | Backend used |
|---|---|---|
| Auth | Phone OTP (send, 6-digit verify, 60s resend, change number) and email login or sign-up. The session is saved in AsyncStorage and refreshed only while the app is in the foreground. Log out also removes the device's push token. | `auth.signInWithOtp`, `verifyOtp`, `signUp`, `signInWithPassword` |
| Profile setup / edit | Name, avatar upload (compressed to 512px), community picker, WhatsApp number with a "show WhatsApp" toggle, phone number with an "allow calls" (`show_phone`) toggle, and bio. New users are sent here after their first login until they set a community. | `profiles` update, `avatars` bucket |
| Home | Category chips, an area picker ("All Liberia" or a community, remembered on the phone), and a 2-column grid. Promoted items come first and carry a badge. Pull to refresh, infinite scroll (20 per page), skeletons, empty and error states. | RPC `search_listings` |
| Search | Search-as-you-type with a debounce. The filter sheet covers category, community, currency (Any/USD/LRD), price min/max, condition and sort. Active filters show as removable chips, with a result count. "Save search" writes to `saved_searches`. | `search_listings`, `saved_searches` |
| Listing detail | Swipeable photo carousel with full-screen view. Price with a "≈ other currency" hint, badges (negotiable or fixed, condition, reserved, sold, promoted), community, time ago, views and saves, category, and description. Seller trust card (avatar, rating, verified, member since). Safety banner and similar items. Buyers get Chat, Make offer, WhatsApp (`wa.me` link with the listing title filled in) and Call (only if the seller allowed it, and only after login). Share opens WhatsApp or the system share sheet. Also Save (heart), Report item, Report seller and Block seller. The view is counted once per open. Owners see Edit, Reserve/Unreserve, Mark sold, Relist and Delete instead. | `listings` + `public_profiles` embed, `increment_listing_view`, `favorites`, `blocks` |
| Sell / Edit | Up to 10 photos from the camera or gallery. Each is resized to 1080px on its long edge and saved as JPEG at 70%, re-compressed if it is still over ~250KB, then uploaded one at a time with retry to `listing-images/<uid>/<listing>/<uuid>.jpg`. Tap a photo to make it the cover. Photo tips are shown. The form has title (70 characters), searchable category grid, condition chips, price with a USD/LRD toggle and a live "≈" hint, a negotiable switch, a grouped searchable community picker (spec list plus "use what I typed"), and a description (2000 characters). Edit mode can add, remove and reorder photos, and also has Reserve, Mark sold (`mark_listing_sold`) and Delete (soft delete, `status='deleted'`). | `listings`, `listing_images`, storage |
| Chat | The inbox has All/Buying/Selling tabs, the listing thumbnail, the other user, the last message and unread badges. Realtime updates keep the Chats tab badge current. The conversation screen shows a listing header card (with Mark sold for the seller and Review once a deal is done). Messages update in realtime (INSERT and UPDATE) and are loaded 30 at a time. Also in the chat: quick replies (buyer and seller sets), offer messages (buyer), Accept/Decline (seller), photo messages from the private bucket shown through signed URLs, and Sent/Seen ticks. The conversation is marked read when it opens and when a message arrives. A one-time safety notice appears, and a warning shows on messages that look like advance-payment scams. The composer is disabled when a user is blocked. | `start_conversation`, `inbox`, `messages`, `respond_to_offer`, `mark_conversation_read`, `message-images` |
| Reviews | 1–5 stars with an optional comment, and editing your own review. The Review button appears in the chat once the listing is sold or an offer was accepted. Public profiles show the user's items and reviews. | `reviews` |
| Report / Block | Report reasons differ for items and for users, with optional details (insert only). You can block from the listing, the chat or a profile, and unblock in Settings → Blocked users. | `reports`, `blocks` |
| Me | My items (Selling and Sold) with views and saves, a Manage menu (edit, reserve, mark sold, relist, delete) and long-press. Also saved items (with a note when an item was removed), saved searches (tap to run, delete), Settings and Log out. | |
| Push | Asks for permission and registers the Expo push token through `register_push_token`. This is skipped in Expo Go, on emulators, or when there is no EAS projectId. | RPC `register_push_token` |

## 6. Screen map

```
app/
├── _layout.tsx                 Providers (React Query + persisted cache, Auth) and the root Stack
├── (tabs)/
│   ├── _layout.tsx             Bottom tabs: Home · Search · Sell(+) · Chats(badge) · Me
│   ├── index.tsx               Home feed
│   ├── search.tsx              Search + filters sheet + save search
│   ├── sell.tsx                Post item (ListingForm) → /listing/[id]?posted=1
│   ├── chats.tsx               Inbox (All / Buying / Selling)
│   └── profile.tsx             Me: Selling · Sold · Saved · Searches
├── listing/[id].tsx            Listing detail
├── listing/edit/[id].tsx       Edit item (+ reserve / sold / delete)
├── chat/[id].tsx               Conversation (realtime, offers, photos)
├── user/[id].tsx               Public seller profile (items, reviews, report/block)
├── auth/login.tsx              Phone or email login (modal)
├── auth/verify.tsx             SMS code
├── auth/profile-setup.tsx      Onboarding / edit profile
├── review.tsx                  Leave or update a review (modal)
├── report.tsx                  Report item or user (modal)
├── settings/index.tsx          Settings
├── settings/blocked.tsx        Blocked users
└── safety.tsx                  Safety tips
src/
├── lib/        supabase client, api.ts (every query/RPC), images (compress/upload), push, share, format, queryClient
├── hooks/      useAuth (+useRequireAuth), useFavorites, useInbox (+realtime), useListingActions, useReferenceData, useStoredState
├── components/ ui kit, ListingCard/Grid, Price, FiltersSheet, CommunityPicker, CategoryChips/Picker, ListingForm, ImageCarousel, MessageBubble, OfferSheet, SellerCard, SafetyBanner, Sheet
├── constants/  colors (#C8102E red, #002868 blue), categories (icon fallbacks), communities (spec §5), options (conditions, report reasons, quick replies, safety copy)
└── types/      database.ts (copy of supabase/types.ts), app.ts (joined shapes)
```

## 7. Scripts

| Command | What it does |
|---|---|
| `npm start` | Starts the Expo dev server |
| `npm run typecheck` | Runs `tsc --noEmit` in strict mode |
| `npm run sync-types` | Copies `../supabase/types.ts` to `src/types/database.ts` |
| `npx expo export --platform android` | Builds the production JS bundle (a quick sanity check) |

## 8. Open items and limits

- **Push delivery.** Tokens are registered, but no Edge Function sends pushes yet, so new messages don't notify anyone. The backend needs a webhook on `messages` INSERT that calls the Expo Push API. Saved-search alerts need a scheduled function too. The app labels them "Alerts soon".
- **Delete account.** This is required by the Play Store. For now it opens a support email, because there is no backend RPC for it yet.
- **Not in the backend schema yet**, so not in the app: landmark text, Free/Swap flags, listing expiry and renewal, a counter-offer status, contact-reveal events, IMEI fields and subcategories.
- **Draft auto-save.** Post drafts are not saved on the phone yet. Photos upload one at a time with 2 retries each. If some photos still fail, the ad is kept and the user is told to add them with Edit.
- **Data saver.** Image-transform thumbnails need Supabase Pro (`EXPO_PUBLIC_IMAGE_TRANSFORMS`). Without Pro, feed cards load the compressed ~250KB photo, which is cached on disk after the first view.
- **Share links.** `https://libmarket.app/l/<id>` needs a web page or app link to exist. Until then, the shared text still includes the title, price and community.
- **Reviews.** The seller can review the buyer they chatted with. The "who bought it?" picker from the spec is not built. The server enforces that a review can only go to the other party in a conversation.
