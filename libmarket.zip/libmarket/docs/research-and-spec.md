# LibMarket — Competitive Research & Product Spec

> Owner: Product Research · Date: 2026-09-26 · Status: v1.0 (ready for engineering review)
> Stack assumption: Expo (React Native) + Supabase (Auth, Postgres, Storage, Realtime, Edge Functions)

**TL;DR**
- Every winner (OfferUp, letgo, Jiji, Carousell) won on **fast photo-first listing + in-app chat + local feed**. Payments/shipping came later, and in Africa, largely never (Jiji is still "meet and pay on inspection").
- Jiji's Africa model is the closest analogue: **free listings, money from paid boosts/packages for power sellers, phone number visible to buyers**. Copy it, but add the trust layer OfferUp built (verification badge, ratings, meetup spots) because scams are the #1 barrier.
- Liberia specifics drive the design: only ~32% of people are online and data is expensive → **low-data by default**; ~1M+ users each on Orange Money and MTN MoMo → **mobile money is the only payment rail worth building**; WhatsApp is the default channel → **WhatsApp buttons are a feature, not a leak**.

---

## Contents
1. [Feature matrix](#1-feature-matrix)
2. [What worked and what failed](#2-what-worked-and-what-failed)
3. [LibMarket spec (MoSCoW)](#3-libmarket-spec-moscow)
4. [Monetization, trust & safety for Liberia](#4-monetization-and-trust--safety-for-liberia)
5. [Categories and locations](#5-categories-and-locations)
6. [UX notes and screens](#6-ux-notes-and-screens)
7. [Sources](#sources)

---

## 1. Feature matrix

Legend: ✅ = core feature · ◐ = partial / some markets / paid tier · — = absent or not a focus

| Feature | letgo | OfferUp | FB Marketplace | OLX | Jiji | Vinted | Carousell | Mercari | Depop | Why it works |
|---|---|---|---|---|---|---|---|---|---|---|
| Fast photo-first listing (<60s) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | Supply is the bottleneck; every second cut in posting raises listings. OfferUp won praise for being "more user-friendly to list on than eBay" ([Wikipedia](https://en.wikipedia.org/wiki/OfferUp)). |
| Photo tips / guided capture | ✅ | ✅ | ◐ | ◐ | ◐ | ✅ | ✅ | ✅ | ✅ | Better photos mean more clicks and fewer "send more pics" chats. |
| AI auto-category / price suggestion | ✅ image recognition + pricing (2018) ([Wikipedia](https://en.wikipedia.org/wiki/Letgo)) | ◐ | ✅ Meta AI ([TechCrunch](https://techcrunch.com/2025/11/13/facebook-marketplace-gets-new-collaborative-and-social-features-meta-ai-integrations)) | — | — | ◐ | ◐ | ✅ Price Suggestion + Smart Pricing ([Mercari Eng](https://engineering.mercari.com/en/blog/entry/pricing-guidance-system/)) | ◐ | Fewer form fields; pricing help cuts time-to-sale. |
| Moderation before publish | — | ◐ | ◐ | ✅ | ✅ (a few hours) ([Jiji About](https://jiji.ng/about.html)) | ◐ | ◐ | ◐ | ◐ | Blocks scam and duplicate ads in high-fraud markets. The cost is slower posting. |
| Search + filters (price, category, condition, distance) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | Table stakes. |
| Geo / nearby feed | ✅ | ✅ geo-feed, infinite scroll ([Wikipedia](https://en.wikipedia.org/wiki/OfferUp)) | ✅ | ✅ | ✅ (region/city) | — (ships) | ✅ | — (ships) | — | Local pickup only works if items are close. In Liberia, "close" means the same community. |
| Saved / favorites | ✅ | ✅ | ✅ + collections | ✅ | ✅ | ✅ | ✅ | ✅ likes | ✅ | Return-visit hook, and a demand signal for sellers. |
| Saved searches + alerts | ◐ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ◐ | Brings buyers back when fresh supply arrives. It is the top retention loop. |
| Price-drop alerts to likers | — | ◐ | — | — | — | ◐ | ◐ | ✅ Promote notifies all likers on a ≥5% drop ([Mercari](https://www.mercari.com/us/help_center/article/347/)) | ◐ | Turns favorites into sales. Cheap to build once favorites and push exist. |
| In-app chat | ✅ (3B msgs by 2018) ([Wikipedia](https://en.wikipedia.org/wiki/Letgo)) | ✅ secure chat ([OfferUp T&S](https://about.offerup.com/trust-safety)) | ✅ Messenger | ✅ | ✅ | ✅ | ✅ (6.5x chat MAU after rebuild) ([Sendbird](https://sendbird.com/resources/carousell)) | ✅ | ✅ | Keeps the deal in-app (moderation, analytics, safety). Carousell built it because users kept leaving for WhatsApp. |
| Quick replies / suggested messages | ✅ | ✅ | ✅ "Is this still available?" + AI-suggested questions | ◐ | ◐ | ◐ | ✅ Chat-Reply ML + 50 saved replies ([Medium](https://medium.com/carousell-insider/introducing-chat-reply-on-carousell-3efdf06a72e1), [Carousell Help](https://support.carousell.com/hc/en-us/articles/1500002412501--Singapore-CarouBiz-tools-Quick-Reply-and-Auto-Reply)) | ✅ | ◐ | The first message is the biggest drop-off point. One tap removes it. Sellers get repetitive questions. |
| Make-offer | ✅ | ✅ (it's in the name) | ◐ | ◐ | — (chat/call) | ✅ | ✅ | ✅ + offer-to-likers | ✅ | A structured offer makes haggling a clear accept/decline step. |
| Seller ratings / reviews | ✅ | ✅ detailed attributes ([GeekWire](https://www.geekwire.com/2017/new-offerup-features-aim-trust-mobile-marketplace-deals-robberies-thefts/)) | ✅ | ◐ | ✅ feedback ([Jiji FAQ](https://jiji.ng/faq/57)) | ✅ | ✅ | ✅ | ✅ | Reputation replaces brand trust in C2C trading. |
| Response time on profile | ◐ | ✅ | ◐ | — | ✅ ([ProductMint](https://productmint.com/how-does-jiji-make-money/)) | — | ✅ | — | — | Tells buyers who is worth messaging, and pushes sellers to reply. |
| Verification badge | ◐ | ✅ TruYou: phone + ID + selfie via Onfido ([OfferUp Help](https://help.offerup.com/hc/en-us/articles/360031993072-About-TruYou)) | ◐ | ◐ | ✅ verified sellers | ✅ | ✅ | ✅ | ◐ | Removes anonymity, which is the main driver of scams and robbery. |
| Safety tips / meetup spots | ◐ | ✅ 1,960+ MeetUp Spots at police stations and stores ([OfferUp T&S](https://about.offerup.com/trust-safety)) | ◐ | ✅ tips ([OLX PK](https://help.olx.com.pk/hc/en-us/articles/35613871965073-What-are-the-safety-tips-on-OLX)) | ✅ "don't prepay, meet in public" ([Jiji FAQ](https://jiji.ng/faq/57)) | n/a | ◐ | n/a | n/a | Cheap to add and very visible trust signal. |
| Report / block | ✅ | ✅ | ✅ | ✅ block ([OLX PK](https://help.olx.com.pk/hc/en-us/articles/35613871965073-What-are-the-safety-tips-on-OLX)) | ✅ | ✅ | ✅ + auto PII/spam filter | ✅ | ✅ | Required by the stores. Also the main source of moderation signal. |
| Boost / promoted listings | ✅ | ✅ "Bump" / Promote ([Wikipedia](https://en.wikipedia.org/wiki/OfferUp)) | ◐ ads | ✅ | ✅ TOP / Boost / packages ([ProductMint](https://productmint.com/how-does-jiji-make-money/)) | ✅ Bump, Spotlight ([RevenueMemo](https://www.revenuememo.com/p/how-does-vinted-make-money)) | ✅ | ✅ | ✅ pay-on-sale 8% ([Sacra](https://sacra.com/c/depop/)) | The main revenue for free classifieds. It sells to power sellers without taxing casual users. |
| Business / shop subscriptions | ◐ (subs cancelled at merger) | ✅ OfferUp Business | ◐ | ✅ | ✅ packages by category ([Jiji](https://jiji.ng/faq/how-to-buy-premium)) | ◐ Pro | ✅ CarouBiz | — | ◐ | Dealers (phones, cars, property) pay for volume and tools. |
| Shipping / escrow / buyer protection | — | ✅ nationwide shipping | ◐ checkout | ◐ | — | ✅ buyer-paid protection fee = >50% of revenue ([RevenueMemo](https://www.revenuememo.com/p/how-does-vinted-make-money)) | ◐ | ✅ | ✅ | Needed for non-local trade. Not viable yet in Liberia (no reliable parcel network or card rails). |
| Followers / social feed | — | ◐ | ✅ friends, reactions, comments | — | — | ✅ | ✅ | ✅ | ✅ ML feed from the last 300 interactions ([Sacra](https://sacra.com/c/depop/)) | Social graph drives repeat browsing (Depop/Gen Z). A weak fit for utility buying. |
| Phone number shown to buyer ("Show contact") | — | — | — | ✅ (can hide) | ✅ | — | — | — | — | In call-first cultures a phone call closes the deal faster than chat. |
| Share to WhatsApp / external | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | Free distribution. Every shared link is an acquisition channel. |
| Video listings | ✅ (2018) | ◐ | ◐ | — | ◐ | — | ◐ | ◐ | ✅ | More trust for high-ticket items. Too heavy on data for Liberia v1. |

---

## 2. What worked and what failed

### letgo (2015–2020)
| Worked | Failed / lesson |
|---|---|
| Founded by ex-OLX CEO Alec Oxenford. Raised $100M Series A, with **~75% spent on marketing** ([Wikipedia](https://en.wikipedia.org/wiki/Letgo)) | Growth was bought, not earned. It needed ~$375M+ and never became a standalone business. |
| Very simple "snap and sell" listing, with **image recognition + price suggestions** in 2018 | Listings **expired after 30 days**, which created churn ([TechCrunch](https://techcrunch.com/2020/08/31/offerup-and-letgo-combine-marketplaces-post-acquisition)) |
| 100M+ downloads and 400M listings by 2018. Comscore's 2nd-fastest-growing US app in 2017 ([Wikipedia](https://en.wikipedia.org/wiki/Letgo)) | Two apps fighting for the same local US liquidity. **OfferUp acquired letgo (announced Mar 2020, merged Sept 21, 2020)** with a $120M round led by OLX ([TechCrunch](https://techcrunch.com/2020/08/31/offerup-and-letgo-combine-marketplaces-post-acquisition)) |
| | Migration pain: listings did **not transfer** and had to be reposted, subscriptions were cancelled, jobs/services categories were dropped, and Canada was cut off ([TechCrunch](https://techcrunch.com/2020/08/31/offerup-and-letgo-combine-marketplaces-post-acquisition)) |

**Lesson for LibMarket:** Local marketplaces are winner-take-most on **liquidity per neighborhood**. Concentrate on Greater Monrovia before expanding. Never make users re-post, and keep data portable.

### OfferUp
| Worked | Failed / lesson |
|---|---|
| Mobile-first Craigslist replacement with **profiles and ratings** ([Wikipedia](https://en.wikipedia.org/wiki/OfferUp)) | Robberies and stolen goods at meetups ([GeekWire](https://www.geekwire.com/2017/new-offerup-features-aim-trust-mobile-marketplace-deals-robberies-thefts/)) forced a big trust investment |
| Image-first geo feed with infinite scroll. Daily time per user went from 12 to 25 min | Responded with **TruYou** (ID + selfie), detailed ratings, response time, and **MeetUp Spots** at police stations ([OfferUp T&S](https://about.offerup.com/trust-safety)) |
| Free to list, with money from **Bump/Promote** and business accounts | |

**Lesson:** Trust features came *after* safety incidents. Liberia already has high scam awareness, so ship basic trust in v1.

### Jiji (Africa model)
| Worked | Risk / lesson |
|---|---|
| **Free listings**, because Africa's lower incomes can't support listing fees ([ProductMint](https://productmint.com/how-does-jiji-make-money/)) | Paid promotion can look like spam. Yellow "TOP" ads and weak analytics; a Kenyan test got 45 impressions for Ksh 450/week ([Qodewire](https://qodewire.com/jiji-premium-ads-review/)) |
| Revenue from **TOP ads (7–30 days), Boost packages (1–12 months, 6 tiers), PRO cost-per-click** ([ProductMint](https://productmint.com/how-does-jiji-make-money/)). Packages are grouped by **category: Cars, Property, Others, Others Lite, All-in-one** ([Jiji FAQ](https://jiji.ng/faq/how-to-buy-premium)) | Depends on a small base of dealers. Casual sellers rarely pay |
| **Phone number visible** ("Show contact") plus chat. Suits call-first markets ([Jiji About](https://jiji.ng/about.html)) | Visible numbers enable off-platform scams and lose the deal signal |
| **Moderated before publish** (a few hours) plus safety tips: no prepayment, meet in public, inspect first ([Jiji FAQ](https://jiji.ng/faq/57)) | Moderation latency frustrates sellers |
| Consolidated the continent: **bought OLX Africa in 2019** (Nigeria, Ghana, Kenya, Tanzania, Uganda) when OLX exited for "portfolio optimization" ([Nairametrics](https://nairametrics.com/2019/04/04/jiji-acquires-rival-olx-as-e-commerce-startups-continue-to-divest/)). Later bought Cars45 and Tonaton ([Wikipedia](https://en.wikipedia.org/wiki/Jiji_Africa)) | Jiji is **not in Liberia**. The gap is open, but Facebook groups and Marketplace are the incumbent ([FB Marketplace Monrovia](https://www.facebook.com/marketplace/115401238474691/)) |
| 7M monthly users and 160k sellers by Jan 2018 ([Wikipedia](https://en.wikipedia.org/wiki/Jiji_Africa)) | |

### Others (short)
- **Vinted:** Selling is free and the buyer pays a protection fee. That fee is >50% of revenue, and Vinted reported €1.1B revenue by 2025 ([RevenueMemo](https://www.revenuememo.com/p/how-does-vinted-make-money)). This is a v3 option for LibMarket once mobile-money escrow exists.
- **Carousell:** Moved chat in-house because users were leaving for WhatsApp. Chat MAU grew 6.5x and deals closed in minutes instead of hours ([Sendbird](https://sendbird.com/resources/carousell)). It also added PII and spam filters in chat.
- **Mercari:** Price guidance plus "Promote" (a price cut notifies all likers) ([Mercari](https://www.mercari.com/us/help_center/article/347/)).
- **Depop:** A social feed and followers. Moved to buyer fees in 2024. Boosts are pay-on-sale ([Sacra](https://sacra.com/c/depop/)). Good for fashion, but not the core of LibMarket.
- **FB Marketplace:** The default competitor in Monrovia. Its strengths are distribution and zero friction. Its weaknesses are no local trust layer, no structured location, feeds mixed with social content, and a dependency on a Facebook account. Only ~941k social media users in Liberia ([DataReportal](https://datareportal.com/reports/digital-2025-liberia)), so a phone-number-first app reaches people Facebook doesn't.

### Local competition (not deeply analyzed)
Liberia already has small players: [Buy & Sell Liberia app](https://play.google.com/store/apps/details?id=com.buyandsell.app&hl=en), [LiberiaMarketplace](https://liberiamarketplace.com/), [Market231](https://market231.com/), and [Jula](https://julatrade.com/), plus Facebook groups ([example](https://www.facebook.com/groups/buysellshopping3/)). None appears to have Jiji-scale traction. See open issues.

---

## 3. LibMarket spec (MoSCoW)

### Liberia constraints that shape the spec
| Reality | Data | Design consequence |
|---|---|---|
| Low internet penetration | 1.84M internet users (32.4%) vs 5.11M mobile connections (90%) ([DataReportal](https://datareportal.com/reports/digital-2025-liberia)) | Phone-number login. Small APK. Works on 3G. |
| Expensive data | Regulator floor price ~$22/GB (2019). 1GB ≈ 47.5% of monthly income for the poorest 20% (2023) ([TS2](https://ts2.tech/en/liberias-internet-revolution-how-4g-fiber-and-starlink-are-connecting-every-corner-of-the-country/)) | Aggressive image compression, thumbnails, low-data mode on by default |
| Mobile money | Orange Money >1M subscribers (Mar 2025). MTN MoMo 1.28M (end 2025) ([Developing Telecoms](https://developingtelecoms.com/telecom-technology/financial-services/19812-orange-liberias-mobile-money-service-gets-separate-licence-under-new-regs.html)) | Monetization rails = OM + MoMo. No cards. |
| Dual currency | CBL rate L$170.68 buy / L$172.75 sell per US$1 (25 Sep 2026) ([CBL](https://www.cbl.org.lr/research/buying-selling-rates)) | Price in USD **or** LRD, with the other shown as an approximate conversion |
| WhatsApp-first, call-first | Carousell saw users leave for WhatsApp ([Sendbird](https://sendbird.com/resources/carousell)). Jiji shows phone numbers ([Jiji](https://jiji.ng/about.html)) | In-app chat is the default, with WhatsApp and Call buttons offered (seller opt-in) |
| Landmark addressing | Communities, not street numbers ([Wikipedia](https://en.wikipedia.org/wiki/Communities_of_the_Greater_Monrovia_District)) | Location = County → Area → Community (picker) + free-text landmark. No GPS required. |

### MUST — MVP (v1.0)

| # | Feature | Acceptance criteria (engineer-ready) |
|---|---|---|
| M1 | **Auth: phone (OTP) + email** | Supabase Auth. Phone OTP via SMS (Twilio or a local aggregator) with +231 prefilled. Email + password or magic link as fallback. Profile setup: display name, avatar (optional), default community. Session persists. Guests can browse. Auth is required to post, chat, or save. |
| M2 | **Browse feed** | Home = grid of listing cards (2 columns), newest first, filtered to the user's area by default with a toggle for "All Liberia". Cursor pagination (20 per page). Pull-to-refresh. Card shows thumbnail, price (primary currency), title, community, and time ago. Boosted slot placeholder is reserved but unused in v1. |
| M3 | **Categories** | Fixed taxonomy (Section 5), 2 levels, stored in a `categories` table. Category chips on home plus a full category screen with icons. |
| M4 | **Search + filters** | Postgres full-text search on title + description (`tsvector`), with a trigram fallback for typos. Filters: category/subcategory, price min/max (in chosen currency, normalized to USD in the DB), condition, county/area/community, "negotiable only", posted within (24h/7d/30d). Sort: newest, price low→high, price high→low. Recent searches stored locally. |
| M5 | **Listing detail + photo gallery** | Swipeable gallery (1–8 photos), pinch-zoom, lazy full-res. Shows price (primary + converted), Negotiable badge, condition, category, community + landmark, posted date, view count, description, seller card (name, avatar, rating, member since, verified phone ✓, response time later). CTAs: **Chat**, **Make offer**, **WhatsApp**, **Call** (if the seller allows), **Save ♥**, **Share**, **Report**. Safety tip banner. "Similar items" row from the same category and area. |
| M6 | **Post item** | Steps: Photos (1–8, camera or gallery, reorder, first = cover, compressed client-side to ≤1280px long edge, JPEG q≈0.7, ~150–250KB) → Title (≤70 chars) → Category → Price + currency (USD/LRD toggle) + Negotiable switch (+ "Free" and "Swap" options) → Condition (New / Like new / Good / Fair / For parts) → Description (≤2000) → Location (defaults to profile community, plus optional landmark text) → Contact preferences (show WhatsApp / allow calls) → Preview → Publish. Drafts auto-saved locally. Uploads resumable, one photo at a time, with retry. |
| M7 | **Realtime chat per listing** | One thread per (listing, buyer). Supabase Realtime on `messages`. Text + image messages. Quick replies (buyer: "Is this still available?", "What's your last price?", "Where can we meet?"; seller: "Yes, available", "Price is fixed", "Sold, sorry"). Read receipts, unread badges on Inbox tab, listing header in thread (thumb, price, status). Offline queue with retry. Messages paginated (30). Links and phone numbers are allowed, with a warning banner when a message contains "send money first" patterns (regex). |
| M8 | **Make offer in chat** | "Make offer" opens an amount input with a currency. It is posted as a special message type `offer` (amount, currency, status). The seller sees **Accept / Decline / Counter**. An accepted offer shows "Deal agreed. Meet safely" with meetup tips, and optionally marks the listing "Reserved". One pending offer per buyer per listing. |
| M9 | **Saved / favorites** | Heart on card and detail. Saved tab lists saved items and shows when an item is sold or removed. `favorites_count` is visible to the seller. |
| M10 | **My listings** | Tabs: Active / Reserved / Sold / Expired. Actions: Edit (all fields), Mark as Sold (optionally pick the buyer from chat participants to enable a review), Mark Reserved, Renew (listings expire after 60 days with a push/SMS reminder), Delete (soft delete). Shows views, saves, and chat count per listing. |
| M11 | **Seller profile + rating** | Public profile: name, avatar, community, member since, phone-verified badge, avg rating (1–5) + count, active listings grid, reviews list. Reviews are allowed only between users who had a chat thread on a listing marked Sold (or a >24h chat with an accepted offer). One review per pair per listing. Optional tags: "Item as described", "On time", "Friendly". |
| M12 | **Report & block** | Report a listing (reasons: scam/fraud, prohibited item, wrong category, duplicate, offensive, already sold) and a user (scam, harassment, fake profile, no-show). Block user hides their listings and chats both ways. The report queue is in the Supabase table with an admin view (a simple Supabase Studio saved query or an internal page). 3+ unique reports automatically hide a listing pending review. |
| M13 | **Share to WhatsApp** | Share button builds a text with title, price, community, and a deep link (`https://libmarket.app/l/{id}` → app link or web fallback with an OG image). Uses a `whatsapp://send?text=` intent, falling back to the native share sheet. |
| M14 | **Call / WhatsApp seller buttons** | Shown only if the seller enabled them. The number is revealed on tap (log a `contact_reveal` event to count leads). WhatsApp opens `https://wa.me/231XXXXXXXX?text=Hi, I saw your "{title}" on LibMarket...`. Requires login to reveal (reduces scraping). |
| M15 | **Safety basics** | First-chat safety interstitial (once), a safety tips page, and a banner on detail: "Meet in public. Inspect before you pay. Never send mobile money in advance." |
| M16 | **Low-data defaults** | Thumbnails (~320px WebP/JPEG) in feeds, full images only on the detail screen. A "Data saver" setting (on by default on cellular). Image caching (expo-image). |
| M17 | **Admin basics** | Role flag on `profiles`. Can remove listings, ban users, and review reports. Row Level Security on all tables. |

### SHOULD — v1.1 (4–8 weeks after launch)
| Feature | Notes |
|---|---|
| **Push notifications** (Expo Push) | New message, offer received/accepted, listing about to expire. SMS fallback for OTP only. |
| **Saved searches + alerts** | Save the filter set. A daily Edge Function cron matches new listings and sends a push digest. |
| **Price-drop alert to savers** | When the price drops ≥5%, notify users who saved the item (Mercari pattern). |
| Seller response time and "last active" | Computed from chat timestamps. |
| Meetup spot suggestions in chat | A curated list of public spots per community (see Section 4), shared as a chat card. |
| Listing auto-moderation | Keyword blocklist, duplicate-image hash, and a new-account posting cap (e.g., 5 per day). |
| Mark "Reserved" and "Swap" filters | |
| Seller quick-reply templates | Custom saved replies (Carousell CarouBiz pattern). |
| Recently viewed | |

### COULD — v2
| Feature | Notes |
|---|---|
| **Boosts via mobile money** (Orange Money / MTN MoMo) | See Section 4 pricing. Needs an aggregator or direct merchant API. |
| **Verification badge** ("LibMarket Verified") | Phone ✓ (v1) → ID + selfie (National ID / passport / voter card) reviewed manually or via a vendor (TruYou pattern). |
| **Shop / business accounts** | Subscription: storefront, bulk listing, more active ads, analytics (Jiji packages by category). |
| AI auto-category + title from photo | letgo/Mercari pattern. Use a vision model via an Edge Function. |
| Price suggestion | From historical listings in the same subcategory. |
| Followers of shops | |
| In-app referral ("Invite via WhatsApp") | |
| Web app (SEO listing pages) | Captures Google search traffic. Shared links render nicely. |

### WON'T (for now)
- Shipping / escrow / in-app payment for items. There is no reliable parcel network and mobile-money escrow has legal/KYC overhead. Revisit for v3 using the Vinted buyer-protection model.
- Video listings (data cost).
- Social feed, comments, and reactions.

### MVP data model (Supabase / Postgres)
| Table | Key columns |
|---|---|
| `profiles` | id (= auth.users.id), display_name, avatar_url, phone, phone_verified, whatsapp_enabled, calls_enabled, county_id, community_id, rating_avg, rating_count, role, is_banned, created_at, last_active_at |
| `categories` | id, parent_id, slug, name, icon, sort_order, is_active |
| `locations` | id, type (county/area/community), parent_id, name, aliases[] |
| `listings` | id, seller_id, category_id, title, description, price_amount, currency ('USD'\|'LRD'), price_usd_normalized, is_negotiable, is_free, is_swap, condition, county_id, community_id, landmark, status ('active'\|'reserved'\|'sold'\|'expired'\|'removed'), views, favorites_count, search_tsv, expires_at, created_at, updated_at |
| `listing_photos` | id, listing_id, storage_path, thumb_path, width, height, position |
| `favorites` | user_id, listing_id, created_at (PK both) |
| `conversations` | id, listing_id, buyer_id, seller_id, last_message_at, buyer_unread, seller_unread (unique listing_id + buyer_id) |
| `messages` | id, conversation_id, sender_id, type ('text'\|'image'\|'offer'\|'system'), body, offer_amount, offer_currency, offer_status ('pending'\|'accepted'\|'declined'\|'countered'), created_at, read_at |
| `reviews` | id, listing_id, reviewer_id, reviewee_id, rating, tags[], comment, created_at |
| `reports` | id, reporter_id, target_type, target_id, reason, note, status, created_at |
| `blocks` | blocker_id, blocked_id |
| `events` | id, user_id, type ('view'\|'contact_reveal'\|'share'), listing_id, created_at (for lead metrics / future boost ROI) |
| `fx_rates` | date, usd_lrd (admin-set daily from CBL) |

---

## 4. Monetization and trust & safety for Liberia

### Monetization (phased)
| Phase | Stream | Model | Indicative price (to validate) | Rationale |
|---|---|---|---|---|
| v1 | **None** (free everything) | Grow liquidity | — | letgo/Jiji both launched free. Liquidity first ([ProductMint](https://productmint.com/how-does-jiji-make-money/)) |
| v2 | **Boost / Top listing** | Pinned to the top of its category + area for N days, with a "Promoted" label (subtle, not Jiji yellow) | US$1 / 3 days, US$2 / 7 days (or LRD equivalent) | Jiji TOP and OfferUp Bump are proven. Keep it cheap so casual sellers try it. |
| v2 | **Bump / Refresh** | Moves the listing back to "newest" | US$0.25–0.50 per bump | Micro-payment that fits mobile money |
| v2 | **Shop subscriptions** (by category, Jiji-style) | Monthly: more active listings, shop page, verified business badge, stats, auto-bumps | Phones/Electronics shop US$5–10/mo; Cars/Property US$15–25/mo | Dealers already sell on FB groups. They pay for leads. |
| v2 | **Paid verification** (optional) | ID-verified badge, one-off fee | US$1–2 | Covers manual review cost, and the badge signals seriousness |
| v3 | **Featured banners / local business ads** | Direct sales to dealers, telcos, and banks | CPM or flat monthly | |
| v3 | **Buyer protection (escrow via MoMo/OM)** | Vinted model: buyer pays a small fee and money is released on confirmation | ~5% + fixed | >50% of Vinted revenue ([RevenueMemo](https://www.revenuememo.com/p/how-does-vinted-make-money)). Needs a licensed payment partner. |

**Payment rails:** Orange Money and MTN MoMo are the only rails worth building. Both have ~1M+ subscribers and are being spun into separately licensed fintechs ([Developing Telecoms](https://developingtelecoms.com/telecom-technology/financial-services/19812-orange-liberias-mobile-money-service-gets-separate-licence-under-new-regs.html), [MTN Liberia MoMo](https://lonestarcell.com/momo/)). The v2 interim option (no API) is a manual "pay to merchant code + enter transaction ID", with admin confirmation and activation. Replace it with an API or aggregator when available.

### Trust & safety (Liberia-specific)
| Risk | Mitigation | Phase |
|---|---|---|
| **Advance-payment scam** ("send MoMo first, I'll deliver") | Banner on detail and in chat. Regex detection of "send money", "MoMo first", "transport fare", "deposit" in chat, which shows a warning card. Safety tip: never send mobile money before seeing the item ([Jiji FAQ](https://jiji.ng/faq/57)) | MVP |
| **Fake MoMo / OM payment SMS** sent to sellers | Seller tip: "Check your balance in the USSD menu (*144# Orange / *156# MTN) before handing over the item. Never trust an SMS screenshot." | MVP (copy) — **verify USSD codes** |
| Robbery at meetup | **Safe meetup spots** list per community (supermarkets, bank branches, police depots, busy junctions, e.g. ELWA Junction, Red Light, Sinkor supermarkets), shared from chat. Tip: meet in daytime and bring someone. OfferUp pattern ([OfferUp](https://help.offerup.com/hc/en-us/articles/360032335691-About-Community-MeetUp-Spots)) | v1.1 (list curated by ops) |
| Fake / stolen phones | Phone category asks for an optional IMEI last-4 and a "box and receipt available" flag. Tip to check IMEI (*#06#) at the meetup | MVP field, v1.1 check |
| Fake accounts / multi-accounting | Phone OTP required to post. One account per phone. New-account caps. Device fingerprint later | MVP |
| Counterfeit / prohibited items | Prohibited list (weapons, drugs, wildlife/bushmeat, stolen goods, prescription meds, counterfeit currency, adult). Keyword filter on post. Report flow | MVP list + report, v1.1 filter |
| Property rental scams (fake landlords taking "inspection fee" or "advance") | If property is enabled: "Never pay before viewing the property and meeting the owner" banner. Agent badge only for verified agents | v1.1 |
| Harassment | Block, report, and hiding phone numbers by default (seller opt-in to show) | MVP |
| Reputation gaming | Reviews only after chat + sold/accepted offer. One per pair per listing | MVP |
| Identity | TruYou-style badge (phone ✓ → ID + selfie ✓) ([OfferUp](https://help.offerup.com/hc/en-us/articles/360031993072-About-TruYou)) | Phone MVP, ID v2 |

---

## 5. Categories and locations

### Recommended categories (v1 = 14 top-level)
| # | Category | Subcategories (examples) | Note |
|---|---|---|---|
| 1 | **Phones & Tablets** | Smartphones, Basic phones, Tablets, Accessories, Chargers & power banks | Highest-volume category on Jiji-style sites |
| 2 | **Electronics** | TVs, Laptops & computers, Audio & speakers, Cameras, Gaming, Decoders/satellite | |
| 3 | **Generators, Solar & Power** | Generators, Solar panels, Inverters & batteries, Stabilizers, Fuel containers | Liberia-specific. Unreliable grid makes this a high-demand category |
| 4 | **Home Appliances** | Fridges & freezers, Fans & AC, Washing machines, Kitchen appliances, Water dispensers | |
| 5 | **Furniture & Home** | Beds & mattresses, Sofas, Tables & chairs, Wardrobes, Décor, Kitchenware | |
| 6 | **Vehicles** | Cars, SUVs & jeeps, Trucks & pickups, Buses, Vehicle parts & tyres | High-ticket. Future boost/shop revenue |
| 7 | **Motorbikes & Keke** | Motorbikes (pen-pen), Tricycles (keke), Parts & helmets | Liberia-specific |
| 8 | **Fashion** | Men's clothing, Women's clothing, Shoes, Bags, Watches & jewelry, Lappa & African wear | |
| 9 | **Health & Beauty** | Hair & wigs, Cosmetics, Perfumes | No prescription medicines |
| 10 | **Babies & Kids** | Baby gear, Kids' clothes, Toys, School supplies | |
| 11 | **Building & Tools** | Building materials (zinc, cement, rods), Tools, Plumbing & electrical | |
| 12 | **Sports, Hobbies & Books** | Sports equipment, Musical instruments, Books | |
| 13 | **Agriculture & Food** | Farm tools, Seeds, Livestock & poultry | Moderate carefully (no bushmeat) |
| 14 | **Other / Free & Swap** | Free stuff, Swap, Miscellaneous | |

**Property rentals: v1.1 (SHOULD), gated.** High demand in Monrovia (Jiji has a whole Property package tier ([Jiji](https://jiji.ng/faq/how-to-buy-premium))), but it is the category most exposed to "advance fee" scams, and it needs different fields (bedrooms, rent period, number of months up-front). Launch it after the report/moderation loop is proven, with an agent-verification flow.

**Jobs and Services: WON'T in v1.** They don't fit the "used items" positioning, need different listing flows, and carry high spam risk. OfferUp dropped jobs/services at the letgo merger ([TechCrunch](https://techcrunch.com/2020/08/31/offerup-and-letgo-combine-marketplaces-post-acquisition)). Reconsider in v2 as a separate vertical.

### Location picker — Greater Monrovia (Montserrado)
Structure: **Area** (township / city corporation) → **Community**, plus free-text **Landmark** ("near Total gas station, ELWA junction"). Names come from [Communities of the Greater Monrovia District](https://en.wikipedia.org/wiki/Communities_of_the_Greater_Monrovia_District), [Greater Monrovia District](https://en.wikipedia.org/wiki/Greater_Monrovia_District), and [Monrovia](https://en.wikipedia.org/wiki/Monrovia). Entries marked † are colloquial names in common use that were not in those lists. Ops should confirm them locally.

| Area | Communities for the picker (commonly used names) |
|---|---|
| **Central Monrovia** | Broad Street / Downtown, Waterside, Capitol Hill, Mamba Point, Snapper Hill, Crown Hill, Center Street, Randall Street, Camp Johnson Road†, Slipway, West Point, Jallah Town, Bishop Brooks, Soniwein, Clay Street† |
| **Sinkor** | Sinkor, Old Road, Sinkor 3rd–24th Street†, Tubman Boulevard†, Airfield†, Fiamah, Lakpazee, 9th Street†, Matadi (Old/New), Wroto Town, Raymond Field |
| **Congo Town** | Congo Town, Oldest Congo Town, Congo Town Old Road, Swankamore, Chugbor, Tarr Town, Peace Island, Pagos Island, Smythe Road, Catholic Hospital, Key & Death Hole |
| **Paynesville** | Paynesville Joe Bar, Red Light, ELWA (King Gray-ELWA), Rehab / Borbor Town, 72nd, Duport Road, Pipeline, Police Academy, GSA Road / Rockville, Jacob Town, Kpelle Town, Soul Clinic, S.D. Cooper, Town Hall, Wood Camp, Zinc Factory, A.B. Tolbert Road, Morris Farm, Omega / Kemah Town, Kendeja, Double Bridge, SKD Boulevard†, Somalia Drive†, Coca-Cola Factory†, Nancy Doe Market† |
| **Gardnersville** | Gardnersville, Barnersville Road, Stephen Tolbert Estate, Kesselly Boulevard, JJY / Snow Hill, Shoe Factory, MTA, Mangrove Island, Grass Field |
| **Barnersville** (also spelled Barnesville) | Barnersville Estate, Kaba Town, Dabwe Town, Johnsonville Road, Old Field, Behwein Community |
| **New Georgia** | New Georgia, New Georgia Estate, Chocolate City, Battery Factory, Iron Factory, SOS, Topoe Village, Flahn Town |
| **Bushrod Island** | Clara Town, Logan Town, Vai Town, Freeport, Jamaica Road, Stockton Creek, Point Four, Doe Community†, Duala, Duala Market, New Kru Town, Popo Beach, Crab Hole, Zinc Camp |
| **Caldwell / Virginia / Brewerville** | Caldwell, Upper Caldwell, Caldwell Market, Cassava Hill, Louisiana, Dixville, Virginia†, Brewerville†, Kpallah† |
| **Johnsonville & east** | Johnsonville, Rock Hill, City View, Mount Barclay†, Bensonville (Montserrado capital), Duazon† (Margibi border), ELWA–Roberts Field Hwy communities† |

> MVP implementation: seed `locations` with a CSV of ~150 communities. Allow a "My community isn't listed → type it" free-text entry that goes to an admin review queue, so the list grows organically. Store aliases (e.g., "Barnesville", "Barnersville"; "Fiama", "Fiamah"; "Joe Bar", "Paynesville Joe Bar") so both spellings match in search.

### Other counties — capital / main city
Source: [Statoids](https://statoids.com/ulr.html). Main commercial towns added where they differ from the capital.

| County | Capital | Other main towns for the picker |
|---|---|---|
| Montserrado | Bensonville | Greater Monrovia (above) |
| Margibi | Kakata | Harbel / Firestone, Marshall, Unification Town (RIA airport) |
| Bong | Gbarnga | Salala, Totota |
| Nimba | Sanniquellie | **Ganta** (main commercial hub), Saclepea, Tappita, Yekepa |
| Grand Bassa | Buchanan | Compound #1 |
| Grand Cape Mount | Robertsport | Sinje, Bo Waterside |
| Bomi | Tubmanburg | |
| Gbarpolu | Bopolu | |
| Lofa | Voinjama | Foya, Zorzor |
| Grand Gedeh | Zwedru | |
| River Gee | Fish Town | |
| Maryland | Harper | Pleebo |
| Grand Kru | Barclayville | |
| Sinoe | Greenville | |
| Rivercess | Cestos City | |

---

## 6. UX notes and screens

### Principles
1. **3 taps to browse, 60 seconds to post.** No signup to browse. OTP only when posting, chatting, or saving.
2. **Low data by default.** Target ≤ 1.5MB to load the home feed on first open and ≤ 250KB per uploaded photo. Show "Data saver ON" in settings.
3. **Works on a $60 Android:** Android 8+, 2GB RAM, 720p screens, small APK (Hermes, no heavy libraries), large tap targets (≥44dp), system font scaling.
4. **Liberian English copy**, short and friendly ("Your item is live!", "Make your offer", "Still available?"). Avoid jargon like "listing" in primary CTAs and use "item" or "ad".
5. **Currency clarity:** always show which currency ("US$45" / "L$7,700"), with the converted value in grey ("≈ L$7,700"). The FX rate is admin-set daily from the [CBL rate](https://www.cbl.org.lr/research/buying-selling-rates).
6. **Trust visible everywhere:** verified-phone tick, rating stars, "member since", and safety banner.

### Onboarding (first launch)
1. Splash with 3 swipeable value cards (skippable): "Sell in 60 seconds", "Chat, call or WhatsApp sellers", "Meet safely. Pay after you inspect."
2. **Pick your area** (county → community). Stored locally and used for the default feed. No login yet.
3. Land on the Home feed.
4. Login is prompted contextually (on Post, Chat, or Save): phone number with +231 → OTP (6 digits, auto-read on Android) → name → done. Email is a secondary option.

### Low-data mode (spec)
| Item | Behavior |
|---|---|
| Upload compression | `expo-image-manipulator`: resize to max 1280px long edge, JPEG 0.7. Also generate a 320px thumbnail client-side, or server-side via Supabase image transforms |
| Feed images | Thumbnails only. `expo-image` with memory + disk cache and blurhash placeholders |
| Detail images | Load the first full image, the rest when swiped. In Data saver mode, show a "Tap to load HD" option |
| API | Select only needed columns. Paginate 20 items. No autoplay. Avoid polling (Realtime only for open chats) |
| Offline | Cache the last feed and chats. Queue outgoing messages and post drafts |
| Metrics | Log bytes per session in dev builds to enforce budgets |

### Screens list (MVP)
| # | Screen | Key elements |
|---|---|---|
| 1 | **Onboarding / Area picker** | Value cards, county → community picker, Skip |
| 2 | **Login (Phone / Email)** | +231 prefix, phone input, "Use email instead", terms link |
| 3 | **OTP verify** | 6-digit input, auto-read, resend timer (60s), change number |
| 4 | **Profile setup** | Name, optional photo, default community, "Show my WhatsApp" / "Allow calls" toggles |
| 5 | **Home (Browse)** | Search bar, area chip ("Paynesville ▾"), category chips row, listing grid (2 columns), floating **Sell** button, bottom tabs: Home · Saved · **Sell** · Inbox · Me |
| 6 | **Categories** | Icon grid of 14 categories → subcategory list → results |
| 7 | **Search results** | Query, result count, Filter button (badge with active count), Sort, grid/list toggle, "No results → Save this search (v1.1)" |
| 8 | **Filters sheet** | Category, price range + currency, condition chips, location (county/area/community), negotiable, posted within, Reset / Apply |
| 9 | **Listing detail** | Gallery, price + converted price, Negotiable badge, title, condition, community + landmark, time, views; description; seller card (avatar, name, ★ rating, verified ✓, member since → profile); safety banner; similar items; sticky bottom bar: **Chat** · **Make offer** · WhatsApp · Call; top bar: back, ♥ save, share, ⋮ report |
| 10 | **Post item: Photos** | Camera / gallery, up to 8, reorder, cover badge, photo tips ("Use daylight", "Show any damage", "Plain background") |
| 11 | **Post item: Details** | Title, category picker, price + USD/LRD toggle, Negotiable / Free / Swap, condition chips, description, location (prefilled) + landmark, contact toggles |
| 12 | **Post item: Preview & publish** | Card preview, Edit, Publish. Success screen: "Your item is live!" + **Share to WhatsApp** + View item |
| 13 | **Inbox** | Threads with listing thumbnail, other user, last message, time, unread badge; tabs Buying / Selling |
| 14 | **Chat thread** | Listing header (thumbnail, price, status, "Mark sold" for seller), messages, offer cards (Accept / Decline / Counter), quick-reply chips, text input + photo attach, safety interstitial on first open, ⋮ block / report |
| 15 | **Make offer sheet** | Amount, currency, asking price shown, Send offer |
| 16 | **Saved** | Grid of favorites with sold/removed state; (v1.1) Saved searches tab |
| 17 | **Me / My listings** | Tabs Active / Reserved / Sold / Expired; per-item stats (views, saves, chats); actions Edit / Mark sold / Renew / Delete |
| 18 | **Edit listing** | Same form as Post, prefilled |
| 19 | **Mark as sold** | "Who bought it?" (pick from chat participants or "Someone else"). Triggers a review request |
| 20 | **Public seller profile** | Avatar, name, community, member since, verified ✓, ★ avg + count, listings grid, reviews tab, ⋮ report / block |
| 21 | **Leave review** | 1–5 stars, tags, optional comment |
| 22 | **Report** | Reason list, optional note, submit confirmation |
| 23 | **Settings** | Edit profile, contact preferences, Data saver, currency display preference, blocked users, safety tips, help / WhatsApp support, terms / privacy, log out, delete account (required by the stores) |
| 24 | **Safety tips** | Static page: meet in public, inspect first, no MoMo in advance, check phone IMEI, check the MoMo balance yourself, report suspicious users |
| 25 | **Admin (internal)** | Reports queue, remove listing, ban user, set FX rate, manage categories/locations |

---

## Top 10 MVP features (priority order)
1. Post item in <60s (multi-photo with compression, USD/LRD, condition, negotiable, community)
2. Browse feed filtered to area + categories
3. Search + filters (price, category, condition, community)
4. Listing detail with gallery + seller trust card
5. Realtime in-app chat per listing with quick replies
6. Make-offer card in chat (accept / decline / counter)
7. Phone-OTP auth (email fallback), browse without login
8. Call / WhatsApp seller buttons (seller opt-in) + Share to WhatsApp deep link
9. Seller profile with verified-phone tick and post-sale ratings
10. Report & block + safety banners (plus Saved / favorites and My Listings as table stakes)

## Open issues / to validate
- **SMS OTP provider for +231**: confirm deliverability and cost (Twilio vs a local aggregator vs Supabase's built-in providers). WhatsApp OTP could be a cheaper alternative.
- **Mobile money merchant APIs**: public developer access for Orange Money Liberia and MTN MoMo Liberia is not confirmed. v2 boosts may need a manual transaction-ID flow first.
- **USSD codes** in the safety copy (*144# / *156#) need local verification before shipping.
- Community list entries marked † are colloquial. Ops should run a 30-minute local review. Township spelling "Barnersville" vs "Barnesville" appears both ways in sources. Store both as aliases.
- **Local competitors** (Market231, LiberiaMarketplace, Jula, Buy & Sell Liberia) were not analyzed in depth. Their pages timed out or had little data.
- **Boost price points** are hypotheses. Validate with 10–20 Monrovia phone/electronics dealers who sell on Facebook groups.
- **Property category** go/no-go (recommended v1.1 with scam safeguards).
- Legal: terms of service, a prohibited items list aligned with Liberian law, data protection, and any LTA/CBL implications if escrow is ever added.

---

## Sources
- letgo: [Wikipedia](https://en.wikipedia.org/wiki/Letgo) · [TechCrunch merger](https://techcrunch.com/2020/08/31/offerup-and-letgo-combine-marketplaces-post-acquisition)
- OfferUp: [Wikipedia](https://en.wikipedia.org/wiki/OfferUp) · [TruYou](https://help.offerup.com/hc/en-us/articles/360031993072-About-TruYou) · [MeetUp Spots](https://help.offerup.com/hc/en-us/articles/360032335691-About-Community-MeetUp-Spots) · [Trust & Safety](https://about.offerup.com/trust-safety) · [GeekWire 2017](https://www.geekwire.com/2017/new-offerup-features-aim-trust-mobile-marketplace-deals-robberies-thefts/)
- Jiji: [ProductMint](https://productmint.com/how-does-jiji-make-money/) · [Jiji About](https://jiji.ng/about.html) · [Jiji Premium FAQ](https://jiji.ng/faq/how-to-buy-premium) · [Jiji Safety FAQ](https://jiji.ng/faq/57) · [Qodewire review](https://qodewire.com/jiji-premium-ads-review/) · [Wikipedia](https://en.wikipedia.org/wiki/Jiji_Africa) · [Nairametrics OLX deal](https://nairametrics.com/2019/04/04/jiji-acquires-rival-olx-as-e-commerce-startups-continue-to-divest/)
- OLX: [OLX PK safety](https://help.olx.com.pk/hc/en-us/articles/35613871965073-What-are-the-safety-tips-on-OLX)
- Vinted: [RevenueMemo](https://www.revenuememo.com/p/how-does-vinted-make-money)
- Carousell: [Chat-Reply](https://medium.com/carousell-insider/introducing-chat-reply-on-carousell-3efdf06a72e1) · [Sendbird case](https://sendbird.com/resources/carousell) · [Quick/Auto Reply](https://support.carousell.com/hc/en-us/articles/1500002412501--Singapore-CarouBiz-tools-Quick-Reply-and-Auto-Reply)
- Mercari: [Promote](https://www.mercari.com/us/help_center/article/347/) · [Price guidance](https://engineering.mercari.com/en/blog/entry/pricing-guidance-system/)
- Depop: [Sacra](https://sacra.com/c/depop/)
- Facebook Marketplace: [TechCrunch 2025](https://techcrunch.com/2025/11/13/facebook-marketplace-gets-new-collaborative-and-social-features-meta-ai-integrations) · [Monrovia Marketplace](https://www.facebook.com/marketplace/115401238474691/)
- Liberia: [DataReportal 2025](https://datareportal.com/reports/digital-2025-liberia) · [TS2 internet/data costs](https://ts2.tech/en/liberias-internet-revolution-how-4g-fiber-and-starlink-are-connecting-every-corner-of-the-country/) · [Developing Telecoms (OM/MoMo)](https://developingtelecoms.com/telecom-technology/financial-services/19812-orange-liberias-mobile-money-service-gets-separate-licence-under-new-regs.html) · [MTN MoMo Liberia](https://lonestarcell.com/momo/) · [CBL exchange rates](https://www.cbl.org.lr/research/buying-selling-rates) · [Greater Monrovia communities](https://en.wikipedia.org/wiki/Communities_of_the_Greater_Monrovia_District) · [Greater Monrovia District](https://en.wikipedia.org/wiki/Greater_Monrovia_District) · [Monrovia](https://en.wikipedia.org/wiki/Monrovia) · [Counties (Statoids)](https://statoids.com/ulr.html)
